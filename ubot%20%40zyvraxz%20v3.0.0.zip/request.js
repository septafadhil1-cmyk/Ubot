const fs = require("fs");
const path = require("path");
const { NewMessage } = require("telegram/events");

const REQUEST_FILE = path.join(__dirname, "requests.json");

// ===============================
// DATABASE
// ===============================

function loadRequests() {
  try {
    if (!fs.existsSync(REQUEST_FILE)) {
      fs.writeFileSync(REQUEST_FILE, "[]", "utf8");
      return [];
    }

    const data = fs.readFileSync(REQUEST_FILE, "utf8");
    const parsed = JSON.parse(data);

    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error("Gagal membaca requests.json:", err.message);
    return [];
  }
}

function saveRequests(data) {
  try {
    fs.writeFileSync(
      REQUEST_FILE,
      JSON.stringify(data, null, 2),
      "utf8"
    );
  } catch (err) {
    console.error("Gagal menyimpan requests:", err.message);
  }
}

// ===============================
// HTML ESCAPE
// ===============================

function escapeHTML(text) {
  return String(text ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ===============================
// PLUGIN
// ===============================

module.exports = function requestPlugin(bot, config = {}) {

  // GANTI DENGAN ID TELEGRAM OWNER
  const OWNER_ID = String(
    config.ownerId || "8872735892"
  );

  function isOwner(userId) {
    return String(userId) === OWNER_ID;
  }

  // ===============================
  // EVENT HANDLER
  // ===============================

  bot.addEventHandler(
    async (event) => {
      try {
        const message = event.message;

        if (!message) return;

        const text = String(message.message || "").trim();

        if (!text.startsWith("/")) return;

        // ===============================
        // USER ID
        // ===============================

        const senderId = message.senderId;

        if (!senderId) return;

        const userId = String(senderId);

        // ===============================
        // AMBIL DATA USER
        // ===============================

        let sender = null;

        try {
          sender = await bot.getEntity(senderId);
        } catch (err) {
          sender = null;
        }

        const username = sender?.username
          ? `@${sender.username}`
          : sender?.firstName
            ? sender.firstName
            : `ID ${userId}`;

        // ==================================================
        // /request
        // ==================================================

        if (/^\/request(?:@\w+)?(?:\s|$)/i.test(text)) {

          const requestText = text
            .replace(/^\/request(?:@\w+)?/i, "")
            .trim();

          if (!requestText) {
            await message.reply({
              message:
                "❌ <b>Format salah!</b>\n\n" +
                "Gunakan:\n" +
                "<code>/request isi request kamu</code>",
              parseMode: "html",
            });

            return;
          }

          const requests = loadRequests();

          // ID berikutnya
          let nextId = 1;

          if (requests.length > 0) {
            nextId =
              Math.max(
                ...requests.map((item) => Number(item.id) || 0)
              ) + 1;
          }

          const newRequest = {
            id: nextId,
            userId: userId,
            username: username,
            request: requestText,
            status: "pending",
            createdAt: new Date().toISOString(),
          };

          requests.push(newRequest);

          saveRequests(requests);

          // ===============================
          // BALAS USER
          // ===============================

          await message.reply({
            message:
              "✅ <b>REQUEST TERKIRIM!</b>\n\n" +
              `🆔 ID: <code>${nextId}</code>\n` +
              `👤 User: ${escapeHTML(username)}\n` +
              `📝 Request: ${escapeHTML(requestText)}\n\n` +
              "⏳ Status: <b>Pending</b>\n\n" +
              "Silakan tunggu sampai request diproses.",
            parseMode: "html",
          });

          // ===============================
          // NOTIF OWNER
          // ===============================

          try {
            await bot.sendMessage(OWNER_ID, {
              message:
                "📥 <b>REQUEST BARU</b>\n\n" +
                `🆔 ID: <code>${nextId}</code>\n` +
                `👤 User: ${escapeHTML(username)}\n` +
                `🆔 User ID: <code>${userId}</code>\n` +
                `📝 Request:\n${escapeHTML(requestText)}\n\n` +
                "⏳ Status: <b>Pending</b>\n\n" +
                `Gunakan <code>/done ${nextId}</code> untuk menyelesaikan.\n` +
                `Gunakan <code>/delrequest ${nextId}</code> untuk menghapus.`,
              parseMode: "html",
            });
          } catch (err) {
            console.error(
              "Gagal mengirim notifikasi owner:",
              err.message
            );
          }

          return;
        }

        // ==================================================
        // /requests
        // ==================================================

        if (/^\/requests(?:@\w+)?$/i.test(text)) {

          if (!isOwner(userId)) {
            await message.reply({
              message: "❌ Kamu tidak punya akses ke daftar request.",
            });

            return;
          }

          const requests = loadRequests();

          if (requests.length === 0) {
            await message.reply({
              message:
                "📭 <b>DAFTAR REQUEST</b>\n\n" +
                "Belum ada request.",
              parseMode: "html",
            });

            return;
          }

          let output =
            "📋 <b>DAFTAR REQUEST</b>\n\n";

          for (const item of requests) {

            const status =
              item.status === "done"
                ? "✅ Selesai"
                : "⏳ Pending";

            output +=
              `🆔 <b>#${item.id}</b>\n` +
              `👤 ${escapeHTML(item.username || "Unknown")}\n` +
              `📝 ${escapeHTML(item.request || "-")}\n` +
              `📌 Status: <b>${status}</b>\n\n`;
          }

          // Telegram memiliki batas panjang pesan.
          if (output.length > 4000) {
            output =
              output.substring(0, 3900) +
              "\n\n<i>Daftar terlalu panjang...</i>";
          }

          await message.reply({
            message: output,
            parseMode: "html",
          });

          return;
        }

        // ==================================================
        // /done <id>
        // ==================================================

        if (/^\/done(?:@\w+)?(?:\s|$)/i.test(text)) {

          if (!isOwner(userId)) {
            await message.reply({
              message: "❌ Kamu tidak punya akses.",
            });

            return;
          }

          const idText = text
            .replace(/^\/done(?:@\w+)?/i, "")
            .trim();

          const id = Number(idText);

          if (!Number.isInteger(id) || id <= 0) {
            await message.reply({
              message:
                "❌ <b>Format salah!</b>\n\n" +
                "Gunakan:\n" +
                "<code>/done 1</code>",
              parseMode: "html",
            });

            return;
          }

          const requests = loadRequests();

          const item = requests.find(
            (request) => Number(request.id) === id
          );

          if (!item) {
            await message.reply({
              message:
                `❌ Request dengan ID <code>${id}</code> tidak ditemukan.`,
              parseMode: "html",
            });

            return;
          }

          if (item.status === "done") {
            await message.reply({
              message:
                `ℹ️ Request <b>#${id}</b> sudah selesai sebelumnya.`,
              parseMode: "html",
            });

            return;
          }

          item.status = "done";
          item.doneAt = new Date().toISOString();

          saveRequests(requests);

          await message.reply({
            message:
              "✅ <b>REQUEST SELESAI!</b>\n\n" +
              `🆔 ID: <code>${id}</code>\n` +
              `👤 ${escapeHTML(item.username)}\n` +
              `📝 ${escapeHTML(item.request)}\n\n` +
              "📌 Status: <b>Selesai</b>",
            parseMode: "html",
          });

          // ===============================
          // NOTIF USER
          // ===============================

          try {
            await bot.sendMessage(item.userId, {
              message:
                "✅ <b>REQUEST KAMU SELESAI!</b>\n\n" +
                `🆔 ID: <code>${id}</code>\n` +
                `📝 ${escapeHTML(item.request)}\n\n` +
                "📌 Status: <b>Selesai</b>",
              parseMode: "html",
            });
          } catch (err) {
            console.error(
              "Gagal mengirim notifikasi user:",
              err.message
            );
          }

          return;
        }

        // ==================================================
        // /delrequest <id>
        // ==================================================

        if (/^\/delrequest(?:@\w+)?(?:\s|$)/i.test(text)) {

          if (!isOwner(userId)) {
            await message.reply({
              message: "❌ Kamu tidak punya akses.",
            });

            return;
          }

          const idText = text
            .replace(/^\/delrequest(?:@\w+)?/i, "")
            .trim();

          const id = Number(idText);

          if (!Number.isInteger(id) || id <= 0) {
            await message.reply({
              message:
                "❌ <b>Format salah!</b>\n\n" +
                "Gunakan:\n" +
                "<code>/delrequest 1</code>",
              parseMode: "html",
            });

            return;
          }

          const requests = loadRequests();

          const index = requests.findIndex(
            (request) => Number(request.id) === id
          );

          if (index === -1) {
            await message.reply({
              message:
                `❌ Request dengan ID <code>${id}</code> tidak ditemukan.`,
              parseMode: "html",
            });

            return;
          }

          const deleted = requests[index];

          requests.splice(index, 1);

          saveRequests(requests);

          await message.reply({
            message:
              "🗑️ <b>REQUEST DIHAPUS!</b>\n\n" +
              `🆔 ID: <code>${id}</code>\n` +
              `👤 ${escapeHTML(deleted.username)}\n` +
              `📝 ${escapeHTML(deleted.request)}`,
            parseMode: "html",
          });

          return;
        }

      } catch (err) {

        console.error(
          "❌ Request Plugin Error:",
          err
        );

        try {
          await event.message.reply({
            message:
              "❌ Terjadi error saat memproses request.",
          });
        } catch {}
      }
    },

    new NewMessage({
      incoming: true,
    })
  );
};