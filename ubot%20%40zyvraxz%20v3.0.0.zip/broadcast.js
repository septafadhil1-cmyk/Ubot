// broadcast.js
const fs = require("fs");
const path = require("path");

const DATA_FILE = path.join(__dirname, "broadcast-users.json");

function loadUsers() {
  try {
    if (!fs.existsSync(DATA_FILE)) return [];

    const data = JSON.parse(
      fs.readFileSync(DATA_FILE, "utf8")
    );

    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function saveUsers(users) {
  fs.writeFileSync(
    DATA_FILE,
    JSON.stringify([...new Set(users)], null, 2)
  );
}

// Daftarkan user yang pernah /start
function registerUser(userId) {
  const users = loadUsers();

  if (!users.includes(userId)) {
    users.push(userId);
    saveUsers(users);
  }
}

// Pasang fitur broadcast
function setupBroadcast(bot, ownerId) {

  // /start
  bot.start(async (ctx) => {
    registerUser(ctx.from.id);

    await ctx.reply(
      "🤖 Bot aktif!\n\n" +
      "Gunakan /broadcast <pesan>"
    );
  });

  // /broadcast pesan
  bot.command("broadcast", async (ctx) => {

    // Cek owner
    if (String(ctx.from.id) !== String(ownerId)) {
      return ctx.reply("❌ Kamu tidak punya akses.");
    }

    const message = ctx.message.text
      .replace(/^\/broadcast(?:@\w+)?\s*/i, "")
      .trim();

    if (!message) {
      return ctx.reply(
        "❌ Format salah.\n\n" +
        "Contoh:\n" +
        "/broadcast Halo semuanya 👋"
      );
    }

    const users = loadUsers();

    if (users.length === 0) {
      return ctx.reply(
        "⚠️ Belum ada user yang terdaftar."
      );
    }

    let success = 0;
    let failed = 0;

    const status = await ctx.reply(
      `📢 Broadcast dimulai...\n` +
      `👥 Target: ${users.length}`
    );

    for (const userId of users) {
      try {
        await bot.telegram.sendMessage(
          userId,
          message
        );

        success++;
      } catch (err) {
        failed++;
      }

      // Delay 1 detik
      await new Promise(resolve =>
        setTimeout(resolve, 1000)
      );
    }

    await ctx.telegram.editMessageText(
      ctx.chat.id,
      status.message_id,
      undefined,
      `✅ Broadcast selesai!\n\n` +
      `📨 Berhasil: ${success}\n` +
      `❌ Gagal: ${failed}`
    );
  });
}

module.exports = {
  setupBroadcast,
  registerUser
};