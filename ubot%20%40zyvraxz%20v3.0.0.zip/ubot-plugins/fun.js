const _fmt = require("./_format");
const PREFIX = process.env.PREFIX || ".";

function esc(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

async function reply(event, html) {
  return _fmt.reply(event, html);
}

module.exports.commands = [
  {
    name: "say",
    description: "Buat bot mengucapkan sesuatu",
    usage: ".say <teks>",
    category: "Fun",
    handler: async (event, args) => {
      if (!args.length) return reply(event, `❌ Contoh: <code>.say Halo semua!</code>`);
      return reply(event, esc(args.join(" ")));
    },
  },
  {
    name: "reverse",
    description: "Balik teks yang kamu tulis",
    usage: ".reverse <teks>",
    category: "Fun",
    handler: async (event, args) => {
      if (!args.length) return reply(event, `❌ Contoh: <code>.reverse halo dunia</code>`);
      const reversed = args.join(" ").split("").reverse().join("");
      return reply(event, `🔄 <b>Reversed:</b>\n${esc(reversed)}`);
    },
  },
  {
    name: "upper",
    description: "Ubah teks jadi HURUF BESAR semua",
    usage: ".upper <teks>",
    category: "Fun",
    handler: async (event, args) => {
      if (!args.length) return reply(event, `❌ Contoh: <code>.upper halo dunia</code>`);
      return reply(event, esc(args.join(" ").toUpperCase()));
    },
  },
  {
    name: "lower",
    description: "Ubah teks jadi huruf kecil semua",
    usage: ".lower <teks>",
    category: "Fun",
    handler: async (event, args) => {
      if (!args.length) return reply(event, `❌ Contoh: <code>.lower HALO DUNIA</code>`);
      return reply(event, esc(args.join(" ").toLowerCase()));
    },
  },
  {
    name: "count",
    description: "Hitung jumlah karakter dalam teks",
    usage: ".count <teks>",
    category: "Utilitas",
    handler: async (event, args) => {
      if (!args.length) return reply(event, `❌ Contoh: <code>.count halo dunia</code>`);
      const text = args.join(" ");
      return reply(event,
        `📊 <b>Statistik Teks</b>\n\n` +
        `Karakter: <code>${text.length}</code>\n` +
        `Kata: <code>${args.length}</code>\n` +
        `Spasi: <code>${(text.match(/ /g) || []).length}</code>`
      );
    },
  },
];
