// ─────────────────────────────────────────
//  Plugin: TTS (Text to Speech)
//   • .tts {pesan}/(reply)     → suara via Groq, model Orpheus English (UTAMA)
//   • .ttsagus {pesan}/(reply) → suara via ElevenLabs (voice "Agus"), model Eleven v3
//
//  .tts butuh GROQ_API_KEY. .ttsagus butuh ELEVENLABS_API_KEY.
//  Keduanya bisa dipakai terpisah (ttsagus tetap jalan walau groq berfungsi).
// ─────────────────────────────────────────
const _fmt = require("./_format");
const { Api } = require("telegram");
const fs = require("fs");
const os = require("os");
const path = require("path");

// ── Groq Orpheus (English) ──
const GROQ_TTS_URL = "https://api.groq.com/openai/v1/audio/speech";
const ORPHEUS_MODEL = "canopylabs/orpheus-v1-english";
const ORPHEUS_VOICE = "troy"; // salah satu dari 6 voice English Orpheus

// ── ElevenLabs (Agus) ──
const ELEVEN_BASE = "https://api.elevenlabs.io/v1/text-to-speech";
const ELEVEN_VOICE_ID = "GrxM8OEUWBzyFR2xP2Qd"; // voice "Agus"
const ELEVEN_MODEL = "eleven_v3";                // selalu V3
// Setting sesuai permintaan: Stability = Creative (paling kiri = 0.0), style 0, output MP3 44.1kHz 128kbps.
// Catatan: untuk v3, stability harus salah satu dari 0.0 / 0.5 / 1.0 → Creative = 0.0
const ELEVEN_OUTPUT_FORMAT = "mp3_44100_128";

// Ambil teks dari args atau pesan yang di-reply
async function getText(event, args) {
  let t = args.join(" ").trim();
  if (!t && event.message.replyTo) {
    try { const r = await event.message.getReplyMessage(); t = (r?.text || r?.message || "").trim(); } catch {}
  }
  return t;
}

// Kirim buffer audio sebagai voice note Telegram
async function sendVoice(client, peerId, replyToId, buf, ext) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "ubottts_"));
  const file = path.join(tmpDir, "voice." + ext);
  fs.writeFileSync(file, buf);
  try {
    await client.sendFile(peerId, {
      file,
      replyTo: replyToId,
      voiceNote: true, // kirim sebagai voice note (bisa diputar langsung)
      attributes: [
        new Api.DocumentAttributeAudio({
          voice: true,
          duration: 0,
        }),
      ],
    });
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

module.exports.commands = [
  // ── .tts (Groq Orpheus English) ──
  {
    name: "tts",
    description: "Teks jadi suara (Groq, Orpheus English). .tts <pesan> atau reply pesan — butuh GROQ_API_KEY",
    category: "AI",
    handler: async (event, args, ctx) => {
      const key = process.env.GROQ_API_KEY;
      if (!key) return _fmt.reply(event,
        `🔑 <b>Fitur TTS belum aktif</b>\n\nButuh <code>GROQ_API_KEY</code> di <code>gwajib.env</code>.\nDaftar: https://console.groq.com/keys`);
      let text = await getText(event, args);
      if (!text) return _fmt.reply(event, `❌ Format: <code>.tts halo apa kabar</code> atau reply pesan lalu <code>.tts</code>`);
      // Orpheus batas 200 karakter
      if (text.length > 200) text = text.slice(0, 200);

      let thinking;
      try { thinking = await event.message.reply({ message: `<blockquote><b>🔊 Membuat suara...</b></blockquote>`, parseMode: "html" }); } catch {}

      try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 60000);
        let res;
        try {
          res = await fetch(GROQ_TTS_URL, {
            method: "POST", signal: ctrl.signal,
            headers: { "Content-Type": "application/json", "Authorization": "Bearer " + key },
            body: JSON.stringify({ model: ORPHEUS_MODEL, voice: ORPHEUS_VOICE, input: text, response_format: "wav" }),
          });
        } finally { clearTimeout(t); }

        if (!res.ok) {
          let msg = "HTTP " + res.status;
          try { const j = await res.json(); msg = j?.error?.message || msg; } catch {}
          throw new Error(msg);
        }
        const buf = Buffer.from(await res.arrayBuffer());
        if (!buf.length) throw new Error("Audio kosong.");

        await sendVoice(ctx.client, event.message.peerId, event.message.id, buf, "wav");
        if (thinking) { try { await thinking.delete(); } catch {} }
      } catch (e) {
        const err = `<blockquote><b>❌ Gagal: ${_fmt.esc(e.message)}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); return; } catch {} }
        return event.message.reply({ message: err, parseMode: "html" });
      }
    },
  },

  // ── .ttsagus (ElevenLabs, voice Agus, Eleven v3) ──
  {
    name: "ttsagus",
    description: "Teks jadi suara via ElevenLabs (voice Agus, V3). .ttsagus <pesan> atau reply — butuh ELEVENLABS_API_KEY",
    category: "AI",
    handler: async (event, args, ctx) => {
      const key = process.env.ELEVENLABS_API_KEY;
      if (!key) return _fmt.reply(event,
        `🔑 <b>Fitur TTS Agus belum aktif</b>\n\nButuh <code>ELEVENLABS_API_KEY</code> di <code>gwajib.env</code>.\nDaftar: https://elevenlabs.io/app/settings/api-keys`);
      const text = await getText(event, args);
      if (!text) return _fmt.reply(event, `❌ Format: <code>.ttsagus halo apa kabar</code> atau reply pesan lalu <code>.ttsagus</code>`);
      if (text.length > 1000) return _fmt.reply(event, `❌ Teks kepanjangan (maks 1000 karakter).`);

      let thinking;
      try { thinking = await event.message.reply({ message: `<blockquote><b>🔊 Membuat suara (Agus / V3)...</b></blockquote>`, parseMode: "html" }); } catch {}

      try {
        const url = `${ELEVEN_BASE}/${ELEVEN_VOICE_ID}?output_format=${ELEVEN_OUTPUT_FORMAT}`;
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 90000);
        let res;
        try {
          res = await fetch(url, {
            method: "POST", signal: ctrl.signal,
            headers: { "xi-api-key": key, "Content-Type": "application/json", "Accept": "audio/mpeg" },
            body: JSON.stringify({
              text,
              model_id: ELEVEN_MODEL,                 // eleven_v3
              apply_text_normalization: "auto",       // "V3 Enhance"
              voice_settings: {
                stability: 0.0,                       // Creative (paling kiri)
                similarity_boost: 0.75,
                style: 0.0,
                use_speaker_boost: false,             // v3 ga support speaker boost
              },
            }),
          });
        } finally { clearTimeout(t); }

        if (!res.ok) {
          let msg = "HTTP " + res.status;
          try { const j = await res.json(); msg = j?.detail?.message || j?.detail || j?.message || msg; if (typeof msg === "object") msg = JSON.stringify(msg); } catch {}
          throw new Error(msg);
        }
        const buf = Buffer.from(await res.arrayBuffer());
        if (!buf.length) throw new Error("Audio kosong.");

        await sendVoice(ctx.client, event.message.peerId, event.message.id, buf, "mp3");
        if (thinking) { try { await thinking.delete(); } catch {} }
      } catch (e) {
        const err = `<blockquote><b>❌ Gagal: ${_fmt.esc(e.message)}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); return; } catch {} }
        return event.message.reply({ message: err, parseMode: "html" });
      }
    },
  },
];
