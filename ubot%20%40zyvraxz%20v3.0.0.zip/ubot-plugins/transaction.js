// ─────────────────────────────────────────
//  Plugin: Struk Transaksi
//  .done produk,harga,pembayaran                 → struk LUNAS (+ kartu gambar)
//  .dp produk,harga asli,baru dibayar,pembayaran → struk HUTANG (+ kartu gambar)
//  .trx <nomor>                                   → tampilkan ulang struk by nomor TRX
//  Catatan: ubot TIDAK bisa screenshot layar. "Foto" = kartu struk yang dirender.
// ─────────────────────────────────────────

const _fmt = require("./_format");
const trxStore = require("../lib/trxStore");
const { createCanvas } = require("@napi-rs/canvas");
const fs = require("fs");
const path = require("path");
const os = require("os");

function nowWIB() {
  const d = new Date(Date.now() + 7 * 3600 * 1000);
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}-${p(d.getUTCMonth() + 1)}-${p(d.getUTCDate())} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}`;
}

async function ownerName(client) {
  try {
    const me = await client.getMe();
    if (me.username) return "@" + me.username;
    return me.firstName || "Owner";
  } catch { return "Owner"; }
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

// Render kartu struk → buffer PNG
function renderReceiptCard({ title, rows, status, statusOk, owner }) {
  const W = 720;
  const topH = 150;
  const rowH = 46;
  const H = topH + rows.length * rowH + 130;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  // BG
  ctx.fillStyle = "#0f1620";
  roundRect(ctx, 0, 0, W, H, 30); ctx.fill();

  // Panel dalam
  const accent = statusOk ? "#27c46b" : "#f0941e";
  ctx.fillStyle = "#16202e";
  roundRect(ctx, 24, 24, W - 48, H - 48, 22); ctx.fill();

  // Strip aksen atas
  ctx.fillStyle = accent;
  roundRect(ctx, 24, 24, W - 48, 8, 4); ctx.fill();

  // Lingkaran centang
  const cx = W / 2, cy = 90, rad = 34;
  ctx.fillStyle = accent;
  ctx.beginPath(); ctx.arc(cx, cy, rad, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = "#0f1620"; ctx.lineWidth = 6; ctx.lineCap = "round";
  if (statusOk) {
    ctx.beginPath(); ctx.moveTo(cx - 15, cy + 2); ctx.lineTo(cx - 4, cy + 13); ctx.lineTo(cx + 16, cy - 12); ctx.stroke();
  } else {
    ctx.font = "bold 40px sans-serif"; ctx.fillStyle = "#0f1620"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("!", cx, cy);
  }

  // Judul
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 30px sans-serif";
  ctx.textAlign = "center"; ctx.textBaseline = "top";
  ctx.fillText(title, W / 2, 138);

  // Garis
  ctx.strokeStyle = "#2a3850"; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(60, topH + 28); ctx.lineTo(W - 60, topH + 28); ctx.stroke();

  // Rows
  let y = topH + 44;
  ctx.textBaseline = "middle";
  for (const [label, value] of rows) {
    ctx.textAlign = "left";
    ctx.fillStyle = "#8b9bb4";
    ctx.font = "20px sans-serif";
    ctx.fillText(label, 60, y);
    ctx.textAlign = "right";
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 21px sans-serif";
    // potong value kepanjangan
    let v = String(value);
    if (v.length > 32) v = v.slice(0, 31) + "…";
    ctx.fillText(v, W - 60, y);
    y += rowH;
  }

  // Status badge
  y += 6;
  ctx.textAlign = "center";
  ctx.fillStyle = accent;
  ctx.font = "bold 22px sans-serif";
  ctx.fillText(status, W / 2, y);

  // Footer owner
  ctx.fillStyle = "#6b7a90";
  ctx.font = "18px sans-serif";
  ctx.fillText(`Owner: ${owner}  •  Terima kasih telah bertransaksi`, W / 2, H - 44);

  return canvas.toBuffer("image/png");
}

async function sendReceipt(event, ctx, { textReceipt, card, trx, type }) {
  const msg = event.message;
  const client = ctx.client;

  // Reply ke pesan yang di-reply (proof), bukan ke command
  const replyToId = msg.replyTo?.replyToMsgId || undefined;

  // Kirim kartu (gambar) + caption struk
  let sent = false;
  let sentMsg = null;
  if (card) {
    const tmp = path.join(os.tmpdir(), `trx_${ctx.ownerId}_${trx}_${Date.now()}.png`);
    try {
      fs.writeFileSync(tmp, card);
      sentMsg = await client.sendFile(msg.peerId, {
        file: tmp,
        caption: _fmt.wrap(textReceipt),
        parseMode: "html",
        replyTo: replyToId,
      });
      sent = true;
    } catch (e) {
      console.error("kirim kartu struk gagal:", e.message);
    } finally { try { fs.unlinkSync(tmp); } catch {} }
  }
  // Fallback teks kalau kartu gagal
  if (!sent) {
    sentMsg = await client.sendMessage(msg.peerId, { message: _fmt.wrap(textReceipt), parseMode: "html", replyTo: replyToId });
  }

  // Simpan struk + lokasi pesan (buat .trx lookup & .sharetrx forward)
  try {
    trxStore.saveReceipt(ctx.ownerId, trx, {
      text: textReceipt, type, ts: Date.now(),
      chatId: (msg.chatId != null ? msg.chatId.toString() : null),
      msgId: (sentMsg && sentMsg.id) ? sentMsg.id : null,
    });
  } catch {}

  // Hapus command (.done/.dp) biar ga keliatan
  try { await client.deleteMessages(msg.peerId, [msg.id], { revoke: true }); } catch {}
}

const doneHandler = async (event, args, ctx) => {
  const parts = args.join(" ").split(",").map((s) => s.trim());
  if (parts.length < 3 || !parts[0]) {
    return _fmt.reply(event, `❌ Format: <code>.done produk,harga,pembayaran</code>\nContoh: <code>.done mt unlimper,2k,qris</code>`);
  }
  const [produk, harga, pembayaran] = parts;
  const trx = trxStore.nextTrx(ctx.ownerId);
  const owner = await ownerName(ctx.client);
  const waktu = nowWIB();

  const textReceipt =
    `『 Transaction Successfull 』\n━━━━━━━━━━━━━━━\n` +
    `🛍️ Produk : ${_fmt.esc(produk)}\n🏷️ Harga : Rp${_fmt.esc(harga)}\n💳 Pembayaran : ${_fmt.esc(pembayaran)}\n` +
    `🕐 Waktu : ${waktu} WIB\n🧾 Nomor TRX : TRX-${trx}\n✅ Status : Tercatat & Selesai!\n` +
    `━━━━━━━━━━━━━━━\n👤 Owner : ${_fmt.esc(owner)}\n━━━━━━━━━━━━━━━\n✨ Terima Kasih Telah Bertransaksi ✨ !`;

  let card = null;
  try {
    card = renderReceiptCard({
      title: "TRANSACTION SUCCESSFUL",
      rows: [["Produk", produk], ["Harga", "Rp" + harga], ["Pembayaran", pembayaran], ["Waktu", waktu + " WIB"], ["Nomor TRX", "TRX-" + trx]],
      status: "TERCATAT & SELESAI", statusOk: true, owner,
    });
  } catch (e) { console.error("render done card:", e.message); }

  await sendReceipt(event, ctx, { textReceipt, card, trx, type: "done" });
};

const dpHandler = async (event, args, ctx) => {
  const parts = args.join(" ").split(",").map((s) => s.trim());
  if (parts.length < 4 || !parts[0]) {
    return _fmt.reply(event, `❌ Format: <code>.dp produk,harga asli,baru dibayar,pembayaran</code>\nContoh: <code>.dp mt unlimper,5k,2k,qris</code>`);
  }
  const [produk, hargaAsli, dibayar, pembayaran] = parts;
  const trx = trxStore.nextTrx(ctx.ownerId);
  const owner = await ownerName(ctx.client);
  const waktu = nowWIB();

  const textReceipt =
    `『 Transaction Successfull 』\n━━━━━━━━━━━━━━━\n` +
    `🛍️ Produk : ${_fmt.esc(produk)}\n🏷️ Harga Asli : Rp${_fmt.esc(hargaAsli)}\n💵 Baru Dibayar : ${_fmt.esc(dibayar)}\n💳 Pembayaran : ${_fmt.esc(pembayaran)}\n` +
    `🕐 Waktu : ${waktu} WIB\n🧾 Nomor TRX : TRX-${trx}\n⚠️ Status : Tercatat Masih Hutang!\n` +
    `━━━━━━━━━━━━━━━\n👤 Owner : ${_fmt.esc(owner)}\n━━━━━━━━━━━━━━━\n✨ Terima Kasih Telah Bertransaksi ✨ !`;

  let card = null;
  try {
    card = renderReceiptCard({
      title: "TRANSACTION SUCCESSFUL",
      rows: [["Produk", produk], ["Harga Asli", "Rp" + hargaAsli], ["Baru Dibayar", dibayar], ["Pembayaran", pembayaran], ["Waktu", waktu + " WIB"], ["Nomor TRX", "TRX-" + trx]],
      status: "TERCATAT — MASIH HUTANG", statusOk: false, owner,
    });
  } catch (e) { console.error("render dp card:", e.message); }

  await sendReceipt(event, ctx, { textReceipt, card, trx, type: "dp" });
};

const trxHandler = async (event, args, ctx) => {
  const num = parseInt(args[0]);
  if (isNaN(num)) return _fmt.reply(event, `❌ Format: <code>.trx 31</code> (nomor TRX)`);
  const rec = trxStore.getReceipt(ctx.ownerId, num);
  if (!rec || !rec.text) {
    return _fmt.reply(event, `❌ TRX-${num} tidak ditemukan. Mungkin nomornya salah atau belum pernah dibuat.`);
  }
  // Tampilkan ulang teks struk apa adanya
  return _fmt.reply(event, `🔎 <b>Detail TRX-${num}</b>\n\n${rec.text}`);
};

module.exports.commands = [
  { name: "done", description: "Struk transaksi lunas + kartu (.done produk,harga,pembayaran)", category: "Transaksi", handler: doneHandler },
  { name: "dp", description: "Struk DP/hutang + kartu (.dp produk,harga asli,baru dibayar,pembayaran)", category: "Transaksi", handler: dpHandler },
  { name: "trx", description: "Tampilkan ulang struk by nomor (.trx 31)", category: "Transaksi", handler: trxHandler },
];
