// ─────────────────────────────────────────
//  Plugin: Chat Automation (auto-reply PRIVATE chat, TANPA tanda "terbaca")
//  .chatauto <balas ketika>, <balas dengan>  → balas otomatis kalau ada yang chat kata itu
//     contoh: .chatauto P, uy   → orang pv "P", ubot balas "uy"
//  .chatautoall <balas dengan>  → balas SEMUA pesan pv apa pun isinya
//     contoh: .chatautoall halo! → tiap orang pv, ubot balas "halo!"
//  .chatautooff      → matiin semua rule trigger
//  .chatautoalloff   → matiin mode balas-semua
//  .delchatauto <balas ketika> → hapus 1 rule
//  .listchatauto     → lihat semua rule + status
//
//  Cara kerja "tanpa terbaca": ubot cuma KIRIM pesan balasan, TIDAK pernah manggil
//  readHistory, jadi pesan lawan chat tetap kelihatan belum kebaca (centang ga biru).
//  HANYA jalan di private chat (pv), bukan grup/channel.
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");

const esc = _fmt.esc;

let cache = null; // ownerId(str) → { rules:[{trigger,reply}], all:{enabled,reply} }

async function initChatauto() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("chatauto");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { rules: Array.isArray(d.rules) ? d.rules : [], all: d.all || { enabled: false, reply: "" } };
      }
      console.log(`✅ [db] load chatauto: ${docs.length} user`);
    } catch (e) { console.error("init chatauto:", e.message); }
  }
}

function getConf(ownerId) {
  const id = String(ownerId);
  if (!cache) cache = {};
  if (!cache[id]) cache[id] = { rules: [], all: { enabled: false, reply: "" } };
  return cache[id];
}
function saveConf(ownerId) {
  const id = String(ownerId);
  store.upsert("chatauto", id, cache[id]).catch(() => {});
}

// Anti-flood ringan: jeda min antar balasan ke chat yang sama
const lastReply = new Map(); // `${ownerId}:${chatId}` → ts
const MIN_GAP = 600;

// Dipanggil ubotManager buat tiap pesan MASUK (bukan dari diri sendiri).
// return true kalau udah dibalas (biar handler lain berhenti).
async function handleIncoming(event, { client, ownerId, me, senderId }) {
  try {
    if (!event.isPrivate) return false;            // cuma private chat
    const msg = event.message;
    if (!msg || !msg.text) return false;
    if (!senderId || senderId === me.id.toString()) return false; // jangan balas diri sendiri
    if (senderId === "777000") return false;       // service Telegram

    const conf = cache && cache[String(ownerId)];
    if (!conf) return false;

    const text = msg.text.trim();
    let replyText = null;

    // Mode balas-semua menang duluan
    if (conf.all && conf.all.enabled && conf.all.reply) {
      replyText = conf.all.reply;
    } else if (conf.rules && conf.rules.length) {
      const rule = conf.rules.find((r) => r.trigger.toLowerCase() === text.toLowerCase());
      if (rule) replyText = rule.reply;
    }
    if (!replyText) return false;

    // Cooldown per chat
    const key = `${ownerId}:${msg.chatId || senderId}`;
    const now = Date.now();
    if (now - (lastReply.get(key) || 0) < MIN_GAP) return true; // di-skip tapi tetap "handled"
    lastReply.set(key, now);

    // KIRIM plain (tanpa reply, tanpa readHistory) → ga bikin tanda terbaca
    await client.sendMessage(msg.peerId, { message: replyText });
    return true;
  } catch (e) {
    console.error("chatauto handleIncoming:", e.message);
    return false;
  }
}

// Ringkasan status buat ditampilin
function statusText(ownerId) {
  const conf = getConf(ownerId);
  const lines = [`🤖 <b>Chat Automation</b>`, `⏣────────────────⏣\n`];
  lines.push(`Balas semua: <b>${conf.all && conf.all.enabled ? `AKTIF → "${esc(conf.all.reply)}"` : "nonaktif"}</b>`);
  if (conf.rules && conf.rules.length) {
    lines.push(`\nRule trigger (${conf.rules.length}):`);
    for (const r of conf.rules) lines.push(`• "${esc(r.trigger)}" → "${esc(r.reply)}"`);
  } else {
    lines.push(`\nBelum ada rule trigger.`);
  }
  lines.push(`\n<i>Cuma jalan di private chat & tanpa tanda terbaca.</i>`);
  return lines.join("\n");
}

module.exports.initChatauto = initChatauto;
module.exports.handleIncoming = handleIncoming;
module.exports.getConf = getConf;

module.exports.commands = [
  {
    name: "chatauto",
    description: "Auto-balas pv saat ada trigger: .chatauto <balas ketika>, <balas dengan>",
    category: "Auto Reply",
    handler: async (event, args, ctx) => {
      const raw = args.join(" ").trim();
      if (!raw) {
        // tanpa argumen → tampilkan status
        return _fmt.reply(event, statusText(ctx.ownerId));
      }
      const ci = raw.indexOf(",");
      if (ci === -1) {
        return _fmt.reply(event,
          `❌ Format: <code>.chatauto &lt;balas ketika&gt;, &lt;balas dengan&gt;</code>\n\n` +
          `Contoh: <code>.chatauto P, uy</code> → ada yang pv "P", dibalas "uy".`);
      }
      const trigger = raw.slice(0, ci).trim();
      const reply = raw.slice(ci + 1).trim();
      if (!trigger || !reply) {
        return _fmt.reply(event, `❌ Trigger & balasan tidak boleh kosong. Contoh: <code>.chatauto P, uy</code>`);
      }
      const conf = getConf(ctx.ownerId);
      const existing = conf.rules.find((r) => r.trigger.toLowerCase() === trigger.toLowerCase());
      if (existing) existing.reply = reply;
      else conf.rules.push({ trigger, reply });
      saveConf(ctx.ownerId);
      return _fmt.reply(event,
        `✅ <b>Chat auto diset!</b>\n\n` +
        `balas ketika: <b>${esc(trigger)}</b>\n` +
        `balas dengan: <b>${esc(reply)}</b>\n\n` +
        `<i>Bekerja di private chat, tanpa bikin tanda terbaca.</i>`);
    },
  },
  {
    name: "chatautoall",
    description: "Auto-balas SEMUA pesan pv apa pun isinya: .chatautoall <balas dengan>",
    category: "Auto Reply",
    handler: async (event, args, ctx) => {
      const reply = args.join(" ").trim();
      if (!reply) {
        return _fmt.reply(event,
          `❌ Format: <code>.chatautoall &lt;balas dengan&gt;</code>\n\n` +
          `Contoh: <code>.chatautoall halo!</code> → tiap orang pv, dibalas "halo!".`);
      }
      const conf = getConf(ctx.ownerId);
      conf.all = { enabled: true, reply };
      saveConf(ctx.ownerId);
      return _fmt.reply(event,
        `✅ <b>Balas-semua aktif!</b>\n\n` +
        `Tiap pesan pv bakal dibalas: <b>${esc(reply)}</b>\n\n` +
        `<i>Matikan pakai <code>.chatautoalloff</code>.</i>`);
    },
  },
  {
    name: "chatautooff",
    description: "Matikan semua rule trigger chat auto",
    category: "Auto Reply",
    handler: async (event, args, ctx) => {
      const conf = getConf(ctx.ownerId);
      const n = conf.rules.length;
      conf.rules = [];
      saveConf(ctx.ownerId);
      return _fmt.reply(event, `🛑 <b>${n} rule trigger dihapus.</b>\n<i>Mode balas-semua (kalau aktif) masih jalan — matikan pakai .chatautoalloff.</i>`);
    },
  },
  {
    name: "chatautoalloff",
    description: "Matikan mode balas-semua chat auto",
    category: "Auto Reply",
    handler: async (event, args, ctx) => {
      const conf = getConf(ctx.ownerId);
      conf.all = { enabled: false, reply: "" };
      saveConf(ctx.ownerId);
      return _fmt.reply(event, `🛑 <b>Mode balas-semua dimatikan.</b>`);
    },
  },
  {
    name: "delchatauto",
    description: "Hapus 1 rule trigger: .delchatauto <balas ketika>",
    category: "Auto Reply",
    handler: async (event, args, ctx) => {
      const trigger = args.join(" ").trim();
      if (!trigger) return _fmt.reply(event, `❌ Format: <code>.delchatauto &lt;balas ketika&gt;</code>`);
      const conf = getConf(ctx.ownerId);
      const before = conf.rules.length;
      conf.rules = conf.rules.filter((r) => r.trigger.toLowerCase() !== trigger.toLowerCase());
      if (conf.rules.length === before) return _fmt.reply(event, `❌ Rule "${esc(trigger)}" tidak ditemukan.`);
      saveConf(ctx.ownerId);
      return _fmt.reply(event, `🗑 Rule "<b>${esc(trigger)}</b>" dihapus.`);
    },
  },
  {
    name: "listchatauto",
    description: "Lihat semua rule chat auto + status",
    category: "Auto Reply",
    handler: async (event, args, ctx) => {
      return _fmt.reply(event, statusText(ctx.ownerId));
    },
  },
];
