// ─────────────────────────────────────────
//  Plugin: Prefix — ubah / matikan prefix command ubot
//  .prefix !        → ganti prefix jadi !
//  .prefix          → balik ke default (.)
//  .prefix off      → mode NO-PREFIX (ketik command tanpa awalan)
//  .noprefix        → toggle on/off mode no-prefix
// ─────────────────────────────────────────

const _fmt = require("./_format");
const prefixStore = require("../lib/prefixStore");

const OFF_WORDS = ["off", "none", "kosong", "hapus", "no", "0"];

function noPrefixWarn() {
  return (
    `✅ <b>Mode NO-PREFIX aktif!</b>\n\n` +
    `Sekarang command diketik <b>tanpa awalan</b>.\n` +
    `Contoh: ketik <code>help</code> (bukan <code>.help</code>)\n\n` +
    `⚠️ <i>Hati-hati: tiap pesanmu yang diawali nama command bakal otomatis jalan ` +
    `(misal nulis "id ..." bakal micu command id).</i>\n\n` +
    `<i>Matiin lagi: ketik <code>noprefix</code> atau <code>prefix .</code></i>`
  );
}

module.exports.commands = [
  {
    name: "prefix",
    description: "Ubah prefix ubot (.prefix ! / .prefix = reset / .prefix off = no-prefix)",
    category: "Utilitas",
    handler: async (event, args, ctx) => {
      const ownerId = ctx.ownerId;
      const newPrefix = (args[0] || "").trim();

      // Tanpa argumen → reset ke default
      if (!newPrefix) {
        prefixStore.setPrefix(ownerId, ".");
        return _fmt.reply(event,
          `↩️ <b>Prefix direset ke default!</b>\n\n` +
          `Prefix sekarang: <code>.</code>\n` +
          `Contoh: <code>.help</code>`
        );
      }

      // Argumen "off"/"none"/dll → no-prefix
      if (OFF_WORDS.includes(newPrefix.toLowerCase())) {
        prefixStore.setPrefix(ownerId, "");
        return _fmt.reply(event, noPrefixWarn());
      }

      if (newPrefix.length > 3) {
        return _fmt.reply(event, `❌ Prefix maksimal 3 karakter.`);
      }
      if (/\s/.test(newPrefix)) {
        return _fmt.reply(event, `❌ Prefix tidak boleh ada spasi.`);
      }

      prefixStore.setPrefix(ownerId, newPrefix);
      return _fmt.reply(event,
        `✅ <b>Prefix diubah!</b>\n\n` +
        `Prefix sekarang: <code>${_fmt.esc(newPrefix)}</code>\n` +
        `Contoh: <code>${_fmt.esc(newPrefix)}help</code>\n\n` +
        `<i>Reset ke default: ketik <code>${_fmt.esc(newPrefix)}prefix</code></i>`
      );
    },
  },
  {
    name: "noprefix",
    description: "Aktif/matikan mode no-prefix (command tanpa awalan)",
    category: "Utilitas",
    handler: async (event, args, ctx) => {
      const ownerId = ctx.ownerId;
      // Toggle: kalau lagi no-prefix → balik default, kalau bukan → aktifkan
      if (prefixStore.isNoPrefix(ownerId)) {
        prefixStore.setPrefix(ownerId, ".");
        return _fmt.reply(event,
          `↩️ <b>Mode no-prefix dimatikan.</b>\n\n` +
          `Prefix balik ke <code>.</code>\n` +
          `Contoh: <code>.help</code>`
        );
      }
      prefixStore.setPrefix(ownerId, "");
      return _fmt.reply(event, noPrefixWarn());
    },
  },
];
