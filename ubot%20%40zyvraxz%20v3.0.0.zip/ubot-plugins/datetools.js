// ─────────────────────────────────────────
//  Plugin: Date & Time tools (offline, REAL)
// ─────────────────────────────────────────

const _fmt = require("./_format");

const commands = [
  { name: "timestamp", description: "Unix timestamp sekarang", category: "Utilitas",
    handler: e => _fmt.reply(e, `⏱️ Timestamp: <code>${Math.floor(Date.now()/1000)}</code>\nMillis: <code>${Date.now()}</code>`) },
  { name: "totimestamp", description: "Tanggal ke timestamp (.totimestamp 2024-01-01)", category: "Utilitas",
    handler: (e, a) => { const d = new Date(a.join(" ")); if (isNaN(d)) return _fmt.reply(e, `❌ Format: <code>.totimestamp 2024-01-01</code>`); return _fmt.reply(e, `⏱️ <code>${Math.floor(d.getTime()/1000)}</code>`); } },
  { name: "fromtimestamp", description: "Timestamp ke tanggal (.fromtimestamp 1700000000)", category: "Utilitas",
    handler: (e, a) => { const ts = parseInt(a[0]); if (isNaN(ts)) return _fmt.reply(e, `❌ Masukkan timestamp.`); const d = new Date(ts * (ts < 1e12 ? 1000 : 1)); return _fmt.reply(e, `📅 ${d.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })} WIB`); } },
  { name: "datediff", description: "Selisih 2 tanggal (.datediff 2024-01-01 2024-12-31)", category: "Utilitas",
    handler: (e, a) => { const d1 = new Date(a[0]), d2 = new Date(a[1]); if (isNaN(d1)||isNaN(d2)) return _fmt.reply(e, `❌ Format: <code>.datediff 2024-01-01 2024-12-31</code>`); const days = Math.abs(Math.round((d2-d1)/86400000)); return _fmt.reply(e, `📅 Selisih: <b>${days} hari</b> (${(days/365).toFixed(1)} tahun)`); } },
  { name: "age", description: "Hitung umur (.age 2000-05-15)", category: "Utilitas",
    handler: (e, a) => { const d = new Date(a[0]); if (isNaN(d)) return _fmt.reply(e, `❌ Format: <code>.age 2000-05-15</code>`); const ms = Date.now()-d.getTime(); const yr = Math.floor(ms/31557600000); const days = Math.floor(ms/86400000); return _fmt.reply(e, `🎂 Umur: <b>${yr} tahun</b> (${days.toLocaleString()} hari)`); } },
  { name: "dayofweek", description: "Hari apa tanggal tertentu (.dayofweek 2024-01-01)", category: "Utilitas",
    handler: (e, a) => { const d = new Date(a.join(" ")); if (isNaN(d)) return _fmt.reply(e, `❌ Format: <code>.dayofweek 2024-01-01</code>`); const hari = ["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"]; return _fmt.reply(e, `📅 ${a.join(" ")} = <b>${hari[d.getDay()]}</b>`); } },
  { name: "countdown", description: "Hitung mundur ke tanggal (.countdown 2025-01-01)", category: "Utilitas",
    handler: (e, a) => { const d = new Date(a.join(" ")); if (isNaN(d)) return _fmt.reply(e, `❌ Format: <code>.countdown 2025-12-31</code>`); const ms = d.getTime()-Date.now(); if (ms < 0) return _fmt.reply(e, `⏰ Tanggal sudah lewat.`); const days = Math.floor(ms/86400000); const hours = Math.floor((ms%86400000)/3600000); return _fmt.reply(e, `⏳ <b>${days} hari ${hours} jam</b> lagi menuju ${a.join(" ")}`); } },
  { name: "worldtime", description: "Jam di kota dunia (.worldtime Tokyo)", category: "Utilitas",
    handler: (e, a) => { const tz = { jakarta:"Asia/Jakarta", tokyo:"Asia/Tokyo", london:"Europe/London", newyork:"America/New_York", dubai:"Asia/Dubai", sydney:"Australia/Sydney", paris:"Europe/Paris", mekah:"Asia/Riyadh", makkah:"Asia/Riyadh" }; const z = tz[(a[0]||"jakarta").toLowerCase()]; if (!z) return _fmt.reply(e, `❌ Kota: ${Object.keys(tz).join(", ")}`); const t = new Date().toLocaleString("id-ID", { timeZone: z }); return _fmt.reply(e, `🕐 <b>${a[0]}</b>: ${t}`); } },
];

module.exports.commands = commands;
