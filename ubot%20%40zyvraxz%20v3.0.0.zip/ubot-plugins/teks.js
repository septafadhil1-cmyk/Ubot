// ─────────────────────────────────────────
//  Plugin: Teks Cepat (quick-reply snippets) — tersimpan permanen per ubot
//  .setteks <nama> <isi>   → simpan teks (atau reply pesan buat ambil isinya)
//  .teks <nama>            → kirim teks tersimpan (jadi pesan biasa)
//  .daftarteks            → daftar semua nama teks
//  .hapusteks <nama>      → hapus 1 teks
//  .cariteks <kata>       → cari teks by nama/isi
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");
const esc = _fmt.esc;

let cache = null; // ownerId(str) → { items: { name: content } }

async function initTeks() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("teks");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { items: d.items || {} };
      }
      console.log(`✅ [db] load teks: ${docs.length} user`);
    } catch (e) { console.error("init teks:", e.message); }
  }
}
function get(ownerId) { const id = String(ownerId); if (!cache) cache = {}; if (!cache[id]) cache[id] = { items: {} }; return cache[id]; }
function save(ownerId) { store.upsert("teks", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

module.exports.initTeks = initTeks;
module.exports.commands = [
  {
    name: "setteks", description: "Simpan teks cepat: .setteks <nama> <isi> (atau reply pesan)", category: "Teks Cepat",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      if (!name) return _fmt.reply(event, `❌ Format: <code>.setteks &lt;nama&gt; &lt;isi&gt;</code>`);
      let content = args.slice(1).join(" ").trim();
      if (!content && event.message.replyTo) {
        try { const r = await event.message.getReplyMessage(); content = (r && (r.text || r.message)) || ""; } catch {}
      }
      if (!content) return _fmt.reply(event, `❌ Isi teks kosong. Kasih isi atau reply pesan.`);
      const t = get(ctx.ownerId);
      t.items[name] = content;
      save(ctx.ownerId);
      return _fmt.reply(event, `✅ Teks "<b>${esc(name)}</b>" tersimpan. Panggil pakai <code>.teks ${esc(name)}</code>.`);
    },
  },
  {
    name: "teks", description: "Kirim teks tersimpan: .teks <nama>", category: "Teks Cepat",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      const t = get(ctx.ownerId);
      if (!name || !t.items[name]) return _fmt.reply(event, `❌ Teks "${esc(name || "-")}" ga ada. Lihat <code>.daftarteks</code>.`);
      // kirim sebagai pesan biasa (bukan blockquote) biar natural
      try { await ctx.client.sendMessage(event.message.peerId, { message: t.items[name] }); } catch {}
    },
  },
  {
    name: "daftarteks", description: "Daftar semua teks cepat", category: "Teks Cepat",
    handler: async (event, args, ctx) => {
      const t = get(ctx.ownerId);
      const names = Object.keys(t.items);
      if (!names.length) return _fmt.reply(event, `📄 Belum ada teks. Simpan pakai <code>.setteks</code>.`);
      return _fmt.reply(event, `📄 <b>Teks Cepat</b> (${names.length})\n\n` + names.map((n) => `• <code>${esc(n)}</code>`).join("\n"));
    },
  },
  {
    name: "hapusteks", description: "Hapus teks: .hapusteks <nama>", category: "Teks Cepat",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      const t = get(ctx.ownerId);
      if (!name || !t.items[name]) return _fmt.reply(event, `❌ Teks "${esc(name || "-")}" ga ada.`);
      delete t.items[name];
      save(ctx.ownerId);
      return _fmt.reply(event, `🗑 Teks "<b>${esc(name)}</b>" dihapus.`);
    },
  },
  {
    name: "cariteks", description: "Cari teks by nama/isi: .cariteks <kata>", category: "Teks Cepat",
    handler: async (event, args, ctx) => {
      const q = args.join(" ").toLowerCase().trim();
      if (!q) return _fmt.reply(event, `❌ Format: <code>.cariteks &lt;kata&gt;</code>`);
      const t = get(ctx.ownerId);
      const hits = Object.entries(t.items).filter(([n, c]) => n.includes(q) || String(c).toLowerCase().includes(q));
      if (!hits.length) return _fmt.reply(event, `🔍 Ga ada teks yang cocok "<b>${esc(q)}</b>".`);
      return _fmt.reply(event, `🔍 <b>Hasil "${esc(q)}"</b> (${hits.length})\n\n` + hits.map(([n, c]) => `• <code>${esc(n)}</code> — ${esc(String(c).slice(0, 40))}${String(c).length > 40 ? "…" : ""}`).join("\n"));
    },
  },
];
