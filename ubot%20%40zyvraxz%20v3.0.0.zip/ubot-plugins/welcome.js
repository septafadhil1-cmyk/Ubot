// ─────────────────────────────────────────
//  Plugin: Welcome Message (multi-user / per-ownerId)
//  .setwelcome <pesan>  → set welcome (pakai {name} & {group})
//  .welcome on/off      → aktif/matikan
//  .welcome             → status
//  Data per ownerId: { ownerId: { chatId: {enabled, message} } }
// ─────────────────────────────────────────
const _fmt = require("./_format");

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "welcome_data.json");

function loadDB() {
  try { return JSON.parse(fs.readFileSync(DB_PATH, "utf8")); } catch { return {}; }
}
function saveDB(db) {
  try { fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2)); } catch (e) { console.error("wc save:", e.message); }
}
// Config welcome untuk 1 owner di 1 chat
function getConf(ownerId, chatId) {
  const db = loadDB();
  return db[ownerId]?.[chatId] || null;
}
function setConf(ownerId, chatId, conf) {
  const db = loadDB();
  if (!db[ownerId]) db[ownerId] = {};
  db[ownerId][chatId] = conf;
  saveDB(db);
}

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
async function reply(event, html) {
  return _fmt.reply(event, html);
}

// Export untuk handler join di ubotManager
module.exports.getConf = getConf;
module.exports.esc = esc;

module.exports.commands = [
  {
    name: "setwelcome",
    description: "Set pesan sambutan member baru ({name}, {group})",
      category: "Grup",
    handler: async (event, args, ctx) => {
      const msg = event.message;
      const chat = await msg.getChat();
      const isGroup = chat?.className === "Channel" || chat?.className === "Chat";
      if (!isGroup) return reply(event, `❌ Command ini hanya bisa dipakai di grup.`);

      const text = args.join(" ");
      if (!text) {
        return reply(event,
          `❌ <b>Cara pakai:</b>\n\n<code>.setwelcome Selamat datang {name} di {group}!</code>\n\n` +
          `<b>Placeholder:</b>\n• <code>{name}</code> → nama member\n• <code>{group}</code> → nama grup`
        );
      }
      setConf(ctx.ownerId, chat.id.toString(), { enabled: true, message: text });
      return reply(event,
        `✅ <b>Welcome Message Diset!</b>\n\n<b>Pesan:</b>\n${esc(text)}\n\n` +
        `<i>Aktif otomatis. Matikan dengan <code>.welcome off</code></i>`
      );
    },
  },
  {
    name: "welcome",
    description: "Aktif/matikan atau lihat status welcome",
      category: "Grup",
    handler: async (event, args, ctx) => {
      const msg = event.message;
      const chat = await msg.getChat();
      const isGroup = chat?.className === "Channel" || chat?.className === "Chat";
      if (!isGroup) return reply(event, `❌ Command ini hanya bisa dipakai di grup.`);

      const chatId = chat.id.toString();
      const conf = getConf(ctx.ownerId, chatId);
      const opt = (args[0] || "").toLowerCase();

      if (opt === "on") {
        if (!conf?.message) return reply(event, `❌ Set pesan dulu dengan <code>.setwelcome &lt;pesan&gt;</code>`);
        conf.enabled = true; setConf(ctx.ownerId, chatId, conf);
        return reply(event, `✅ Welcome <b>diaktifkan</b>.`);
      }
      if (opt === "off") {
        if (conf) { conf.enabled = false; setConf(ctx.ownerId, chatId, conf); }
        return reply(event, `🔕 Welcome <b>dimatikan</b>.`);
      }
      if (!conf?.message) return reply(event, `ℹ️ Belum ada welcome. Set dengan <code>.setwelcome &lt;pesan&gt;</code>`);
      return reply(event,
        `📋 <b>Status Welcome</b>\n\n<b>Status:</b> ${conf.enabled ? "🟢 Aktif" : "🔴 Mati"}\n<b>Pesan:</b>\n${esc(conf.message)}`
      );
    },
  },
];
