// ─────────────────────────────────────────
//  Plugin: TextFun — transformasi teks (tanpa API)
// ─────────────────────────────────────────

const _fmt = require("./_format");

async function getText(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) {
    try { const r = await event.message.getReplyMessage(); t = r?.text || r?.message || ""; } catch {}
  }
  return t;
}

function toFullwidth(s) {
  let o = "";
  for (const ch of s) {
    const c = ch.codePointAt(0);
    if (c === 0x20) o += "\u3000";
    else if (c >= 0x21 && c <= 0x7e) o += String.fromCodePoint(c + 0xfee0);
    else o += ch;
  }
  return o;
}
function toEmoji(s) {
  let o = "";
  for (const ch of s.toLowerCase()) {
    if (ch >= "a" && ch <= "z") o += String.fromCodePoint(0x1f1e6 + (ch.charCodeAt(0) - 97)) + " ";
    else if (ch >= "0" && ch <= "9") o += ch + "\uFE0F\u20E3 ";
    else if (ch === " ") o += "  ";
    else o += ch;
  }
  return o.trim();
}
function toBubble(s) {
  let o = "";
  for (const ch of s) {
    if (ch >= "a" && ch <= "z") o += String.fromCodePoint(0x24d0 + (ch.charCodeAt(0) - 97));
    else if (ch >= "A" && ch <= "Z") o += String.fromCodePoint(0x24b6 + (ch.charCodeAt(0) - 65));
    else if (ch === "0") o += "\u24ea";
    else if (ch >= "1" && ch <= "9") o += String.fromCodePoint(0x2460 + (ch.charCodeAt(0) - 49));
    else o += ch;
  }
  return o;
}
function toSquare(s) {
  let o = "";
  for (const ch of s.toUpperCase()) {
    if (ch >= "A" && ch <= "Z") o += String.fromCodePoint(0x1f170 + (ch.charCodeAt(0) - 65)) + "\uFE0F";
    else o += ch;
  }
  return o;
}
const ZALGO_UP = ["\u0300","\u0301","\u0302","\u0303","\u0304","\u0306","\u0307","\u0308","\u030A","\u030B","\u0312","\u0313","\u0314","\u033D","\u0342","\u0350","\u0351","\u0352"];
const ZALGO_DOWN = ["\u0316","\u0317","\u0318","\u0319","\u031C","\u031D","\u031E","\u031F","\u0320","\u0324","\u0325","\u0326","\u0329","\u032A","\u032B","\u032C"];
function toZalgo(s) {
  let o = "";
  for (const ch of s) {
    o += ch;
    if (ch.trim() === "") continue;
    const n = 1 + Math.floor(Math.random() * 3);
    for (let i = 0; i < n; i++) o += ZALGO_UP[Math.floor(Math.random() * ZALGO_UP.length)];
    for (let i = 0; i < n; i++) o += ZALGO_DOWN[Math.floor(Math.random() * ZALGO_DOWN.length)];
  }
  return o;
}
const MORSE = {a:".-",b:"-...",c:"-.-.",d:"-..",e:".",f:"..-.",g:"--.",h:"....",i:"..",j:".---",k:"-.-",l:".-..",m:"--",n:"-.",o:"---",p:".--.",q:"--.-",r:".-.",s:"...",t:"-",u:"..-",v:"...-",w:".--",x:"-..-",y:"-.--",z:"--..","0":"-----","1":".----","2":"..---","3":"...--","4":"....-","5":".....","6":"-....","7":"--...","8":"---..","9":"----.",".":".-.-.-",",":"--..--","?":"..--..","!":"-.-.--","/":"-..-.","@":".--.-.","-":"-....-"};
const UNMORSE = Object.fromEntries(Object.entries(MORSE).map(([k, v]) => [v, k]));

const commands = [
  {
    name: "vaporwave",
    description: "Ubah teks jadi 'ｆｕｌｌｗｉｄｔｈ' (.vaporwave halo)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.vaporwave teksnya</code>`);
      return _fmt.reply(event, `🌴 <code>${_fmt.esc(toFullwidth(t))}</code>`);
    },
  },
  {
    name: "emojify",
    description: "Ubah teks jadi emoji huruf 🇦🇧🇨 (.emojify halo)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.emojify teksnya</code>`);
      return _fmt.reply(event, `🔠 ${_fmt.esc(toEmoji(t))}`);
    },
  },
  {
    name: "bubble",
    description: "Ubah teks jadi huruf gelembung ⓗⓐⓛⓞ (.bubble halo)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.bubble teksnya</code>`);
      return _fmt.reply(event, `🫧 <code>${_fmt.esc(toBubble(t))}</code>`);
    },
  },
  {
    name: "squaretext",
    description: "Ubah teks jadi kotak 🅷🅰🅻🅾 (.squaretext halo)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.squaretext teksnya</code>`);
      return _fmt.reply(event, `🟦 ${_fmt.esc(toSquare(t))}`);
    },
  },
  {
    name: "smallcaps",
    description: "Ubah teks jadi small caps ʜᴀʟᴏ (.smallcaps halo)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.smallcaps teksnya</code>`);
      return _fmt.reply(event, `🔡 <code>${_fmt.esc(_fmt.toSmallCaps(t))}</code>`);
    },
  },
  {
    name: "zalgo",
    description: "Teks 'rusak' bergetar (.zalgo halo)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.zalgo teksnya</code>`);
      return _fmt.reply(event, `👹 ${_fmt.esc(toZalgo(t))}`);
    },
  },
  {
    name: "morse",
    description: "Ubah teks → kode morse (.morse halo)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.morse teksnya</code>`);
      const out = t.toLowerCase().split("").map(c => (c === " " ? "/" : (MORSE[c] || ""))).filter(Boolean).join(" ");
      return _fmt.reply(event, `📡 <b>Morse</b>\n<code>${_fmt.esc(out || "-")}</code>`);
    },
  },
  {
    name: "unmorse",
    description: "Ubah kode morse → teks (.unmorse .... .- .-.. ---)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.unmorse .... .- .-.. ---</code>`);
      const out = t.trim().split(/\s+/).map(code => (code === "/" ? " " : (UNMORSE[code] || ""))).join("");
      return _fmt.reply(event, `📡 <b>Hasil</b>\n${_fmt.esc(out || "(kosong)")}`);
    },
  },
  {
    name: "titlecase",
    description: "Kapital tiap awal kata (.titlecase halo dunia)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.titlecase halo dunia</code>`);
      const out = t.toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
      return _fmt.reply(event, `🔤 <code>${_fmt.esc(out)}</code>`);
    },
  },
  {
    name: "reversewords",
    description: "Balik URUTAN kata (.reversewords aku suka kamu)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.reversewords aku suka kamu</code>`);
      return _fmt.reply(event, `🔄 <code>${_fmt.esc(t.trim().split(/\s+/).reverse().join(" "))}</code>`);
    },
  },
  {
    name: "wordcount",
    description: "Hitung kata, karakter, baris (.wordcount <teks/reply>)",
    category: "TextFun",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.wordcount teksnya</code> (atau reply pesan)`);
      const words = t.trim().split(/\s+/).filter(Boolean).length;
      const chars = [...t].length;
      const noSpace = [...t.replace(/\s/g, "")].length;
      const lines = t.split(/\n/).length;
      return _fmt.reply(event,
        `🔢 <b>Hitungan Teks</b>\n` +
        `Kata: <b>${words}</b>\n` +
        `Karakter: <b>${chars}</b> (tanpa spasi: ${noSpace})\n` +
        `Baris: <b>${lines}</b>`
      );
    },
  },
];

module.exports = { commands };
