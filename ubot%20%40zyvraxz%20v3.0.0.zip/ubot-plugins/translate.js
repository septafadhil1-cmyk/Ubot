// ─────────────────────────────────────────
// Plugin: Translator (fixed)
// .tr <target> <text>             -> auto-detect to target
// .tr <source> <target> <text>    -> translate source to target
// Reply pesan lalu .tr <target>   -> translate replied message
// .trl                            -> list language codes
// ─────────────────────────────────────────
const _fmt = require("./_format");
const https = require("https");
const { Button } = require("telegram/tl/custom/button");
const { CallbackQuery } = require("telegram/events/CallbackQuery");

// Data sementara untuk tombol pilihan bahasa: token -> { text, chatId, userId }
const pendingTranslations = new Map();
const attachedClients = new WeakSet();

function attachTranslateButtons(client) {
  if (!client || attachedClients.has(client)) return;
  attachedClients.add(client);
  client.addEventHandler(async (event) => {
    try {
      const raw = event?.data;
      const data = Buffer.isBuffer(raw) ? raw.toString("utf8") : String(raw || "");
      if (!data.startsWith("trpick:")) return;
      const [, lang, token] = data.split(":");
      const pending = pendingTranslations.get(token);
      if (!pending) { try { await event.answer({ message: "Pilihan ini sudah kedaluwarsa. Ketik .tr lagi.", alert: true }); } catch {} return; }
      const clicker = event.senderId?.toString();
      if (clicker && pending.userId && clicker !== pending.userId) {
        try { await event.answer({ message: "Tombol ini bukan untuk kamu.", alert: true }); } catch {}
        return;
      }
      if (!LANG_LIST[lang]) return;
      try { await event.answer({ message: `Menerjemahkan ke ${LANG_LIST[lang]}…` }); } catch {}
      pendingTranslations.delete(token);
      const result = await googleTranslate(pending.text, lang, "auto");
      const detected = result.detectedLang || "auto";
      const fromName = LANG_LIST[detected] || String(detected).toUpperCase();
      const translated = result.translated.length > 3500 ? result.translated.slice(0, 3500) + "…\n\n<i>(hasil dipotong agar muat dalam pesan Telegram)</i>" : result.translated;
      await client.sendMessage(pending.chatId, {
        message: `<blockquote><b>🌐 Hasil Terjemahan</b>\n\n<b>Dari:</b> ${esc(fromName)} → <b>Ke:</b> ${esc(LANG_LIST[lang])}\n\n${esc(translated)}</blockquote>`,
        parseMode: "html"
      });
    } catch (err) { console.error("Translate button error:", err?.message || err); }
  }, new CallbackQuery({}));
}

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

async function reply(event, html) {
  return _fmt.reply(event, html);
}

const LANG_LIST = {
  af: "Afrikaans", sq: "Albania", am: "Amharik", ar: "Arab", hy: "Armenia",
  az: "Azerbaijan", eu: "Basque", be: "Belarusia", bn: "Bengali", bs: "Bosnia",
  bg: "Bulgaria", ca: "Katalan", ceb: "Cebuano", zh: "Mandarin", "zh-CN": "Mandarin Sederhana",
  "zh-TW": "Mandarin Tradisional", co: "Korsika", hr: "Kroasia", cs: "Ceko", da: "Denmark",
  nl: "Belanda", en: "Inggris", eo: "Esperanto", et: "Estonia", tl: "Filipina", fi: "Finlandia",
  fr: "Prancis", fy: "Frisia", gl: "Galicia", ka: "Georgia", de: "Jerman", el: "Yunani",
  gu: "Gujarati", ht: "Kreol Haiti", ha: "Hausa", haw: "Hawaii", he: "Ibrani", hi: "Hindi",
  hmn: "Hmong", hu: "Hungaria", is: "Islandia", ig: "Igbo", id: "Indonesia", ga: "Irlandia",
  it: "Italia", ja: "Jepang", jv: "Jawa", kn: "Kannada", kk: "Kazakh", km: "Khmer",
  rw: "Kinyarwanda", ko: "Korea", ku: "Kurdi", ky: "Kirgiz", lo: "Lao", la: "Latin",
  lv: "Latvia", lt: "Lithuania", lb: "Luksemburg", mk: "Makedonia", mg: "Malagasi",
  ms: "Melayu", ml: "Malayalam", mt: "Malta", mi: "Maori", mr: "Marathi", mn: "Mongolia",
  my: "Myanmar", ne: "Nepal", no: "Norwegia", ny: "Nyanja", or: "Odia", ps: "Pashto",
  fa: "Persia", pl: "Polandia", pt: "Portugis", pa: "Punjabi", ro: "Rumania", ru: "Rusia",
  sm: "Samoa", gd: "Gaelik Skotlandia", sr: "Serbia", st: "Sesotho", sn: "Shona", sd: "Sindhi",
  si: "Sinhala", sk: "Slovakia", sl: "Slovenia", so: "Somali", es: "Spanyol", su: "Sunda",
  sw: "Swahili", sv: "Swedia", tg: "Tajik", ta: "Tamil", tt: "Tatar", te: "Telugu",
  th: "Thailand", tr: "Turki", tk: "Turkmen", uk: "Ukraina", ur: "Urdu", ug: "Uyghur",
  uz: "Uzbek", vi: "Vietnam", cy: "Welsh", xh: "Xhosa", yi: "Yiddish", yo: "Yoruba",
  zu: "Zulu"
};

function googleTranslate(text, targetLang, sourceLang = "auto") {
  return new Promise((resolve, reject) => {
    const params = new URLSearchParams({ client: "gtx", sl: sourceLang, tl: targetLang, dt: "t", q: text });
    const req = https.get(
      `https://translate.googleapis.com/translate_a/single?${params.toString()}`,
      { headers: { "User-Agent": "Mozilla/5.0", Accept: "application/json" } },
      (res) => {
        let data = "";
        res.setEncoding("utf8");
        res.on("data", chunk => { data += chunk; });
        res.on("end", () => {
          if (res.statusCode < 200 || res.statusCode >= 300) {
            return reject(new Error(`Layanan terjemahan merespons HTTP ${res.statusCode || "error"}`));
          }
          try {
            const parsed = JSON.parse(data);
            const translated = Array.isArray(parsed?.[0])
              ? parsed[0].map(part => Array.isArray(part) ? (part[0] || "") : "").join("")
              : "";
            if (!translated.trim()) return reject(new Error("Hasil terjemahan kosong. Coba teks lain."));
            resolve({ translated, detectedLang: parsed?.[2] || sourceLang || "auto" });
          } catch (err) {
            reject(new Error("Respons layanan terjemahan tidak valid."));
          }
        });
      }
    );
    req.setTimeout(15000, () => req.destroy(new Error("Permintaan terjemahan timeout. Coba lagi.")));
    req.on("error", err => reject(err));
  });
}

module.exports.commands = [
  {
    name: "tr",
    description: "Terjemahkan teks atau pesan reply",
    usage: ".tr <kode_bahasa> <teks> | reply pesan lalu .tr <kode_bahasa>",
    category: "Utilitas",
    handler: async (event, args, ctx = {}) => {
      // Mode praktis: reply pesan lalu ketik .tr untuk memilih Indonesia / Inggris lewat tombol.
      if (!args?.length) {
        try {
          const message = event?.message;
          const replied = typeof message?.getReplyMessage === "function" ? await message.getReplyMessage() : null;
          const textToTranslate = String(replied?.message || replied?.text || "").trim();
          if (textToTranslate) {
            if (textToTranslate.length > 4500) return reply(event, "❌ Teks terlalu panjang. Batasnya 4.500 karakter.");
            const client = ctx.client;
            attachTranslateButtons(client);
            const token = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
            pendingTranslations.set(token, { text: textToTranslate, chatId: event.chatId || message.peerId, userId: event.senderId?.toString() });
            // Bersihkan pilihan lama setelah 10 menit.
            setTimeout(() => pendingTranslations.delete(token), 10 * 60 * 1000).unref?.();
            return message.reply({
              message: "🌐 <b>Pilih bahasa tujuan:</b>\nPesan yang kamu reply akan diterjemahkan otomatis.",
              parseMode: "html",
              buttons: [[
                Button.inline("🇮🇩 Indonesia", Buffer.from(`trpick:id:${token}`)),
                Button.inline("🇬🇧 Inggris", Buffer.from(`trpick:en:${token}`))
              ]]
            });
          }
        } catch (err) {
          console.error("Translate reply picker error:", err?.message || err);
        }
        return reply(event,
          `🌐 <b>Translator</b>\n\n` +
          `• <code>.tr en halo dunia</code> — Indonesia/auto → Inggris\n` +
          `• <code>.tr en id hello world</code> — Inggris → Indonesia\n` +
          `• Reply pesan lalu <code>.tr id</code> — terjemahkan ke Indonesia\n` +
          `• <code>.trl</code> — daftar kode bahasa\n\n` +
          `Kode target yang didukung: ${Object.keys(LANG_LIST).length} bahasa.`
        );
      }

      let sourceLang = "auto";
      let targetLang = String(args[0] || "").toLowerCase();
      let textStart = 1;
      const second = String(args[1] || "").toLowerCase();

      // Format source-target hanya dipilih jika keduanya merupakan kode yang dikenal.
      if (LANG_LIST[targetLang] && LANG_LIST[second]) {
        sourceLang = targetLang;
        targetLang = second;
        textStart = 2;
      }

      if (!LANG_LIST[targetLang]) {
        return reply(event, `❌ Kode bahasa target <code>${esc(targetLang)}</code> tidak dikenal. Ketik <code>.trl</code> untuk daftar bahasa.`);
      }

      let textToTranslate = args.slice(textStart).join(" ").trim();
      let sourceInfo = "";
      if (!textToTranslate) {
        try {
          const message = event?.message;
          const replied = typeof message?.getReplyMessage === "function" ? await message.getReplyMessage() : null;
          textToTranslate = String(replied?.message || replied?.text || "").trim();
          if (!textToTranslate) {
            return reply(event, `❌ Teks tidak ditemukan. Tulis teks setelah kode bahasa atau reply pesan teks lalu gunakan <code>.tr ${esc(targetLang)}</code>.`);
          }
          const preview = textToTranslate.length > 160 ? textToTranslate.slice(0, 160) + "…" : textToTranslate;
          sourceInfo = `<b>Teks asal:</b> ${esc(preview)}\n\n`;
        } catch {
          return reply(event, `❌ Tidak bisa membaca pesan reply. Reply ke pesan teks lalu coba lagi.`);
        }
      }

      if (textToTranslate.length > 4500) {
        return reply(event, `❌ Teks terlalu panjang (${textToTranslate.length} karakter). Batasnya 4.500 karakter per terjemahan.`);
      }

      try {
        const result = await googleTranslate(textToTranslate, targetLang, sourceLang);
        const detected = result.detectedLang || sourceLang;
        const fromName = sourceLang === "auto" ? (LANG_LIST[detected] || String(detected).toUpperCase()) : (LANG_LIST[sourceLang] || sourceLang.toUpperCase());
        const toName = LANG_LIST[targetLang] || targetLang.toUpperCase();
        const translated = result.translated.length > 3500 ? result.translated.slice(0, 3500) + "…\n\n<i>(hasil dipotong agar muat dalam pesan Telegram)</i>" : result.translated;
        return reply(event,
          `🌐 <b>Hasil Terjemahan</b>\n\n` + sourceInfo +
          `<b>Dari:</b> ${esc(fromName)} → <b>Ke:</b> ${esc(toName)}\n\n` + esc(translated)
        );
      } catch (err) {
        const message = /ENOTFOUND|ECONNRESET|ETIMEDOUT|timeout|network/i.test(err?.message || "")
          ? "Koneksi ke layanan terjemahan gagal atau timeout. Coba lagi beberapa saat."
          : (err?.message || "Terjadi kesalahan tidak diketahui.");
        return reply(event, `❌ Gagal menerjemahkan: ${esc(message)}`);
      }
    }
  },
  {
    name: "trl",
    description: "Daftar kode bahasa translator",
    usage: ".trl",
    category: "Utilitas",
    handler: async (event) => {
      const entries = Object.entries(LANG_LIST);
      const lines = [`🌐 <b>Daftar Kode Bahasa (${entries.length})</b>\n`];
      for (const [code, name] of entries) lines.push(`<code>${esc(code)}</code> — ${esc(name)}`);
      lines.push(`\n<i>Contoh: <code>.tr en halo dunia</code></i>`);
      return reply(event, lines.join("\n"));
    }
  }
];
