// ─────────────────────────────────────────
//  Plugin: To-Do List pribadi — tersimpan permanen per ubot
//  .todo <isi>       → tambah tugas
//  .todos            → lihat semua tugas (dengan nomor & status)
//  .ceklis <no>      → tandai tugas selesai
//  .unceklis <no>    → batalkan tanda selesai
//  .deltodo <no>     → hapus 1 tugas
//  .cleartodo        → hapus semua tugas (atau .cleartodo done = hapus yg selesai aja)
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");

const esc = _fmt.esc;

let cache = null; // ownerId(str) → { items: [{text,done,ts}] }

async function initTodo() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("todo");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { items: Array.isArray(d.items) ? d.items : [] };
      }
      console.log(`✅ [db] load todo: ${docs.length} user`);
    } catch (e) { console.error("init todo:", e.message); }
  }
}

function getList(ownerId) {
  const id = String(ownerId);
  if (!cache) cache = {};
  if (!cache[id]) cache[id] = { items: [] };
  return cache[id];
}
function save(ownerId) { store.upsert("todo", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

function render(list) {
  if (!list.items.length) return `📝 To-do kosong. Tambah pakai <code>.todo &lt;isi&gt;</code>.`;
  const done = list.items.filter((i) => i.done).length;
  const lines = [`📝 <b>To-Do List</b> (${done}/${list.items.length} selesai)`, `⏣────────────────⏣\n`];
  list.items.forEach((it, i) => {
    lines.push(`${it.done ? "✅" : "⬜"} <b>#${i + 1}</b> ${esc(it.text)}`);
  });
  lines.push(`\n<i>.ceklis &lt;no&gt; buat tandai selesai.</i>`);
  return lines.join("\n");
}

function markHandler(done) {
  return async (event, args, ctx) => {
    const no = parseInt(args[0]);
    const list = getList(ctx.ownerId);
    if (isNaN(no) || no < 1 || no > list.items.length) {
      return _fmt.reply(event, `❌ Nomor tidak valid. Lihat <code>.todos</code>.`);
    }
    list.items[no - 1].done = done;
    save(ctx.ownerId);
    return _fmt.reply(event, `${done ? "✅ Ditandai selesai" : "⬜ Tanda selesai dibatalkan"}: <b>${esc(list.items[no - 1].text)}</b>`);
  };
}

module.exports.initTodo = initTodo;

module.exports.commands = [
  {
    name: "todo",
    description: "Tambah tugas ke to-do list: .todo <isi>",
    category: "Todo",
    handler: async (event, args, ctx) => {
      const text = args.join(" ").trim();
      if (!text) return _fmt.reply(event, `❌ Format: <code>.todo &lt;isi tugas&gt;</code>`);
      const list = getList(ctx.ownerId);
      list.items.push({ text, done: false, ts: Date.now() });
      save(ctx.ownerId);
      return _fmt.reply(event, `➕ Tugas ditambah (#${list.items.length}): <b>${esc(text)}</b>`);
    },
  },
  {
    name: "todos",
    description: "Lihat semua tugas di to-do list",
    category: "Todo",
    handler: async (event, args, ctx) => _fmt.reply(event, render(getList(ctx.ownerId))),
  },
  {
    name: "ceklis",
    description: "Tandai tugas selesai: .ceklis <no>",
    category: "Todo",
    handler: markHandler(true),
  },
  {
    name: "unceklis",
    description: "Batalkan tanda selesai: .unceklis <no>",
    category: "Todo",
    handler: markHandler(false),
  },
  {
    name: "deltodo",
    description: "Hapus 1 tugas: .deltodo <no>",
    category: "Todo",
    handler: async (event, args, ctx) => {
      const no = parseInt(args[0]);
      const list = getList(ctx.ownerId);
      if (isNaN(no) || no < 1 || no > list.items.length) {
        return _fmt.reply(event, `❌ Nomor tidak valid. Lihat <code>.todos</code>.`);
      }
      const removed = list.items.splice(no - 1, 1)[0];
      save(ctx.ownerId);
      return _fmt.reply(event, `🗑 Tugas dihapus: <b>${esc(removed.text)}</b>`);
    },
  },
  {
    name: "cleartodo",
    description: "Hapus semua tugas (.cleartodo done = hapus yang selesai saja)",
    category: "Todo",
    handler: async (event, args, ctx) => {
      const list = getList(ctx.ownerId);
      const onlyDone = (args[0] || "").toLowerCase() === "done";
      if (onlyDone) {
        const before = list.items.length;
        list.items = list.items.filter((i) => !i.done);
        save(ctx.ownerId);
        return _fmt.reply(event, `🧹 ${before - list.items.length} tugas selesai dihapus. Sisa: <b>${list.items.length}</b>.`);
      }
      const n = list.items.length;
      list.items = [];
      save(ctx.ownerId);
      return _fmt.reply(event, `🧹 <b>Semua ${n} tugas dihapus.</b> To-do bersih.`);
    },
  },
];
