// ─────────────────────────────────────────
//  Plugin: Web Search (DuckDuckGo) — hasil sebagai TOMBOL via bot manager
//  .ddg / .google / .search <kata kunci>
//  Tiap hasil = tombol; diklik → buka isi halaman (edit pesan)
// ─────────────────────────────────────────

const _fmt = require("./_format");
const websearch = require("../lib/websearch");

async function getQuery(event, args) {
  let q = args.join(" ");
  if (!q && event.message.replyTo) { try { const r = await event.message.getReplyMessage(); q = r?.text || ""; } catch {} }
  return q;
}

const searchHandler = async (event, args, ctx) => {
  const msg = event.message;
  const client = ctx.client;
  const BOT_USERNAME = process.env.BOT_USERNAME || "";

  const q = await getQuery(event, args);
  if (!q) return _fmt.reply(event, `❌ Format: <code>.ddg cara masak rendang</code>`);

  // Kalau BOT_USERNAME ga ada → fallback teks biasa (tanpa tombol)
  if (!BOT_USERNAME) {
    if (!websearch.isConfigured()) {
      return _fmt.reply(event,
        `🔍 <b>Search belum diatur.</b>\n\n` +
        `Daftar gratis di <b>serper.dev</b> (2500 query, tanpa kartu), lalu owner tambah di <code>.env</code>:\n` +
        `<code>SERPER_API_KEY=...</code>\n\n` +
        `Sementara pakai <code>.wiki ${_fmt.esc(q)}</code> dulu.`
      );
    }
    try {
      const results = await websearch.ddgSearch(q);
      if (!results.length) return _fmt.reply(event, `🔍 Tidak ada hasil untuk "<b>${_fmt.esc(q)}</b>".`);
      const lines = [`🦆 <b>Hasil: ${_fmt.esc(q)}</b>\n`];
      results.slice(0, 5).forEach((r, i) => {
        lines.push(`<b>${i + 1}. ${_fmt.esc(r.title)}</b>`);
        if (r.snippet) lines.push(`${_fmt.esc(r.snippet.slice(0, 120))}`);
        lines.push(`🔗 ${_fmt.esc(r.url)}\n`);
      });
      return _fmt.reply(event, lines.join("\n"));
    } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
  }

  // Pakai inline bertombol via bot manager
  try {
    const Api = require("telegram").Api;
    let botEntity;
    try { botEntity = await client.getInputEntity(BOT_USERNAME.replace("@", "")); }
    catch { const ent = await client.getEntity(BOT_USERNAME.replace("@", "")); botEntity = await client.getInputEntity(ent); }

    let peerEntity;
    try { peerEntity = await client.getInputEntity(msg.peerId); }
    catch { const chat = await msg.getChat(); peerEntity = await client.getInputEntity(chat); }

    const queryResult = await client.invoke(new Api.messages.GetInlineBotResults({
      bot: botEntity, peer: peerEntity, query: "websearch " + q, offset: "",
    }));

    if (!queryResult.results || queryResult.results.length === 0) {
      return _fmt.reply(event, `🔍 Tidak ada hasil untuk "<b>${_fmt.esc(q)}</b>".`);
    }

    await client.invoke(new Api.messages.SendInlineBotResult({
      peer: peerEntity,
      queryId: queryResult.queryId,
      id: queryResult.results[0].id,
      replyTo: new Api.InputReplyToMessage({ replyToMsgId: msg.id }),
    }));
  } catch (e) {
    console.error("search inline error:", e.message);
    return _fmt.reply(event, `❌ Gagal cari (inline): ${_fmt.esc(e.message)}`);
  }
};

// ── .shop <query> — Google Shopping via bot manager, hasil tombol paginated ──
const shopHandler = async (event, args, ctx) => {
  const msg = event.message;
  const client = ctx.client;
  const BOT_USERNAME = process.env.BOT_USERNAME || "";

  const q = await getQuery(event, args);
  if (!q) return _fmt.reply(event, `❌ Format: <code>.shop iPhone 17 Pro Max</code>`);

  if (!BOT_USERNAME) {
    // Fallback teks tanpa tombol (kalau BOT_USERNAME ga diset)
    try {
      const resp = await websearch.serperShopping(q);
      if (resp.error === "no_key") return _fmt.reply(event, `❌ Owner belum set <code>SERPER_API_KEY</code>.`);
      const results = resp.results || [];
      if (!results.length) return _fmt.reply(event, `🛒 Tidak ada produk untuk "<b>${_fmt.esc(q)}</b>".`);
      const lines = [`🛒 <b>Hasil Belanja: ${_fmt.esc(q)}</b>\n`];
      results.slice(0, 8).forEach((r, i) => {
        lines.push(`<b>${i + 1}. ${_fmt.esc(r.title)}</b>`);
        if (r.price) lines.push(`💰 ${_fmt.esc(r.price)}${r.source ? ` · ${_fmt.esc(r.source)}` : ""}`);
        lines.push(`🔗 ${_fmt.esc(r.link)}\n`);
      });
      return _fmt.reply(event, lines.join("\n"));
    } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
  }

  // Pakai inline bertombol via bot manager (query "shop <q>")
  try {
    const Api = require("telegram").Api;
    let botEntity;
    try { botEntity = await client.getInputEntity(BOT_USERNAME.replace("@", "")); }
    catch { const ent = await client.getEntity(BOT_USERNAME.replace("@", "")); botEntity = await client.getInputEntity(ent); }
    let peerEntity;
    try { peerEntity = await client.getInputEntity(msg.peerId); }
    catch { const chat = await msg.getChat(); peerEntity = await client.getInputEntity(chat); }

    const queryResult = await client.invoke(new Api.messages.GetInlineBotResults({
      bot: botEntity, peer: peerEntity, query: "shop " + q, offset: "",
    }));
    if (!queryResult.results || queryResult.results.length === 0) {
      return _fmt.reply(event, `🛒 Tidak ada produk untuk "<b>${_fmt.esc(q)}</b>".`);
    }
    await client.invoke(new Api.messages.SendInlineBotResult({
      peer: peerEntity, queryId: queryResult.queryId, id: queryResult.results[0].id,
      replyTo: new Api.InputReplyToMessage({ replyToMsgId: msg.id }),
    }));
  } catch (e) {
    console.error("shop inline error:", e.message);
    return _fmt.reply(event, `❌ Gagal cari produk (inline): ${_fmt.esc(e.message)}`);
  }
};

module.exports.commands = [
  { name: "ddg", description: "Cari di web via DuckDuckGo (.ddg <kata kunci>)", category: "Tools", handler: searchHandler },
  { name: "google", description: "Cari di web (.google <kata kunci>)", category: "Tools", handler: searchHandler },
  { name: "search", description: "Cari di web (.search <kata kunci>)", category: "Tools", handler: searchHandler },
  { name: "shop", description: "Cari produk (Google Shopping) — hasil jadi tombol. (.shop iPhone 17 Pro Max)", category: "Tools", handler: shopHandler },
];
