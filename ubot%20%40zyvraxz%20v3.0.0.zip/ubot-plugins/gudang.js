// ─────────────────────────────────────────
//  Plugin: Gudang (manajemen stok barang) — tersimpan permanen per ubot
//  .tambahstok <nama> <jumlah>  → tambah stok (bikin item kalau belum ada)
//  .kurangstok <nama> <jumlah>  → kurangi stok
//  .stok <nama>                 → cek stok 1 barang
//  .daftarstok                  → daftar semua barang + stok
//  .hapusstok <nama>            → hapus barang
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");
const esc = _fmt.esc;

let cache = null; // ownerId(str) → { items: { name: qty } }

async function initGudang() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("gudang");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { items: d.items || {} };
      }
      console.log(`✅ [db] load gudang: ${docs.length} user`);
    } catch (e) { console.error("init gudang:", e.message); }
  }
}
function get(ownerId) { const id = String(ownerId); if (!cache) cache = {}; if (!cache[id]) cache[id] = { items: {} }; return cache[id]; }
function save(ownerId) { store.upsert("gudang", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

function makeAdj(sign) {
  return async (event, args, ctx) => {
    const name = (args[0] || "").toLowerCase();
    const qty = parseInt(args[1]);
    if (!name || isNaN(qty) || qty < 1) return _fmt.reply(event, `❌ Format: <code>.${sign > 0 ? "tambahstok" : "kurangstok"} &lt;nama&gt; &lt;jumlah&gt;</code>`);
    const g = get(ctx.ownerId);
    const cur = g.items[name] || 0;
    let next = cur + sign * qty;
    if (next < 0) next = 0;
    g.items[name] = next;
    save(ctx.ownerId);
    return _fmt.reply(event, `${sign > 0 ? "📦➕" : "📦➖"} <b>${esc(name)}</b>: ${cur} → <b>${next}</b>`);
  };
}

module.exports.initGudang = initGudang;
module.exports.commands = [
  { name: "tambahstok", description: "Tambah stok: .tambahstok <nama> <jumlah>", category: "Gudang", handler: makeAdj(1) },
  { name: "kurangstok", description: "Kurangi stok: .kurangstok <nama> <jumlah>", category: "Gudang", handler: makeAdj(-1) },
  {
    name: "stok", description: "Cek stok 1 barang: .stok <nama>", category: "Gudang",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      const g = get(ctx.ownerId);
      if (!name || !(name in g.items)) return _fmt.reply(event, `❌ Barang "${esc(name || "-")}" ga ada. Lihat <code>.daftarstok</code>.`);
      return _fmt.reply(event, `📦 <b>${esc(name)}</b>: <b>${g.items[name]}</b> stok`);
    },
  },
  {
    name: "daftarstok", description: "Daftar semua stok barang", category: "Gudang",
    handler: async (event, args, ctx) => {
      const g = get(ctx.ownerId);
      const keys = Object.keys(g.items);
      if (!keys.length) return _fmt.reply(event, `📦 Gudang kosong. Tambah pakai <code>.tambahstok</code>.`);
      const lines = [`📦 <b>Daftar Stok</b> (${keys.length} barang)`, `⏣────────────────⏣\n`];
      let total = 0;
      for (const k of keys.sort()) { lines.push(`• <b>${esc(k)}</b>: ${g.items[k]}`); total += g.items[k]; }
      lines.push(`\n<i>Total unit: ${total}</i>`);
      return _fmt.reply(event, lines.join("\n"));
    },
  },
  {
    name: "hapusstok", description: "Hapus barang: .hapusstok <nama>", category: "Gudang",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      const g = get(ctx.ownerId);
      if (!name || !(name in g.items)) return _fmt.reply(event, `❌ Barang "${esc(name || "-")}" ga ada.`);
      delete g.items[name];
      save(ctx.ownerId);
      return _fmt.reply(event, `🗑 Barang "<b>${esc(name)}</b>" dihapus dari gudang.`);
    },
  },
];
