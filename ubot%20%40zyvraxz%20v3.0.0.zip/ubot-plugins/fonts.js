// ─────────────────────────────────────────
//  Plugin: Fonts — konversi teks ke berbagai gaya unicode
//  Semua REAL & jalan offline (tanpa API)
// ─────────────────────────────────────────

const _fmt = require("./_format");

// Builder peta font dari string berurutan A-Z a-z 0-9
function mapFromString(upper, lower, digits) {
  const m = {};
  const A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const a = "abcdefghijklmnopqrstuvwxyz";
  const d = "0123456789";
  if (upper) [...A].forEach((c, i) => { if ([...upper][i]) m[c] = [...upper][i]; });
  if (lower) [...a].forEach((c, i) => { if ([...lower][i]) m[c] = [...lower][i]; });
  if (digits) [...d].forEach((c, i) => { if ([...digits][i]) m[c] = [...digits][i]; });
  return m;
}

// Konversi pakai offset codepoint (untuk font matematika yang berpola)
function mathFont(base) {
  // base = { upper: startCodepoint, lower: startCodepoint, digit: startCodepoint }
  const m = {};
  const A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const a = "abcdefghijklmnopqrstuvwxyz";
  const d = "0123456789";
  if (base.upper) [...A].forEach((c, i) => m[c] = String.fromCodePoint(base.upper + i));
  if (base.lower) [...a].forEach((c, i) => m[c] = String.fromCodePoint(base.lower + i));
  if (base.digit) [...d].forEach((c, i) => m[c] = String.fromCodePoint(base.digit + i));
  return m;
}

function convert(text, map) {
  return [...text].map(c => map[c] || c).join("");
}

// ── Definisi semua font ──
const FONTS = {
  // Font matematika (codepoint berpola)
  bold:        { desc: "𝗧𝗲𝗯𝗮𝗹", map: mathFont({ upper: 0x1D5D4, lower: 0x1D5EE, digit: 0x1D7EC }) },
  italic:      { desc: "𝘐𝘵𝘢𝘭𝘪𝘤", map: mathFont({ upper: 0x1D608, lower: 0x1D622 }) },
  bolditalic:  { desc: "𝘽𝙤𝙡𝙙 𝙄𝙩𝙖𝙡𝙞𝙘", map: mathFont({ upper: 0x1D63C, lower: 0x1D656 }) },
  script:      { desc: "𝒮𝒸𝓇𝒾𝓅𝓉", map: mathFont({ upper: 0x1D49C, lower: 0x1D4B6 }) },
  boldscript:  { desc: "𝓑𝓸𝓵𝓭 𝓢𝓬𝓻𝓲𝓹𝓽", map: mathFont({ upper: 0x1D4D0, lower: 0x1D4EA }) },
  fraktur:     { desc: "𝔉𝔯𝔞𝔨𝔱𝔲𝔯", map: mathFont({ upper: 0x1D504, lower: 0x1D51E }) },
  boldfraktur: { desc: "𝕭𝖔𝖑𝖉 𝕱𝖗𝖆𝖐", map: mathFont({ upper: 0x1D56C, lower: 0x1D586 }) },
  doublestruck:{ desc: "𝔻𝕠𝕦𝕓𝕝𝕖", map: mathFont({ upper: 0x1D538, lower: 0x1D552, digit: 0x1D7D8 }) },
  mono:        { desc: "𝙼𝚘𝚗𝚘", map: mathFont({ upper: 0x1D670, lower: 0x1D68A, digit: 0x1D7F6 }) },
  sans:        { desc: "𝖲𝖺𝗇𝗌", map: mathFont({ upper: 0x1D5A0, lower: 0x1D5BA, digit: 0x1D7E2 }) },
  sansbold:    { desc: "𝗦𝗮𝗻𝘀 𝗕𝗼𝗹𝗱", map: mathFont({ upper: 0x1D5D4, lower: 0x1D5EE, digit: 0x1D7EC }) },
  sansitalic:  { desc: "𝘚𝘢𝘯𝘴 𝘐𝘵𝘢𝘭", map: mathFont({ upper: 0x1D608, lower: 0x1D622 }) },
  // Font dari string (tidak berpola)
  circled:     { desc: "Ⓒⓘⓡⓒⓛⓔⓓ", map: mapFromString("ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ", "ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ", "⓪①②③④⑤⑥⑦⑧⑨") },
  squared:     { desc: "🅂🅀🅄🄰🅁🄴🄳", map: mapFromString("🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉") },
  bubble:      { desc: "Ⓑⓤⓑⓑⓛⓔ", map: mapFromString("ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ", "ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ") },
  fullwidth:   { desc: "Ｆｕｌｌｗｉｄｔｈ", map: mapFromString("ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ", "ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ", "０１２３４５６７８９") },
  smallcaps:   { desc: "sᴍᴀʟʟ ᴄᴀᴘs", map: mapFromString("ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘQʀsᴛᴜᴠᴡxʏᴢ", "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀsᴛᴜᴠᴡxʏᴢ") },
  scaps:       { desc: "sᴍᴀʟʟ ᴄᴀᴘs (tombol)", map: mapFromString("ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘQʀsᴛᴜᴠᴡxʏᴢ", "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀsᴛᴜᴠᴡxʏᴢ") },
  superscript: { desc: "ˢᵘᵖᵉʳ", map: mapFromString("ᴬᴮᶜᴰᴱᶠᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾQᴿˢᵀᵁⱽᵂˣʸᶻ", "ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖqʳˢᵗᵘᵛʷˣʸᶻ", "⁰¹²³⁴⁵⁶⁷⁸⁹") },
  subscript:   { desc: "ₛᵤᵦ", map: mapFromString("","ₐbcdₑfgₕᵢⱼₖₗₘₙₒₚqᵣₛₜᵤᵥwₓyz","₀₁₂₃₄₅₆₇₈₉") },
};

// Font khusus: upside down
const FLIP_MAP = {
  a:"ɐ",b:"q",c:"ɔ",d:"p",e:"ǝ",f:"ɟ",g:"ƃ",h:"ɥ",i:"ı",j:"ɾ",k:"ʞ",l:"l",m:"ɯ",n:"u",o:"o",p:"d",q:"b",r:"ɹ",s:"s",t:"ʇ",u:"n",v:"ʌ",w:"ʍ",x:"x",y:"ʎ",z:"z",
  "A":"∀","B":"𐐒","C":"Ɔ","D":"◖","E":"Ǝ","F":"Ⅎ","G":"⅁","H":"H","I":"I","J":"ſ","K":"ʞ","L":"˥","M":"W","N":"N","O":"O","P":"Ԁ","Q":"Ò","R":"ᴚ","S":"S","T":"┴","U":"∩","V":"Λ","W":"M","X":"X","Y":"⅄","Z":"Z",
  "0":"0","1":"Ɩ","2":"ᄅ","3":"Ɛ","4":"ㄣ","5":"ϛ","6":"9","7":"ㄥ","8":"8","9":"6",
  ".":"˙",",":"'","?":"¿","!":"¡","'":",","(":")",")":"(","[":"]","]":"[","{":"}","}":"{","<":">",">":"<","&":"⅋","_":"‾",
};

// Buat command untuk tiap font
const commands = [];
for (const [name, font] of Object.entries(FONTS)) {
  commands.push({
    name,
    description: `Teks gaya ${font.desc}`,
    category: "Fonts",
    handler: async (event, args) => {
      const text = args.join(" ") || (await getReplyText(event));
      if (!text) return _fmt.reply(event, `❌ Tulis teks atau reply pesan.`);
      const out = convert(text, font.map);
      try { await event.message.reply({ message: out, parseMode: "html" }); }
      catch { await _fmt.reply(event, out); }
    },
  });
}

// Upside down (terpisah karena pakai reverse)
commands.push({
  name: "upsidedown",
  description: "Teks dibalik (umop ǝpısdn)",
  category: "Fonts",
  handler: async (event, args) => {
    const text = args.join(" ") || (await getReplyText(event));
    if (!text) return _fmt.reply(event, `❌ Tulis teks atau reply pesan.`);
    const out = [...text].map(c => FLIP_MAP[c] || c).reverse().join("");
    try { await event.message.reply({ message: out, parseMode: "html" }); }
    catch { await _fmt.reply(event, out); }
  },
});

// Mock (sPoNgEbOb)
commands.push({
  name: "mock",
  description: "Teks SpOngEbOb mOcKiNg",
  category: "Fonts",
  handler: async (event, args) => {
    const text = args.join(" ") || (await getReplyText(event));
    if (!text) return _fmt.reply(event, `❌ Tulis teks atau reply pesan.`);
    const out = [...text].map((c, i) => i % 2 ? c.toUpperCase() : c.toLowerCase()).join("");
    try { await event.message.reply({ message: out, parseMode: "html" }); }
    catch { await _fmt.reply(event, out); }
  },
});

// Spread (t e k s   r e n g g a n g)
commands.push({
  name: "spread",
  description: "Teks dengan spasi antar huruf",
  category: "Fonts",
  handler: async (event, args) => {
    const text = args.join(" ") || (await getReplyText(event));
    if (!text) return _fmt.reply(event, `❌ Tulis teks atau reply pesan.`);
    const out = [...text].join(" ");
    try { await event.message.reply({ message: out, parseMode: "html" }); }
    catch { await _fmt.reply(event, out); }
  },
});

// Clap (teks 👏 antar 👏 kata)
commands.push({
  name: "clap",
  description: "Teks 👏 dengan 👏 emoji",
  category: "Fonts",
  handler: async (event, args) => {
    const text = args.join(" ") || (await getReplyText(event));
    if (!text) return _fmt.reply(event, `❌ Tulis teks atau reply pesan.`);
    const out = text.split(/\s+/).join(" 👏 ");
    try { await event.message.reply({ message: out, parseMode: "html" }); }
    catch { await _fmt.reply(event, out); }
  },
});

async function getReplyText(event) {
  try {
    if (event.message.replyTo) {
      const r = await event.message.getReplyMessage();
      return r?.text || r?.message || "";
    }
  } catch {}
  return "";
}

module.exports.commands = commands;
module.exports.FONTS = FONTS;
module.exports.convert = convert;
