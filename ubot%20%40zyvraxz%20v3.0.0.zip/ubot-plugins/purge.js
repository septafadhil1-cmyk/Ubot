// ─────────────────────────────────────────
//  Plugin: Purge
//  .purge <jumlah>  — hapus N pesan terakhir dari kamu
//  .purge           — hapus 1 pesan (pesan command itu sendiri)
//  .purge all       — hapus semua pesan kamu di chat (max 100)
// ─────────────────────────────────────────
const _fmt = require("./_format");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function sleep(ms) {
  return new Promise((res) => setTimeout(res, ms));
}


async function reply(event, html) {
  return _fmt.reply(event, html);
}

module.exports.commands = [
  {
    name: "purge",
    description: "Hapus pesan terakhir kamu di chat ini",
    usage: ".purge [jumlah|all]",
    category: "Utilitas",
    handler: async (event, args) => {
      const msg = event.message;
      const client = msg.client;
      const me = await client.getMe();

      let count = 1;
      if (args[0] === "all") {
        count = 100;
      } else if (args[0]) {
        count = parseInt(args[0]);
        if (isNaN(count) || count < 1) {
          return msg.reply({
            message: "<blockquote><b>❌ Contoh: <code>.purge 10</code> atau <code>.purge all</code></b></blockquote>",
            parseMode: "html",
          });
        }
        if (count > 100) {
          return msg.reply({
            message: "<blockquote><b>❌ Maksimal 100 pesan sekali purge.</b></blockquote>",
            parseMode: "html",
          });
        }
      }

      // Ambil riwayat pesan di chat ini
      const history = await client.getMessages(msg.peerId, { limit: 200 });

      // Filter hanya pesan dari kita sendiri
      const myMessages = history.filter(
        (m) => m.senderId?.toString() === me.id.toString()
      );

      // Ambil N pesan terakhir (termasuk pesan .purge itu sendiri)
      const toDelete = myMessages.slice(0, count);

      if (!toDelete.length) {
        return msg.reply({
          message: "<blockquote><b>ℹ️ Tidak ada pesan yang bisa dihapus.</b></blockquote>",
          parseMode: "html",
        });
      }

      // Hapus satu per satu
      let deleted = 0;
      for (const m of toDelete) {
        try {
          await client.deleteMessages(msg.peerId, [m.id], { revoke: true });
          deleted++;
          if (deleted % 10 === 0) await sleep(300); // jeda tiap 10 pesan
        } catch (e) {
          console.error("Delete error:", e.message);
        }
      }

      // Kirim konfirmasi (bukan reply karena pesan aslinya udah kehapus)
      try {
        const notif = await client.sendMessage(msg.peerId, {
          message: `<blockquote><b>🗑️ <b>Purge Selesai</b>\n\nDihapus: <b>${deleted}</b> pesan</b></blockquote>`,
          parseMode: "html",
        });
        // Auto hapus notif setelah 3 detik
        await sleep(3000);
        await client.deleteMessages(msg.peerId, [notif.id], { revoke: true });
      } catch {}
    },
  },
];
