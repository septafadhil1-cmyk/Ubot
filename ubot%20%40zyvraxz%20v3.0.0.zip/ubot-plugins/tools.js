// ─────────────────────────────────────────
//  Plugin: Tools berguna (API gratis tanpa key)
// ─────────────────────────────────────────

const _fmt = require("./_format");

async function fetchJson(url, timeout = 15000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { "User-Agent": "UBotManager/1.0", "Accept": "application/json" } });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return await res.json();
  } finally { clearTimeout(t); }
}
async function fetchText(url, timeout = 15000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { "User-Agent": "curl/8.0" } });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return await res.text();
  } finally { clearTimeout(t); }
}
async function getArg(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) { try { const r = await event.message.getReplyMessage(); t = r?.text || ""; } catch {} }
  return t;
}

const commands = [
  {
    name: "cuaca",
    description: "Cek cuaca kota (.cuaca <kota>) cth: .cuaca Jakarta",
    category: "Tools",
    handler: async (event, args) => {
      const kota = args.join(" ") || "Jakarta";
      try {
        const txt = await fetchText(`https://wttr.in/${encodeURIComponent(kota)}?format=%l:+%c+%t+(terasa+%f)+%h+kelembapan+%w+angin&m`);
        return _fmt.reply(event, `🌤️ <b>Cuaca</b>\n${_fmt.esc(txt.trim())}`);
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal ambil cuaca: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "wiki",
    description: "Cari ringkasan Wikipedia (.wiki <kata>)",
    category: "Tools",
    handler: async (event, args) => {
      const q = await getArg(event, args);
      if (!q) return _fmt.reply(event, `❌ Format: <code>.wiki Soekarno</code>`);
      try {
        const data = await fetchJson(`https://id.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q)}`);
        if (!data.extract) return _fmt.reply(event, `❌ Tidak ditemukan. Coba kata kunci lain.`);
        let ex = data.extract;
        if (ex.length > 2000) ex = ex.slice(0, 2000) + "...";
        return _fmt.reply(event, `📚 <b>${_fmt.esc(data.title)}</b>\n\n${_fmt.esc(ex)}`);
      } catch (e) {
        return _fmt.reply(event, `❌ Tidak ditemukan / gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "crypto",
    description: "Harga crypto (.crypto bitcoin) → USD & IDR",
    category: "Tools",
    handler: async (event, args) => {
      const coin = (args[0] || "bitcoin").toLowerCase();
      try {
        const data = await fetchJson(`https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(coin)}&vs_currencies=usd,idr&include_24hr_change=true`);
        const d = data[coin];
        if (!d) return _fmt.reply(event, `❌ Coin tidak ditemukan. Pakai id coingecko (bitcoin, ethereum, dogecoin).`);
        const ch = d.usd_24h_change ? d.usd_24h_change.toFixed(2) : "0";
        return _fmt.reply(event,
          `💰 <b>${coin.toUpperCase()}</b>\n\n` +
          `<b>USD:</b> $${d.usd.toLocaleString()}\n` +
          `<b>IDR:</b> Rp${Math.round(d.idr).toLocaleString()}\n` +
          `<b>24j:</b> ${ch >= 0 ? "📈 +" : "📉 "}${ch}%`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "kurs",
    description: "Konversi mata uang (.kurs 100 USD IDR)",
    category: "Tools",
    handler: async (event, args) => {
      const amount = parseFloat(args[0]);
      const from = (args[1] || "USD").toUpperCase();
      const to = (args[2] || "IDR").toUpperCase();
      if (isNaN(amount)) return _fmt.reply(event, `❌ Format: <code>.kurs 100 USD IDR</code>`);
      try {
        // open.er-api.com: gratis, no key, update harian, lebih dekat ke pasar
        const data = await fetchJson(`https://open.er-api.com/v6/latest/${from}`);
        if (data.result !== "success" || !data.rates) {
          return _fmt.reply(event, `❌ Kode mata uang asal salah (cth: USD, EUR, IDR, JPY).`);
        }
        const rate = data.rates[to];
        if (rate == null) return _fmt.reply(event, `❌ Kode mata uang tujuan salah (cth: USD, EUR, IDR, JPY).`);
        const val = amount * rate;
        const updated = data.time_last_update_utc ? data.time_last_update_utc.replace(/ \d{2}:\d{2}:\d{2} \+0000/, "") : "";
        return _fmt.reply(event,
          `💱 <b>${amount} ${from}</b> = <b>${val.toLocaleString("id-ID", { maximumFractionDigits: 2 })} ${to}</b>\n\n` +
          `<i>Kurs 1 ${from} = ${rate.toLocaleString("id-ID", { maximumFractionDigits: 4 })} ${to}</i>\n` +
          `<i>Update: ${updated} • Kurs tengah, bisa beda tipis dari bank/Google</i>`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "ipinfo",
    description: "Info lokasi IP (.ipinfo 8.8.8.8)",
    category: "Tools",
    handler: async (event, args) => {
      const ip = args[0] || "";
      try {
        const data = await fetchJson(`http://ip-api.com/json/${encodeURIComponent(ip)}?fields=status,country,regionName,city,isp,query,lat,lon`);
        if (data.status !== "success") return _fmt.reply(event, `❌ IP tidak valid.`);
        return _fmt.reply(event,
          `🌐 <b>Info IP</b>\n\n` +
          `<b>IP:</b> <code>${data.query}</code>\n` +
          `<b>Negara:</b> ${data.country}\n` +
          `<b>Wilayah:</b> ${data.regionName}, ${data.city}\n` +
          `<b>ISP:</b> ${data.isp}\n` +
          `<b>Koordinat:</b> ${data.lat}, ${data.lon}`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "github",
    description: "Info user GitHub (.github username)",
    category: "Tools",
    handler: async (event, args) => {
      const user = args[0];
      if (!user) return _fmt.reply(event, `❌ Format: <code>.github torvalds</code>`);
      try {
        const d = await fetchJson(`https://api.github.com/users/${encodeURIComponent(user)}`);
        if (!d.login) return _fmt.reply(event, `❌ User tidak ditemukan.`);
        return _fmt.reply(event,
          `🐙 <b>${_fmt.esc(d.name || d.login)}</b> (@${d.login})\n\n` +
          `${d.bio ? _fmt.esc(d.bio) + "\n\n" : ""}` +
          `<b>Repos:</b> ${d.public_repos} | <b>Followers:</b> ${d.followers} | <b>Following:</b> ${d.following}\n` +
          `${d.location ? "<b>Lokasi:</b> " + _fmt.esc(d.location) + "\n" : ""}` +
          `<b>Profil:</b> ${d.html_url}`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "npm",
    description: "Info paket NPM (.npm express)",
    category: "Tools",
    handler: async (event, args) => {
      const pkg = args[0];
      if (!pkg) return _fmt.reply(event, `❌ Format: <code>.npm express</code>`);
      try {
        const d = await fetchJson(`https://registry.npmjs.org/${encodeURIComponent(pkg)}/latest`);
        if (!d.name) return _fmt.reply(event, `❌ Paket tidak ditemukan.`);
        return _fmt.reply(event,
          `📦 <b>${_fmt.esc(d.name)}</b> v${d.version}\n\n` +
          `${d.description ? _fmt.esc(d.description) + "\n\n" : ""}` +
          `<b>Lisensi:</b> ${d.license || "-"}\n` +
          `<b>Install:</b> <code>npm i ${d.name}</code>`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "shortlink",
    description: "Perpendek URL (.shortlink <url>)",
    category: "Tools",
    handler: async (event, args) => {
      const url = await getArg(event, args);
      if (!url || !/^https?:\/\//.test(url)) return _fmt.reply(event, `❌ Format: <code>.shortlink https://contoh.com</code>`);
      try {
        const res = await fetchText(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`);
        return _fmt.reply(event, `🔗 <b>Link pendek:</b>\n<code>${_fmt.esc(res.trim())}</code>`);
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "gempa",
    description: "Info gempa terkini Indonesia (BMKG)",
    category: "Tools",
    handler: async (event) => {
      try {
        const data = await fetchJson(`https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json`);
        const g = data.Infogempa?.gempa;
        if (!g) return _fmt.reply(event, `❌ Data gempa tidak tersedia.`);
        return _fmt.reply(event,
          `🌋 <b>Gempa Terkini (BMKG)</b>\n\n` +
          `<b>Magnitudo:</b> ${g.Magnitude}\n` +
          `<b>Lokasi:</b> ${_fmt.esc(g.Wilayah)}\n` +
          `<b>Kedalaman:</b> ${g.Kedalaman}\n` +
          `<b>Waktu:</b> ${g.Tanggal} ${g.Jam}\n` +
          `<b>Koordinat:</b> ${g.Lintang}, ${g.Bujur}\n` +
          `${g.Potensi ? "<b>Potensi:</b> " + _fmt.esc(g.Potensi) : ""}`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "dict",
    description: "Kamus Inggris (.dict happy)",
    category: "Tools",
    handler: async (event, args) => {
      const word = args[0];
      if (!word) return _fmt.reply(event, `❌ Format: <code>.dict happy</code>`);
      try {
        const data = await fetchJson(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
        const entry = Array.isArray(data) ? data[0] : null;
        if (!entry) return _fmt.reply(event, `❌ Kata tidak ditemukan.`);
        const lines = [`📖 <b>${_fmt.esc(entry.word)}</b> ${entry.phonetic || ""}\n`];
        for (const m of entry.meanings.slice(0, 3)) {
          lines.push(`<b>${m.partOfSpeech}:</b>`);
          for (const d of m.definitions.slice(0, 2)) lines.push(`  • ${_fmt.esc(d.definition)}`);
        }
        return _fmt.reply(event, lines.join("\n"));
      } catch (e) {
        return _fmt.reply(event, `❌ Tidak ditemukan: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "quotes",
    description: "Kutipan inspiratif random",
    category: "Tools",
    handler: async (event) => {
      try {
        const d = await fetchJson(`https://api.quotable.io/random`);
        return _fmt.reply(event, `💬 <i>"${_fmt.esc(d.content)}"</i>\n\n— <b>${_fmt.esc(d.author)}</b>`);
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal ambil kutipan: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "ssweb",
    description: "Screenshot website (.ssweb <url>)",
    category: "Tools",
    handler: async (event, args) => {
      const url = await getArg(event, args);
      if (!url || !/^https?:\/\//.test(url)) return _fmt.reply(event, `❌ Format: <code>.ssweb https://google.com</code>`);
      try {
        const ss = `https://image.thum.io/get/width/1280/crop/720/${url}`;
        await event.client.sendFile(event.message.peerId, { file: ss, caption: _fmt.wrap(`📸 Screenshot: ${_fmt.esc(url)}`), parseMode: "html" });
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal screenshot: ${_fmt.esc(e.message)}`);
      }
    },
  },
];

module.exports.commands = commands;
