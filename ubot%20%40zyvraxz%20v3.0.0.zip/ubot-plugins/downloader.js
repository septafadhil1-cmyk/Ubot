// ─────────────────────────────────────────
//  Plugin: Downloader
//   • .yttomp4 <url yt>   → convert YouTube ke MP4 (pakai Apify), kirim ke Telegram
//   • .spotify <url>      → download lagu Spotify jadi MP3 (pakai RapidAPI), kirim ke Telegram
//
//  .yttomp4 butuh APIFY_API_TOKEN. .spotify butuh RAPIDAPI_KEY. (di gwajib.env)
// ─────────────────────────────────────────
const _fmt = require("./_format");
const fs = require("fs");
const os = require("os");
const path = require("path");

// Ambil arg / reply
async function getArg(event, args) {
  let q = args.join(" ").trim();
  if (!q && event.message.replyTo) { try { const r = await event.message.getReplyMessage(); q = (r?.text || r?.message || "").trim(); } catch {} }
  return q;
}

// Download URL → file lokal (buat dikirim ke telegram)
// Pakai User-Agent + follow redirect biar link presigned S3 (Spotify/YT) ga ke-403.
async function downloadTo(url, outPath, timeout = 180000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      redirect: "follow",
      headers: {
        // Banyak server (S3/CDN) nolak request tanpa UA yang wajar → kasih UA browser.
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        "Accept": "*/*",
      },
    });
    if (!res.ok) {
      // Kasih pesan lebih jelas buat 403 (link expired / butuh header)
      if (res.status === 403) throw new Error("download 403 (link download kedaluwarsa atau ditolak server — coba ulang command)");
      throw new Error("download HTTP " + res.status);
    }
    const buf = Buffer.from(await res.arrayBuffer());
    if (!buf.length) throw new Error("file kosong");
    fs.writeFileSync(outPath, buf);
    return buf.length;
  } finally { clearTimeout(t); }
}

// Format detik → M:SS
function fmtDur(sec) {
  sec = Math.round(Number(sec) || 0);
  const m = Math.floor(sec / 60), s = sec % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

module.exports.commands = [
  // ── .yttomp4 ──
  {
    name: "yttomp4",
    description: "Download video YouTube jadi MP4 (.yttomp4 <url>) — butuh APIFY_API_TOKEN",
    category: "Downloader",
    handler: async (event, args, ctx) => {
      const token = process.env.APIFY_API_TOKEN;
      if (!token) return _fmt.reply(event, `🔑 Owner belum set <code>APIFY_API_TOKEN</code> di <code>gwajib.env</code>.\nDaftar: https://console.apify.com`);
      const url = await getArg(event, args);
      if (!url) return _fmt.reply(event, `❌ Format: <code>.yttomp4 https://youtube.com/watch?v=...</code>`);
      if (!/youtu\.?be/i.test(url)) return _fmt.reply(event, `❌ URL itu bukan YouTube.`);

      let thinking;
      try { thinking = await event.message.reply({ message: `<blockquote><b>📥 Memproses video... (bisa 1-3 menit)</b></blockquote>`, parseMode: "html" }); } catch {}

      let tmpDir;
      try {
        // Jalanin Apify actor (sync) — actor id: UUhJDfKJT2SsXdclR
        const input = {
          videos: [{ url }],
          preferredQuality: "1080p",
          preferredFormat: "mp4",
          filenameTemplateParts: ["title"],
        };
        const runRes = await fetch(
          `https://api.apify.com/v2/acts/UUhJDfKJT2SsXdclR/run-sync-get-dataset-items?token=${encodeURIComponent(token)}`,
          { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) }
        );
        if (!runRes.ok) {
          let msg = "HTTP " + runRes.status;
          try { const j = await runRes.json(); msg = j?.error?.message || msg; } catch {}
          throw new Error(msg);
        }
        const items = await runRes.json();
        const item = Array.isArray(items) ? items[0] : (items?.items ? items.items[0] : null);
        if (!item) throw new Error("Actor tidak mengembalikan hasil. Cek URL / kuota Apify.");

        // Ambil URL file: downloadedFileUrl / Downloaded File
        const fileUrl = item.downloadedFileUrl || item["Downloaded File"] || item.downloadUrl || item.url;
        if (!fileUrl) throw new Error("Link download MP4 tidak ditemukan di hasil.");

        // Info
        const title = item.title || item.videoTitle || "Video";
        const channel = item.channelName || item.channel || item.author || item.uploader || "-";
        const channelUrl = item.channelUrl || item.channelUsername || "";
        const durationSec = item.duration || item.lengthSeconds || item.durationSeconds || 0;
        const durLabel = typeof durationSec === "string" && durationSec.includes(":") ? durationSec : fmtDur(durationSec);

        if (thinking) { try { await thinking.edit({ text: `<blockquote><b>📥 Mengunduh MP4 & mengirim...</b></blockquote>`, parseMode: "html" }); } catch {} }

        tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "ytmp4_"));
        const out = path.join(tmpDir, "video.mp4");
        await downloadTo(fileUrl, out);

        const chanLabel = channelUrl
          ? `${_fmt.esc(channel)} (${_fmt.esc(channelUrl.startsWith("@") ? channelUrl : "@" + channelUrl.replace(/^https?:\/\/(www\.)?youtube\.com\/@?/, "@").replace(/^@@/, "@"))})`
          : _fmt.esc(channel);
        const caption =
          `<b>Channel:</b> ${chanLabel}\n` +
          `<b>Panjang video:</b> ${_fmt.esc(durLabel)}\n` +
          `<b>Judul:</b> ${_fmt.esc(title)}`;

        await ctx.client.sendFile(event.message.peerId, {
          file: out, replyTo: event.message.id,
          caption, parseMode: "html",
          supportsStreaming: true,
        });
        if (thinking) { try { await thinking.delete(); } catch {} }
      } catch (e) {
        const err = `<blockquote><b>❌ Gagal: ${_fmt.esc(e.message)}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); } catch { try { await event.message.reply({ message: err, parseMode: "html" }); } catch {} } }
        else { try { await event.message.reply({ message: err, parseMode: "html" }); } catch {} }
      } finally {
        if (tmpDir) { try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {} }
      }
    },
  },

  // ── .spotify ──
  {
    name: "spotify",
    description: "Download lagu Spotify jadi MP3 (.spotify <url track>) — butuh RAPIDAPI_KEY",
    category: "Downloader",
    handler: async (event, args, ctx) => {
      const key = process.env.RAPIDAPI_KEY;
      if (!key) return _fmt.reply(event, `🔑 Owner belum set <code>RAPIDAPI_KEY</code> di <code>gwajib.env</code>.\nDaftar: https://rapidapi.com`);
      const url = await getArg(event, args);
      if (!url) return _fmt.reply(event, `❌ Format: <code>.spotify https://open.spotify.com/track/...</code>`);
      if (!/open\.spotify\.com\/track/i.test(url)) return _fmt.reply(event, `❌ URL itu bukan track Spotify.`);

      let thinking;
      try { thinking = await event.message.reply({ message: `<blockquote><b>🎵 Mengambil lagu...</b></blockquote>`, parseMode: "html" }); } catch {}

      let tmpDir;
      try {
        const api = `https://spotify-downloader9.p.rapidapi.com/downloadSong?songId=${encodeURIComponent(url)}`;
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 60000);
        let res;
        try {
          res = await fetch(api, {
            method: "GET",
            signal: ctrl.signal,
            headers: {
              "x-rapidapi-key": key,
              "x-rapidapi-host": "spotify-downloader9.p.rapidapi.com",
            },
          });
        } finally { clearTimeout(t); }

        const data = await res.json();
        if (!res.ok || !data?.success) {
          throw new Error(data?.message || data?.error || ("HTTP " + res.status));
        }
        const d = data.data || {};
        const dl = d.downloadLink;
        if (!dl) throw new Error("Link download MP3 tidak ditemukan.");

        const title = d.title || "Lagu";
        const artist = d.artist || "-";
        const album = d.album || "-";
        const id = d.id || "-";

        if (thinking) { try { await thinking.edit({ text: `<blockquote><b>🎵 Mengunduh MP3 & mengirim...</b></blockquote>`, parseMode: "html" }); } catch {} }

        tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "spot_"));
        const safe = (title + " - " + artist).replace(/[^\w\s.-]+/g, "_").slice(0, 80);
        const out = path.join(tmpDir, safe + ".mp3");
        await downloadTo(dl, out);

        const caption =
          `<b>Judul:</b> ${_fmt.esc(title)}\n` +
          `<b>Artist:</b> ${_fmt.esc(artist)}\n` +
          `<b>Album:</b> ${_fmt.esc(album)}\n` +
          `<b>ID:</b> <code>${_fmt.esc(id)}</code>`;

        const { Api } = require("telegram");
        await ctx.client.sendFile(event.message.peerId, {
          file: out, replyTo: event.message.id,
          caption, parseMode: "html",
          attributes: [
            new Api.DocumentAttributeAudio({
              title: title.slice(0, 64),
              performer: artist.slice(0, 64),
              duration: 0,
            }),
          ],
        });
        if (thinking) { try { await thinking.delete(); } catch {} }
      } catch (e) {
        const err = `<blockquote><b>❌ Gagal: ${_fmt.esc(e.message)}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); } catch { try { await event.message.reply({ message: err, parseMode: "html" }); } catch {} } }
        else { try { await event.message.reply({ message: err, parseMode: "html" }); } catch {} }
      } finally {
        if (tmpDir) { try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {} }
      }
    },
  },
];
