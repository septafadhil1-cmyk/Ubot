// ─────────────────────────────────────────
//  Plugin: Stopwatch (jam henti) — tersimpan permanen per ubot (tahan restart)
//  .swstart  → mulai stopwatch
//  .swlap    → catat lap (waktu berjalan sekarang)
//  .swstop   → stop + tampilkan total waktu
//  .swreset  → reset (hapus stopwatch berjalan)
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");

let cache = null; // ownerId(str) → { start: ts|null, laps: [ts] }

async function initStopwatch() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("stopwatch");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { start: d.start || null, laps: Array.isArray(d.laps) ? d.laps : [] };
      }
      console.log(`✅ [db] load stopwatch: ${docs.length} user`);
    } catch (e) { console.error("init stopwatch:", e.message); }
  }
}
function get(ownerId) { const id = String(ownerId); if (!cache) cache = {}; if (!cache[id]) cache[id] = { start: null, laps: [] }; return cache[id]; }
function save(ownerId) { store.upsert("stopwatch", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

// ms → "1j 02m 03d" / "02m 03d" / "3.4d"
function fmtDur(ms) {
  const totalS = ms / 1000;
  const h = Math.floor(totalS / 3600);
  const m = Math.floor((totalS % 3600) / 60);
  const s = Math.floor(totalS % 60);
  const parts = [];
  if (h) parts.push(`${h}j`);
  if (h || m) parts.push(`${String(m).padStart(2, "0")}m`);
  parts.push(`${String(s).padStart(2, "0")}d`);
  return parts.join(" ");
}

module.exports.initStopwatch = initStopwatch;
module.exports.commands = [
  {
    name: "swstart", description: "Mulai stopwatch", category: "Stopwatch",
    handler: async (event, args, ctx) => {
      const s = get(ctx.ownerId);
      if (s.start) return _fmt.reply(event, `⏱ Stopwatch udah jalan (${fmtDur(Date.now() - s.start)}). Pakai <code>.swstop</code> / <code>.swreset</code>.`);
      s.start = Date.now(); s.laps = [];
      save(ctx.ownerId);
      return _fmt.reply(event, `⏱ <b>Stopwatch dimulai!</b> Catat lap pakai <code>.swlap</code>.`);
    },
  },
  {
    name: "swlap", description: "Catat lap stopwatch", category: "Stopwatch",
    handler: async (event, args, ctx) => {
      const s = get(ctx.ownerId);
      if (!s.start) return _fmt.reply(event, `❌ Stopwatch belum jalan. Mulai pakai <code>.swstart</code>.`);
      s.laps.push(Date.now());
      save(ctx.ownerId);
      const lapLines = s.laps.map((t, i) => `Lap ${i + 1}: <b>${fmtDur(t - s.start)}</b>`).join("\n");
      return _fmt.reply(event, `🏁 <b>Lap ${s.laps.length}</b>\n\n${lapLines}`);
    },
  },
  {
    name: "swstop", description: "Stop stopwatch + total waktu", category: "Stopwatch",
    handler: async (event, args, ctx) => {
      const s = get(ctx.ownerId);
      if (!s.start) return _fmt.reply(event, `❌ Stopwatch belum jalan.`);
      const total = Date.now() - s.start;
      const laps = s.laps.length;
      s.start = null; s.laps = [];
      save(ctx.ownerId);
      return _fmt.reply(event, `⏹ <b>Stopwatch berhenti</b>\n\nTotal waktu: <b>${fmtDur(total)}</b>${laps ? `\nJumlah lap: ${laps}` : ""}`);
    },
  },
  {
    name: "swreset", description: "Reset stopwatch", category: "Stopwatch",
    handler: async (event, args, ctx) => {
      const s = get(ctx.ownerId);
      s.start = null; s.laps = [];
      save(ctx.ownerId);
      return _fmt.reply(event, `🔄 Stopwatch direset.`);
    },
  },
];
