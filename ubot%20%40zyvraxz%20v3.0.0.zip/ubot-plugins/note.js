// ─────────────────────────────────────────
//  Plugin: NOTE — catatan per-user, FULL FORMAT + GAMBAR
//  Format (tebal/miring/garis bawah/coret/mono/kutip/spoiler/link) disimpan
//  sebagai entities & dikirim ulang pakai formattingEntities (spoiler ikut jalan).
//  .addnote nama, isi   |  reply pesan/gambar + .addnote nama
//  .note  .delnote  .listnote  .editnote
// ─────────────────────────────────────────
const _fmt = require("./_format");
const notes = require("../lib/noteStore");
const { Api } = require("telegram");
const esc = _fmt.esc;

const KNOWN = ["Bold", "Italic", "Underline", "Strike", "Spoiler", "Code", "Pre", "Blockquote", "TextUrl"];

// GramJS entity → bentuk simpel yang bisa disimpan ke DB
function serializeEntities(entities) {
  const out = [];
  for (const e of entities || []) {
    const c = (e.className || (e.constructor && e.constructor.name) || "").replace("MessageEntity", "");
    if (!KNOWN.includes(c)) continue;
    const o = { t: c, o: e.offset, l: e.length };
    if (c === "TextUrl" && e.url) o.url = e.url;
    if (c === "Pre" && e.language) o.lang = e.language;
    out.push(o);
  }
  return out;
}
// bentuk simpel → Api entity (buat dikirim)
function toApiEntities(arr) {
  const out = [];
  for (const e of arr || []) {
    const o = e.o, l = e.l;
    if (!(l > 0)) continue;
    switch (e.t) {
      case "Bold": out.push(new Api.MessageEntityBold({ offset: o, length: l })); break;
      case "Italic": out.push(new Api.MessageEntityItalic({ offset: o, length: l })); break;
      case "Underline": out.push(new Api.MessageEntityUnderline({ offset: o, length: l })); break;
      case "Strike": out.push(new Api.MessageEntityStrike({ offset: o, length: l })); break;
      case "Spoiler": out.push(new Api.MessageEntitySpoiler({ offset: o, length: l })); break;
      case "Code": out.push(new Api.MessageEntityCode({ offset: o, length: l })); break;
      case "Pre": out.push(new Api.MessageEntityPre({ offset: o, length: l, language: e.lang || "" })); break;
      case "Blockquote": out.push(new Api.MessageEntityBlockquote({ offset: o, length: l })); break;
      case "TextUrl": if (e.url) out.push(new Api.MessageEntityTextUrl({ offset: o, length: l, url: e.url })); break;
    }
  }
  return out;
}

function isRealMedia(m) { return !!m && !/WebPage/.test((m.className || "").toString()); }

async function saveMedia(client, rm) {
  try {
    const fwd = await client.forwardMessages("me", { messages: [rm.id], fromPeer: rm.peerId });
    const m = Array.isArray(fwd) ? fwd[0] : fwd;
    if (m && m.id) return { savedId: m.id };
  } catch {}
  return null;
}

// Ambil isi dari pesan reply → { text, ents, media }
async function captureFromReply(client, rm) {
  const text = rm.message != null ? rm.message : (rm.rawText != null ? rm.rawText : (rm.text || ""));
  const ents = serializeEntities(rm.entities);
  let media = null;
  if (isRealMedia(rm.media)) media = await saveMedia(client, rm);
  return { text, ents, media };
}

// Ambil isi inline (setelah koma) DARI pesan command + format-nya
function captureInline(event, inlineText) {
  const rawMsg = event.message.message || "";
  const commaPos = rawMsg.indexOf(",");
  let isiStart = commaPos + 1;
  while (isiStart < rawMsg.length && rawMsg[isiStart] === " ") isiStart++;
  const text = commaPos === -1 ? inlineText : rawMsg.slice(isiStart);
  const ents = [];
  for (const e of event.message.entities || []) {
    if (e.offset + e.length <= isiStart) continue;
    const c = (e.className || "").replace("MessageEntity", "");
    if (!KNOWN.includes(c)) continue;
    const cut = Math.max(0, isiStart - e.offset);
    const o = { t: c, o: Math.max(0, e.offset - isiStart), l: e.length - cut };
    if (o.l <= 0) continue;
    if (c === "TextUrl" && e.url) o.url = e.url;
    if (c === "Pre" && e.language) o.lang = e.language;
    ents.push(o);
  }
  return { text, ents };
}

// gabung 2 set entities (A + "\n" + B) → offset B digeser
function combineEnts(aLen, entsA, entsB) {
  const shift = aLen + 1;
  return [...(entsA || []), ...((entsB || []).map(e => ({ ...e, o: e.o + shift })))];
}

// Kirim note (media kalau ada, lalu teks dengan format asli)
async function showNote(event, client, n) {
  const apiEnts = toApiEntities(n.ents);
  if (n.media && n.media.savedId) {
    try {
      const msgs = await client.getMessages("me", { ids: [n.media.savedId] });
      const m = msgs && msgs[0];
      if (m && m.media) {
        await client.sendFile(event.message.peerId, {
          file: m.media,
          caption: n.text || undefined,
          formattingEntities: apiEnts.length ? apiEnts : undefined,
          replyTo: event.message.id,
          forceDocument: false,
        });
        return;
      }
    } catch {}
  }
  try {
    if (n.html) return await event.message.reply({ message: n.text || "(kosong)", parseMode: "html" }); // back-compat note lama
    return await event.message.reply({ message: n.text || "(note kosong)", formattingEntities: apiEnts.length ? apiEnts : undefined });
  } catch {
    return event.message.reply({ message: n.text || "(note kosong)" });
  }
}

const commands = [
  {
    name: "addnote", category: "Note",
    description: "Simpan note: .addnote nama, isi — atau reply pesan/gambar lalu .addnote nama (format & media ikut)",
    handler: async (event, args, ctx) => {
      const client = ctx.client || event.client;
      const raw = args.join(" ");
      let name, inlineText = "";
      const ci = raw.indexOf(",");
      if (ci !== -1) { name = raw.slice(0, ci).trim(); inlineText = raw.slice(ci + 1).trim(); }
      else { name = raw.trim(); }
      if (!name) return _fmt.reply(event, `❌ Format: <code>${ctx.prefix}addnote nama, isi</code>\natau reply pesan/gambar lalu <code>${ctx.prefix}addnote nama</code>`);

      let text = "", ents = null, media = null, rm = null;
      if (event.message.replyTo) { try { rm = await event.message.getReplyMessage(); } catch {} }

      if (inlineText) {
        const cap = captureInline(event, inlineText);
        text = cap.text; ents = cap.ents;
        if (rm && isRealMedia(rm.media)) media = await saveMedia(client, rm);
      } else if (rm) {
        const cap = await captureFromReply(client, rm);
        text = cap.text; ents = cap.ents; media = cap.media;
      } else {
        return _fmt.reply(event, `❌ Isi note kosong. Tambahin isi pakai koma, atau reply sebuah pesan/gambar.`);
      }

      const r = notes.addNote(ctx.ownerId, name, text, { ents, media });
      if (r.error) return _fmt.reply(event, "❌ " + r.error);
      const tag = media ? " 🖼️ (+media)" : "";
      return _fmt.reply(event, _fmt.wrap(`✅ Note <b>#${r.note.num}</b> — "<b>${esc(r.note.name)}</b>" disimpan${tag}.\nLihat: <code>${ctx.prefix}note ${r.note.num}</code>`));
    },
  },
  {
    name: "note", category: "Note",
    description: "Lihat isi note: .note nama/nomor",
    handler: async (event, args, ctx) => {
      if (!args.length) return _fmt.reply(event, `❌ Format: <code>${ctx.prefix}note nama/nomor</code>`);
      const n = notes.findNote(ctx.ownerId, args.join(" "));
      if (!n) return _fmt.reply(event, `❌ Note ga ketemu. Cek daftarnya: <code>${ctx.prefix}listnote</code>`);
      return showNote(event, ctx.client || event.client, n);
    },
  },
  {
    name: "delnote", category: "Note",
    description: "Hapus note: .delnote nama/nomor",
    handler: async (event, args, ctx) => {
      if (!args.length) return _fmt.reply(event, `❌ Format: <code>${ctx.prefix}delnote nama/nomor</code>`);
      const r = notes.delNote(ctx.ownerId, args.join(" "));
      if (r.error) return _fmt.reply(event, "❌ " + r.error);
      return _fmt.reply(event, _fmt.wrap(`🗑️ Note <b>#${r.note.num}</b> — "<b>${esc(r.note.name)}</b>" dihapus.`));
    },
  },
  {
    name: "listnote", category: "Note",
    description: "Lihat daftar semua note kamu",
    handler: async (event, args, ctx) => {
      const list = notes.listNotes(ctx.ownerId);
      if (!list.length) return _fmt.reply(event, `📭 Belum ada note. Bikin: <code>${ctx.prefix}addnote nama, isi</code>`);
      const body = list.map(n => `<b>#${n.num}</b> — ${esc(n.name)}${n.media ? " 🖼️" : ""}`).join("\n");
      return _fmt.reply(event, _fmt.wrap(`📒 <b>Daftar Note</b> (${list.length})\n\n${body}\n\nLihat: <code>${ctx.prefix}note &lt;nomor&gt;</code>`));
    },
  },
  {
    name: "editnote", category: "Note",
    description: "Edit note: .editnote nama/nomor [replace|atas|bawah] teks (atau reply)",
    handler: async (event, args, ctx) => {
      const client = ctx.client || event.client;
      if (args.length < 1) return _fmt.reply(event, `❌ Format: <code>${ctx.prefix}editnote nama/nomor [replace|atas|bawah] teks</code>\n\n• <b>replace</b> = ganti total\n• <b>atas</b> = tambah di atas\n• <b>bawah</b> = tambah di bawah`);
      const key = args[0];
      let mode = "replace", rest = args.slice(1);
      const m2 = (args[1] || "").toLowerCase();
      if (["replace", "atas", "bawah", "all", "ganti"].includes(m2)) {
        mode = (m2 === "all" || m2 === "ganti") ? "replace" : m2;
        rest = args.slice(2);
      }
      const inlineNew = rest.join(" ").trim();
      let nText = "", nEnts = [];
      if (inlineNew) {
        // hitung offset bagian teks baru di pesan command
        const rawMsg = event.message.message || "";
        const idx = rawMsg.indexOf(inlineNew);
        const start = idx === -1 ? 0 : idx;
        nText = inlineNew;
        for (const e of event.message.entities || []) {
          if (e.offset + e.length <= start) continue;
          const c = (e.className || "").replace("MessageEntity", "");
          if (!KNOWN.includes(c)) continue;
          const cut = Math.max(0, start - e.offset);
          const o = { t: c, o: Math.max(0, e.offset - start), l: e.length - cut };
          if (o.l <= 0 || o.o >= nText.length) continue;
          if (c === "TextUrl" && e.url) o.url = e.url;
          if (c === "Pre" && e.language) o.lang = e.language;
          nEnts.push(o);
        }
      } else if (event.message.replyTo) {
        try { const rm = await event.message.getReplyMessage(); const cap = await captureFromReply(client, rm); nText = cap.text; nEnts = cap.ents; } catch {}
      }
      if (!nText) return _fmt.reply(event, `❌ Teks edit kosong. Kasih teks atau reply pesan.`);

      const cur = notes.findNote(ctx.ownerId, key);
      if (!cur) return _fmt.reply(event, `❌ Note ga ketemu.`);

      let finalText, finalEnts;
      if (mode === "atas") { finalText = nText + "\n" + (cur.text || ""); finalEnts = combineEnts(nText.length, nEnts, cur.ents); }
      else if (mode === "bawah") { finalText = (cur.text || "") + "\n" + nText; finalEnts = combineEnts((cur.text || "").length, cur.ents, nEnts); }
      else { finalText = nText; finalEnts = nEnts; }

      const r = notes.setNote(ctx.ownerId, key, finalText, finalEnts);
      if (r.error) return _fmt.reply(event, "❌ " + r.error);
      const label = mode === "atas" ? "ditambah di atas ⬆️" : mode === "bawah" ? "ditambah di bawah ⬇️" : "diganti total 🔄";
      return _fmt.reply(event, _fmt.wrap(`✏️ Note <b>#${r.note.num}</b> — "<b>${esc(r.note.name)}</b>" ${label}.`));
    },
  },
];

module.exports = { commands };
