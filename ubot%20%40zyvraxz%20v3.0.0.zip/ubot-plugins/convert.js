// ─────────────────────────────────────────
//  Plugin: Converter satuan (offline, REAL)
// ─────────────────────────────────────────

const _fmt = require("./_format");

function conv(event, args, units, label) {
  const val = parseFloat(args[0]);
  const from = (args[1] || "").toLowerCase();
  const to = (args[2] || "").toLowerCase();
  if (isNaN(val) || !units[from] || !units[to]) {
    return _fmt.reply(event, `❌ Format: <code>.${label} 10 ${Object.keys(units)[0]} ${Object.keys(units)[1]}</code>\nSatuan: ${Object.keys(units).join(", ")}`);
  }
  const result = val * units[from] / units[to];
  return _fmt.reply(event, `📐 <b>${val} ${from}</b> = <b>${parseFloat(result.toFixed(6))} ${to}</b>`);
}

const commands = [
  { name: "length", description: "Konversi panjang (.length 10 m km)", category: "Convert",
    handler: (e, a) => conv(e, a, { mm:0.001, cm:0.01, m:1, km:1000, inch:0.0254, ft:0.3048, mi:1609.34, yard:0.9144 }, "length") },
  { name: "weight", description: "Konversi berat (.weight 5 kg g)", category: "Convert",
    handler: (e, a) => conv(e, a, { mg:0.001, g:1, kg:1000, ton:1000000, oz:28.35, lb:453.6 }, "weight") },
  { name: "speed", description: "Konversi kecepatan (.speed 100 kmh ms)", category: "Convert",
    handler: (e, a) => conv(e, a, { ms:1, kmh:0.277778, mph:0.44704, knot:0.514444 }, "speed") },
  { name: "area", description: "Konversi luas (.area 100 m2 km2)", category: "Convert",
    handler: (e, a) => conv(e, a, { m2:1, km2:1000000, cm2:0.0001, ha:10000, acre:4046.86, ft2:0.092903 }, "area") },
  { name: "volume", description: "Konversi volume (.volume 1 l ml)", category: "Convert",
    handler: (e, a) => conv(e, a, { ml:0.001, l:1, m3:1000, gallon:3.78541, cup:0.236588 }, "volume") },
  { name: "datasize", description: "Konversi ukuran data (.datasize 1 gb mb)", category: "Convert",
    handler: (e, a) => conv(e, a, { b:1, kb:1024, mb:1048576, gb:1073741824, tb:1099511627776 }, "datasize") },
  { name: "time2", description: "Konversi waktu (.time2 1 jam menit)", category: "Convert",
    handler: (e, a) => conv(e, a, { detik:1, menit:60, jam:3600, hari:86400, minggu:604800 }, "time2") },
  { name: "pressure", description: "Konversi tekanan (.pressure 1 atm pa)", category: "Convert",
    handler: (e, a) => conv(e, a, { pa:1, kpa:1000, bar:100000, atm:101325, psi:6894.76 }, "pressure") },
  { name: "energy", description: "Konversi energi (.energy 1 kcal joule)", category: "Convert",
    handler: (e, a) => conv(e, a, { joule:1, kjoule:1000, kcal:4184, cal:4.184, wh:3600 }, "energy") },
  { name: "angle", description: "Konversi sudut (.angle 180 derajat radian)", category: "Convert",
    handler: (e, a) => conv(e, a, { derajat:1, radian:57.2958, gradian:0.9 }, "angle") },
];

module.exports.commands = commands;
