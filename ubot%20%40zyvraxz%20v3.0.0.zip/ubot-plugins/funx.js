// ─────────────────────────────────────────
//  Plugin: Fun & Random (semua REAL, offline)
// ─────────────────────────────────────────

const _fmt = require("./_format");

function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
async function getText(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) { try { const r = await event.message.getReplyMessage(); t = r?.text || ""; } catch {} }
  return t;
}

const EIGHTBALL = ["Ya!","Tidak.","Mungkin.","Pasti!","Jangan harap.","Coba lagi nanti.","Sudah pasti ya.","Tidak mungkin.","Kemungkinan besar.","Ragu-ragu.","Tanya lagi nanti.","Ya, tentu saja!"];
const RPS = ["batu","gunting","kertas"];

const commands = [
  { name: "dice", description: "Lempar dadu (1-6)", category: "Fun",
    handler: e => _fmt.reply(e, `🎲 Dadu: <b>${rand(1,6)}</b>`) },
  { name: "coin", description: "Lempar koin", category: "Fun",
    handler: e => _fmt.reply(e, `🪙 ${pick(["Kepala (Heads)","Ekor (Tails)"])}`) },
  { name: "8ball", description: "Bola ajaib jawab pertanyaan", category: "Fun",
    handler: (e, a) => a.length ? _fmt.reply(e, `🎱 ${pick(EIGHTBALL)}`) : _fmt.reply(e, `❌ Tanya sesuatu: <code>.8ball apakah hari ini hujan?</code>`) },
  { name: "rate", description: "Kasih rating random ke sesuatu", category: "Fun",
    handler: (e, a) => _fmt.reply(e, `⭐ ${a.join(" ")||"itu"} dapat nilai <b>${rand(0,100)}/100</b>`) },
  { name: "ship", description: "Hitung kecocokan (.ship A B)", category: "Fun",
    handler: (e, a) => _fmt.reply(e, `💕 Kecocokan ${a[0]||"?"} & ${a[1]||"?"}: <b>${rand(0,100)}%</b>`) },
  { name: "choose", description: "Pilih acak (.choose a b c)", category: "Fun",
    handler: (e, a) => a.length ? _fmt.reply(e, `🤔 Aku pilih: <b>${pick(a)}</b>`) : _fmt.reply(e, `❌ Kasih pilihan: <code>.choose nasi mie roti</code>`) },
  { name: "rps", description: "Suit batu-gunting-kertas", category: "Fun",
    handler: (e, a) => { const bot=pick(RPS); return _fmt.reply(e, `✊ Aku pilih: <b>${bot}</b>`); } },
  { name: "slot", description: "Mesin slot", category: "Fun",
    handler: e => { const s=["🍒","🍋","🍊","🍉","⭐","7️⃣"]; const r=[pick(s),pick(s),pick(s)]; const win=r[0]===r[1]&&r[1]===r[2]; return _fmt.reply(e, `🎰 [ ${r.join(" | ")} ]\n${win?"🎉 JACKPOT!":"Coba lagi!"}`); } },
  { name: "yesno", description: "Jawaban ya atau tidak", category: "Fun",
    handler: e => _fmt.reply(e, pick(["✅ Ya","❌ Tidak"])) },
  { name: "randomnumber", description: "Angka acak (.randomnumber 1 100)", category: "Fun",
    handler: (e, a) => { const min=parseInt(a[0])||1, max=parseInt(a[1])||100; return _fmt.reply(e, `🔢 <b>${rand(Math.min(min,max),Math.max(min,max))}</b>`); } },
  { name: "color", description: "Generate warna hex acak", category: "Fun",
    handler: e => { const h="#"+Math.floor(Math.random()*16777215).toString(16).padStart(6,"0"); return _fmt.reply(e, `🎨 Warna: <code>${h}</code>`); } },
  { name: "password", description: "Generate password kuat (.password 16)", category: "Fun",
    handler: (e, a) => { const len=Math.min(Math.max(parseInt(a[0])||12,4),64); const ch="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*"; let p=""; for(let i=0;i<len;i++)p+=ch[rand(0,ch.length-1)]; return _fmt.reply(e, `🔐 Password:\n<code>${_fmt.esc(p)}</code>`); } },
  { name: "uuid", description: "Generate UUID v4", category: "Fun",
    handler: e => _fmt.reply(e, `🆔 <code>${require("crypto").randomUUID()}</code>`) },
  { name: "roll", description: "Roll dadu custom (.roll 2d20)", category: "Fun",
    handler: (e, a) => { const m=(a[0]||"1d6").match(/(\d+)d(\d+)/i); if(!m)return _fmt.reply(e,`❌ Format: <code>.roll 2d20</code>`); const n=Math.min(parseInt(m[1]),100),s=parseInt(m[2]); let tot=0,res=[]; for(let i=0;i<n;i++){const r=rand(1,s);res.push(r);tot+=r;} return _fmt.reply(e, `🎲 [${res.join(", ")}] = <b>${tot}</b>`); } },
  { name: "picknumber", description: "Pilih angka keberuntungan", category: "Fun",
    handler: e => _fmt.reply(e, `🍀 Angka keberuntunganmu: <b>${rand(1,99)}</b>`) },
  { name: "mood", description: "Cek mood random", category: "Fun",
    handler: e => _fmt.reply(e, `😊 Mood: <b>${pick(["Senang 😄","Sedih 😢","Marah 😠","Santai 😎","Lelah 😴","Semangat 🔥","Bingung 😵","Cinta 🥰"])}</b>`) },
  { name: "iq", description: "Cek IQ (just for fun)", category: "Fun",
    handler: (e, a) => _fmt.reply(e, `🧠 IQ ${a.join(" ")||"kamu"}: <b>${rand(50,160)}</b>`) },
  { name: "gay", description: "Gay meter (just for fun)", category: "Fun",
    handler: (e, a) => _fmt.reply(e, `🌈 ${a.join(" ")||"kamu"}: <b>${rand(0,100)}%</b>`) },
  { name: "simp", description: "Simp meter (just for fun)", category: "Fun",
    handler: (e, a) => _fmt.reply(e, `😍 Simp level ${a.join(" ")||"kamu"}: <b>${rand(0,100)}%</b>`) },
  { name: "fact", description: "Fakta random", category: "Fun",
    handler: e => _fmt.reply(e, `💡 ${pick(["Madu tidak pernah basi.","Gurita punya 3 jantung.","Pisang itu buah beri secara botani.","Manusia berbagi 60% DNA dengan pisang.","Cumi raksasa punya mata sebesar piring.","Sehari di Venus lebih lama dari setahunnya."])}`) },
  { name: "jokes", description: "Lelucon random", category: "Fun",
    handler: e => _fmt.reply(e, `😂 ${pick(["Kenapa programmer benci alam? Banyak bug.","Apa bedanya kamu sama bintang? Bintang di langit, kamu di hatiku.","Kenapa komputer dibawa ke dokter? Kena virus.","Apa makanan paling sabar? Tahu, karna tahu diri."])}`) },
];

module.exports.commands = commands;
