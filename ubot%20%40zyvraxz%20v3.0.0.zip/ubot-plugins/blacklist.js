// ─────────────────────────────────────────
//  Plugin: Blacklist / CFD (multi-user / per-ownerId)
//  .addbl  → tandai chat ini di blacklist (TIDAK akan dikirim promosi CFD nanti)
//  .delbl  → hapus dari blacklist
//  .listbl → lihat daftar blacklist
//  Data per ownerId — dipakai fitur CFD (promosi massal) nanti
// ─────────────────────────────────────────
const _fmt = require("./_format");

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "blacklist_data.json");

// ── IN-MEMORY CACHE (MongoDB = sumber utama) ──
let blCache = null;
const mongo = require("../lib/store");

function loadDB() {
  if (blCache) return blCache;
  try { blCache = JSON.parse(fs.readFileSync(DB_PATH, "utf8")); } catch { blCache = {}; }
  return blCache;
}
function saveDB(db) {
  blCache = db;
}

// STARTUP: load dari Mongo + import blacklist_data.json lama lalu HAPUS
async function initBlacklist() {
  blCache = {};
  if (mongo.isReady()) {
    const docs = await mongo.all("blacklist");
    for (const d of docs) blCache[d._id] = d.chats || {};
    console.log(`✅ [mongo] load blacklist: ${docs.length} owner`);
  }
  if (fs.existsSync(DB_PATH)) {
    try {
      const old = JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
      for (const [owner, bl] of Object.entries(old)) {
        blCache[owner] = { ...(blCache[owner] || {}), ...bl };
        if (mongo.isReady()) mongo.upsert("blacklist", owner, { chats: blCache[owner] }).catch(() => {});
      }
      fs.unlinkSync(DB_PATH);
      console.log(`📥 [mongo] blacklist_data.json diimport (${Object.keys(old).length} owner) & dihapus`);
    } catch (e) { console.error("[mongo] import blacklist:", e.message); }
  }
}
async function refreshBlacklist() {
  if (!mongo.isReady() || !blCache) return;
  try {
    const docs = await mongo.all("blacklist");
    const fresh = {};
    for (const d of docs) fresh[d._id] = d.chats || {};
    blCache = fresh;
  } catch {}
}
module.exports.initBlacklist = initBlacklist;
module.exports.refreshBlacklist = refreshBlacklist;
function getOwnerBL(ownerId) {
  const db = loadDB();
  return db[ownerId] || {};
}
function setOwnerBL(ownerId, blData) {
  const db = loadDB();
  db[ownerId] = blData;
  saveDB(db);
  mongo.upsert("blacklist", ownerId, { chats: blData }).catch(() => {});
}

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
async function reply(event, html) {
  return _fmt.reply(event, html);
}

// Normalisasi ID biar match walau format beda (-100xxx vs xxx)
function normId(id) {
  let s = String(id);
  if (s.startsWith("-100")) return s.slice(4);
  if (s.startsWith("-")) return s.slice(1);
  return s;
}

// Export buat dipakai fitur CFD nanti — cek apakah chat di-blacklist
module.exports.getOwnerBL = getOwnerBL;
module.exports.isBlacklisted = (ownerId, chatId) => {
  const bl = getOwnerBL(ownerId);
  const target = normId(chatId);
  return Object.keys(bl).some(k => normId(k) === target);
};
// Tambah blacklist by ID (dipakai CFD buat auto-blacklist grup yang nge-ban akun)
module.exports.addById = function (ownerId, rawId, name) {
  try {
    if (rawId == null) return false;
    const id = String(rawId);
    const n = normId(id);
    const bl = getOwnerBL(ownerId);
    if (Object.keys(bl).some(k => normId(k) === n)) return false; // udah ada
    bl[id] = { id, name: name || id, type: "group", auto: true, addedAt: Date.now() };
    setOwnerBL(ownerId, bl);
    return true;
  } catch { return false; }
};

module.exports.commands = [
  {
    name: "addbl",
    description: "Blacklist chat/grup ini (tidak akan dikirim promosi CFD)",
    category: "Blacklist",
    handler: async (event, args, ctx) => {
      const msg = event.message;
      try {
        const chat = await msg.getChat();
        const chatId = chat.id.toString();
        const chatName = chat.title || chat.firstName || chat.username || chatId;
        const chatType = chat.className === "User" ? "user" : "group";

        const bl = getOwnerBL(ctx.ownerId);
        if (bl[chatId]) return reply(event, `⚠️ <b>${esc(chatName)}</b> sudah ada di blacklist.`);

        bl[chatId] = { id: chatId, name: chatName, type: chatType, username: chat.username || null, addedAt: Date.now() };
        setOwnerBL(ctx.ownerId, bl);

        return reply(event,
          `🚫 <b>Ditambahkan ke Blacklist CFD</b>\n\n` +
          `<b>Nama:</b> ${esc(chatName)}\n` +
          `<b>Tipe:</b> ${chatType === "user" ? "👤 User" : "👥 Grup"}\n` +
          `<b>ID:</b> <code>${chatId}</code>\n\n` +
          `<i>Chat ini TIDAK akan menerima pesan promosi CFD.</i>\n` +
          `<i>Total blacklist: ${Object.keys(bl).length}</i>`
        );
      } catch (e) {
        console.error("addbl error:", e.message);
        return reply(event, `❌ Gagal: ${esc(e.message)}`);
      }
    },
  },
  {
    name: "delbl",
    description: "Hapus chat/grup ini dari blacklist CFD",
    category: "Blacklist",
    handler: async (event, args, ctx) => {
      const msg = event.message;
      try {
        const chat = await msg.getChat();
        const chatId = chat.id.toString();
        const chatName = chat.title || chat.firstName || chat.username || chatId;

        const bl = getOwnerBL(ctx.ownerId);
        if (!bl[chatId]) return reply(event, `ℹ️ <b>${esc(chatName)}</b> tidak ada di blacklist.`);

        delete bl[chatId];
        setOwnerBL(ctx.ownerId, bl);

        return reply(event,
          `✅ <b>Dihapus dari Blacklist CFD</b>\n\n` +
          `<b>Nama:</b> ${esc(chatName)}\n\n` +
          `<i>Chat ini sekarang AKAN menerima promosi CFD lagi.</i>\n` +
          `<i>Total blacklist: ${Object.keys(bl).length}</i>`
        );
      } catch (e) {
        console.error("delbl error:", e.message);
        return reply(event, `❌ Gagal: ${esc(e.message)}`);
      }
    },
  },
  {
    name: "listbl",
    description: "Lihat daftar blacklist CFD kamu",
    category: "Blacklist",
    handler: async (event, args, ctx) => {
      const bl = getOwnerBL(ctx.ownerId);
      const entries = Object.values(bl);
      if (!entries.length) return reply(event, `📋 <b>Blacklist Kosong</b>\n\nBelum ada chat yang di-blacklist dari CFD.`);
      const lines = [`📋 <b>Daftar Blacklist CFD</b> (${entries.length})\n`];
      entries.forEach((e, i) => {
        const icon = e.type === "user" ? "👤" : "👥";
        const uname = e.username ? ` (@${esc(e.username)})` : "";
        lines.push(`${i + 1}. ${icon} <b>${esc(e.name)}</b>${uname}\n    <code>${e.id}</code>`);
      });
      return reply(event, lines.join("\n"));
    },
  },
];
