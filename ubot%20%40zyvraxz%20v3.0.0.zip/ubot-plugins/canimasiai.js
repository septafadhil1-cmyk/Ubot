// ─────────────────────────────────────────
//  Plugin: canimasiai — bikin animasi ASCII pakai AI
//   • .canimasiai {prompt}
//
//  AI (Groq qwen/qwen3.6-27b, fallback Cerebras) baca prompt, boleh nanya balik
//  (Q&A tombol via manager), lalu bikin frame animasi & simpan ke DB (kayak .canimasi).
//
//  Karena userbot (MTProto) ga bisa nangkep callback tombol, Q&A-nya diproxy lewat
//  manager bot: userbot kirim inline query "canimasiai <sid>", manager tampilkan
//  pertanyaan+tombol, manager handle callback, simpan jawaban, lanjut step berikutnya.
//
//  Butuh GROQ_API_KEY (fallback CEREBRAS_API_KEY).
// ─────────────────────────────────────────
const _fmt = require("./_format");
const animasi = require("../lib/animasiStore");

const GROQ_BASE = "https://api.groq.com/openai/v1/chat/completions";
const CEREBRAS_BASE = "https://api.cerebras.ai/v1/chat/completions";
const AI_MODEL_GROQ = "qwen/qwen3.6-27b";       // model sama kayak .ubot
const AI_MODEL_CEREBRAS = "gpt-oss-120b";        // fallback

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function isLimitError(status, msg) {
  if (status === 429) return true;
  const m = String(msg || "").toLowerCase();
  return /rate.?limit|too many requests|quota|limit reached|exceeded|insufficient|tpm|rpm|over capacity|429/.test(m);
}

// Panggil AI: coba Groq dulu, kalau limit → Cerebras. Return {content, provider}
async function callAI(messages, timeout = 60000) {
  const groqKey = process.env.GROQ_API_KEY;
  const cereKey = process.env.CEREBRAS_API_KEY;
  const body = (model) => ({ model, messages, temperature: 0.6, max_tokens: 1500, response_format: { type: "json_object" } });

  async function call(url, key, model) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeout);
    try {
      const res = await fetch(url, {
        method: "POST", signal: ctrl.signal,
        headers: { "Content-Type": "application/json", "Authorization": "Bearer " + key },
        body: JSON.stringify(body(model)),
      });
      const data = await res.json();
      if (!res.ok) { const e = new Error(data?.error?.message || ("HTTP " + res.status)); e.status = res.status; throw e; }
      return data?.choices?.[0]?.message?.content || "";
    } finally { clearTimeout(t); }
  }

  // Groq utama
  if (groqKey) {
    try {
      const out = await call(GROQ_BASE, groqKey, AI_MODEL_GROQ);
      return { content: out, provider: `Qwen3.6-27b (Groq)` };
    } catch (e) {
      if (!(isLimitError(e.status, e.message) && cereKey)) {
        if (!cereKey) throw e; // ga ada fallback
        // error lain + ada cerebras → tetap coba cerebras
      }
    }
  }
  // Cerebras fallback
  if (cereKey) {
    const out = await call(CEREBRAS_BASE, cereKey, AI_MODEL_CEREBRAS);
    return { content: out, provider: `GPT-OSS-120b (Cerebras)` };
  }
  throw new Error("GROQ_API_KEY belum diisi (dan CEREBRAS_API_KEY juga kosong).");
}

// System prompt: AI jadi "animation designer" yang balikin JSON terstruktur.
function buildSystem() {
  return [
    "Kamu AI perancang animasi teks ASCII buat Telegram userbot. User kasih prompt, kamu bikin animasi frame-by-frame.",
    "Animasi = beberapa 'frame' (potongan teks/ASCII). Tiap frame ditampilkan bergantian dengan delay, jadi kelihatan seperti bergerak.",
    "",
    "Kamu HARUS balas dalam JSON valid saja (tanpa markdown, tanpa ```), salah satu dari 2 bentuk:",
    "",
    "BENTUK A — kalau kamu butuh nanya ke user (maksimal tanya kalau memang perlu; boleh 1-3 pertanyaan):",
    '{ "action": "ask", "questions": [ { "q": "pertanyaan singkat", "options": ["opsi1","opsi2"] } ] }',
    "  • options: 2 sampai 5 pilihan singkat. User akan pilih salah satu (tombol).",
    "",
    "BENTUK B — kalau sudah cukup jelas / semua pertanyaan terjawab, hasilkan animasinya:",
    '{ "action": "done", "name": "nama_singkat_tanpa_spasi", "desc": "deskripsi singkat", "delay": 0.5, "frames": ["frame1","frame2","frame3", "..."] }',
    "  • name: 1 kata (huruf/angka/_), dipakai user buat .animasi <name>.",
    "  • delay: detik per-frame (0.2 - 2.0).",
    "  • frames: array string, MINIMAL 3 frame, maksimal 30. Tiap frame teks utuh (boleh multi-baris pakai \\n).",
    "  • Buat animasinya benar-benar sesuai prompt user (arah gerak, teks, dll). Frame harus beda-beda biar keliihatan bergerak.",
    "",
    "Jangan campur bentuk A & B. Kalau ragu sedikit saja masih boleh langsung 'done'. Jangan bertele-tele.",
  ].join("\n");
}

// Bikin daftar 'langkah' naratif (buat progress) — AI yang namain via field steps (opsional).
// Kita generate langkah default kalau AI ga ngasih.

// ── Sesi canimasiai per-owner (in-memory) ──
//  ownerId → { prompt, messages:[], questions:[], qIdx, answers:[], provider, ts, statusMsg }
const aiSessions = new Map();
const AI_TTL = 10 * 60 * 1000;
function getSess(id) { const s = aiSessions.get(String(id)); if (!s) return null; if (Date.now() - s.ts > AI_TTL) { aiSessions.delete(String(id)); return null; } return s; }
function setSess(id, s) { s.ts = Date.now(); aiSessions.set(String(id), s); }
function clearSess(id) { aiSessions.delete(String(id)); }

// Ambil objek JSON dari teks AI (jaga-jaga ada teks tambahan)
function parseAIJson(txt) {
  if (!txt) return null;
  let s = String(txt).trim();
  // buang code fence kalau ada
  s = s.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  try { return JSON.parse(s); } catch {}
  // coba ambil { ... } terluar
  const a = s.indexOf("{"), b = s.lastIndexOf("}");
  if (a >= 0 && b > a) { try { return JSON.parse(s.slice(a, b + 1)); } catch {} }
  return null;
}

// Edit pesan status (progress) di userbot
async function editStatus(statusMsg, html) {
  try { await statusMsg.edit({ text: html, parseMode: "html" }); return true; } catch { return false; }
}
function stepView(lines) {
  return `<blockquote><b>🤖 Membuat animasi (AI)</b>\n\n${lines.join("\n")}</blockquote>`;
}

// Simpan hasil animasi ke DB (sama kayak .canimasi manual)
async function saveAnimation(ownerId, obj) {
  const name = String(obj.name || "").trim().replace(/\s+/g, "_") || ("ai" + Date.now().toString(36));
  const desc = String(obj.desc || "Animasi AI").trim();
  const delay = Number(obj.delay) > 0 ? Number(obj.delay) : 0.5;
  let frames = Array.isArray(obj.frames) ? obj.frames.map(f => String(f)) : [];
  frames = frames.filter(f => f.length).slice(0, 30);
  if (frames.length < 1) return { ok: false, error: "AI tidak menghasilkan frame." };
  const res = await animasi.addUserAnimation(ownerId, name, desc, delay, frames);
  if (!res.ok) {
    // kalau nama bentrok, coba nama unik
    if (/sudah punya|bawaan/i.test(res.error || "")) {
      const alt = name + "_" + Math.random().toString(36).slice(2, 5);
      const r2 = await animasi.addUserAnimation(ownerId, alt, desc, delay, frames);
      if (r2.ok) return { ok: true, name: alt, desc, delay, frames };
    }
    return { ok: false, error: res.error };
  }
  return { ok: true, name, desc, delay, frames };
}

module.exports.__ai = { callAI, buildSystem, parseAIJson, saveAnimation, aiSessions, getSess, setSess, clearSess, stepView, editStatus };

module.exports.commands = [
  {
    name: "canimasiai",
    description: "Bikin animasi pakai AI. .canimasiai <prompt> — butuh GROQ_API_KEY (fallback Cerebras)",
    category: "Animasi",
    handler: async (event, args, ctx) => {
      const ownerId = ctx && ctx.ownerId;
      const prompt = args.join(" ").trim();
      if (!prompt) return _fmt.reply(event, `❌ Format: <code>.canimasiai buatkan animasi teks "Dimas" muncul dari kiri ke kanan</code>`);
      if (!process.env.GROQ_API_KEY && !process.env.CEREBRAS_API_KEY) {
        return _fmt.reply(event, `🔑 Butuh <code>GROQ_API_KEY</code> (atau <code>CEREBRAS_API_KEY</code>) di <code>gwajib.env</code>.`);
      }

      // Pesan status awal
      let statusMsg;
      try { statusMsg = await event.message.reply({ message: stepView(["▸ Memproses perintah..."]), parseMode: "html" }); } catch {}

      const messages = [
        { role: "system", content: buildSystem() },
        { role: "user", content: prompt },
      ];

      let aiOut, provider;
      try {
        const r = await callAI(messages);
        aiOut = r.content; provider = r.provider;
      } catch (e) {
        await editStatus(statusMsg, stepView([`❌ Gagal panggil AI: ${_fmt.esc(e.message)}`]));
        return;
      }

      const parsed = parseAIJson(aiOut);
      if (!parsed || !parsed.action) {
        await editStatus(statusMsg, stepView([`❌ AI kasih respons yang tidak valid. Coba lagi / ubah prompt.`]));
        return;
      }

      // ── AI mau nanya dulu (Q&A via manager) ──
      if (parsed.action === "ask" && Array.isArray(parsed.questions) && parsed.questions.length) {
        const questions = parsed.questions
          .filter(q => q && q.q && Array.isArray(q.options) && q.options.length >= 2)
          .map(q => ({ q: String(q.q), options: q.options.slice(0, 5).map(o => String(o)) }))
          .slice(0, 5);
        if (!questions.length) {
          // fallback: anggap langsung done kalau ternyata pertanyaan invalid
          await editStatus(statusMsg, stepView(["▸ Memproses perintah...", "▸ Merancang frame..."]));
        } else {
          const BOT_USERNAME = process.env.BOT_USERNAME || "";
          if (!BOT_USERNAME) {
            await editStatus(statusMsg, stepView([`❌ Q&A butuh BOT_USERNAME diset di .env (biar tombol muncul).`]));
            return;
          }
          // Simpan sesi buat manager
          const sid = ownerId + "_" + Date.now().toString(36);
          setSess(ownerId, { sid, prompt, messages, questions, qIdx: 0, answers: [], provider, statusMsg, event, ctx, ts: Date.now() });
          // Minta manager tampilkan pertanyaan pertama lewat inline
          try {
            const { Api } = require("telegram");
            const client = ctx.client;
            let botEntity, peerEntity;
            try { botEntity = await client.getInputEntity(BOT_USERNAME.replace("@", "")); } catch { const e = await client.getEntity(BOT_USERNAME.replace("@", "")); botEntity = await client.getInputEntity(e); }
            try { peerEntity = await client.getInputEntity(event.message.peerId); } catch { const c = await event.message.getChat(); peerEntity = await client.getInputEntity(c); }
            const qr = await client.invoke(new Api.messages.GetInlineBotResults({ bot: botEntity, peer: peerEntity, query: "canimasiai " + sid, offset: "" }));
            if (!qr.results || !qr.results.length) throw new Error("inline kosong");
            await client.invoke(new Api.messages.SendInlineBotResult({ peer: peerEntity, queryId: qr.queryId, id: qr.results[0].id }));
            // status di userbot: lagi nunggu jawaban
            await editStatus(statusMsg, stepView(["▸ Memproses perintah...", "▸ AI perlu beberapa info — jawab pertanyaan di bawah 👇"]));
          } catch (e) {
            clearSess(ownerId);
            await editStatus(statusMsg, stepView([`❌ Gagal tampilkan Q&A: ${_fmt.esc(e.message)}`]));
          }
          return; // lanjut pas semua pertanyaan dijawab (di manager → finalizeFromManager)
        }
      }

      // ── AI langsung kasih animasi ──
      await editStatus(statusMsg, stepView(["▸ Memproses perintah...", "▸ Merancang frame animasi...", "▸ Menyimpan ke database..."]));
      const obj = parsed.action === "done" ? parsed : parsed;
      const saved = await saveAnimation(ownerId, obj);
      if (!saved.ok) { await editStatus(statusMsg, stepView([`❌ Gagal simpan: ${_fmt.esc(saved.error)}`])); return; }

      const prefix = (ctx && ctx.prefix) || ".";
      await editStatus(statusMsg,
        `<blockquote><b>✅ SUDAH SIAP, GUNAKAN COMMAND <code>${prefix}animasi ${_fmt.esc(animasi.label(saved.name))}</code> UNTUK MEMULAI!\n\n` +
        `Judul: ${_fmt.esc(saved.name)}\n` +
        `Deskripsi: ${_fmt.esc(saved.desc)}\n` +
        `Via ai: ${_fmt.esc(provider)}</b></blockquote>`);
    },
  },
];
