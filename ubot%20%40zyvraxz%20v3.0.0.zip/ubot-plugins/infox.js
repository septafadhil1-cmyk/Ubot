// ─────────────────────────────────────────
//  Plugin: InfoX — info ringan via API gratis (tanpa key)
// ─────────────────────────────────────────

const _fmt = require("./_format");

async function fetchJson(url, opts = {}, timeout = 15000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { "User-Agent": "UBotManager/1.0", "Accept": "application/json", ...(opts.headers || {}) }, ...opts });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return await res.json();
  } finally { clearTimeout(t); }
}
function decodeEntities(s) {
  return String(s).replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&eacute;/g, "é").replace(/&rsquo;/g, "’");
}
async function sendPhoto(event, ctx, url, caption) {
  const msg = event.message;
  const client = (ctx && ctx.client) || event.client;
  try {
    await client.sendFile(msg.peerId, {
      file: url,
      caption: `<blockquote><b>${caption}</b></blockquote>`,
      parseMode: "html",
      replyTo: msg.id,
      forceDocument: false,
    });
  } catch (e) {
    return _fmt.reply(event, `${caption}\n\n🔗 ${_fmt.esc(url)}`);
  }
}

const commands = [
  {
    name: "advice",
    description: "Saran random (.advice)",
    category: "InfoX",
    handler: async (event) => {
      try {
        const d = await fetchJson("https://api.adviceslip.com/advice");
        return _fmt.reply(event, `💡 <i>${_fmt.esc(d.slip.advice)}</i>`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal ambil saran: ${_fmt.esc(e.message)}`); }
    },
  },
  {
    name: "dadjoke",
    description: "Lelucon bapack-bapack (.dadjoke)",
    category: "InfoX",
    handler: async (event) => {
      try {
        const d = await fetchJson("https://icanhazdadjoke.com/", { headers: { Accept: "application/json" } });
        return _fmt.reply(event, `😆 ${_fmt.esc(d.joke)}`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    },
  },
  {
    name: "catfact",
    description: "Fakta kucing random (.catfact)",
    category: "InfoX",
    handler: async (event) => {
      try {
        const d = await fetchJson("https://catfact.ninja/fact");
        return _fmt.reply(event, `🐱 ${_fmt.esc(d.fact)}`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    },
  },
  {
    name: "uselessfact",
    description: "Fakta random ga penting (.uselessfact)",
    category: "InfoX",
    handler: async (event) => {
      try {
        const d = await fetchJson("https://uselessfacts.jsph.pl/api/v2/facts/random?language=en");
        return _fmt.reply(event, `🤓 ${_fmt.esc(d.text)}`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    },
  },
  {
    name: "bored",
    description: "Ide kegiatan kalau bosan (.bored)",
    category: "InfoX",
    handler: async (event) => {
      try {
        const d = await fetchJson("https://bored-api.appbrewery.com/random");
        return _fmt.reply(event, `🎯 <b>Coba ini:</b> ${_fmt.esc(d.activity)}\n<i>Tipe: ${_fmt.esc(d.type || "-")}</i>`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    },
  },
  {
    name: "meme",
    description: "Meme random (gambar) (.meme)",
    category: "InfoX",
    handler: async (event, args, ctx) => {
      try {
        const d = await fetchJson("https://meme-api.com/gimme");
        return sendPhoto(event, ctx, d.url, `😂 ${_fmt.esc(d.title || "Meme")}\nr/${_fmt.esc(d.subreddit || "memes")} • 👍 ${d.ups || 0}`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal ambil meme: ${_fmt.esc(e.message)}`); }
    },
  },
  {
    name: "country",
    description: "Info negara (.country Indonesia)",
    category: "InfoX",
    handler: async (event, args) => {
      const q = args.join(" ");
      if (!q) return _fmt.reply(event, `❌ Format: <code>.country Indonesia</code>`);
      try {
        const arr = await fetchJson(`https://restcountries.com/v3.1/name/${encodeURIComponent(q)}?fields=name,capital,region,subregion,population,currencies,languages,flag,timezones`);
        const c = arr[0];
        const cur = c.currencies ? Object.values(c.currencies).map(x => `${x.name} (${x.symbol || "?"})`).join(", ") : "-";
        const lang = c.languages ? Object.values(c.languages).join(", ") : "-";
        return _fmt.reply(event,
          `${c.flag || "🏳️"} <b>${_fmt.esc(c.name.common)}</b>\n` +
          `Ibukota: <b>${_fmt.esc((c.capital || ["-"]).join(", "))}</b>\n` +
          `Wilayah: ${_fmt.esc(c.region || "-")}${c.subregion ? " / " + _fmt.esc(c.subregion) : ""}\n` +
          `Populasi: <b>${(c.population || 0).toLocaleString("id-ID")}</b>\n` +
          `Mata uang: ${_fmt.esc(cur)}\n` +
          `Bahasa: ${_fmt.esc(lang)}\n` +
          `Zona waktu: ${_fmt.esc((c.timezones || ["-"]).slice(0, 3).join(", "))}`
        );
      } catch (e) { return _fmt.reply(event, `❌ Negara tidak ditemukan / gagal.`); }
    },
  },
  {
    name: "pokemon",
    description: "Info Pokémon (.pokemon pikachu)",
    category: "InfoX",
    handler: async (event, args, ctx) => {
      const q = (args[0] || "").toLowerCase();
      if (!q) return _fmt.reply(event, `❌ Format: <code>.pokemon pikachu</code>`);
      try {
        const d = await fetchJson(`https://pokeapi.co/api/v2/pokemon/${encodeURIComponent(q)}`);
        const types = d.types.map(t => t.type.name).join(", ");
        const abilities = d.abilities.map(a => a.ability.name).join(", ");
        const img = d.sprites?.other?.["official-artwork"]?.front_default || d.sprites?.front_default;
        const cap = `⚡ <b>${_fmt.esc(d.name.toUpperCase())}</b> (#${d.id})\n` +
          `Tipe: ${_fmt.esc(types)}\n` +
          `Tinggi: ${d.height / 10} m • Berat: ${d.weight / 10} kg\n` +
          `Ability: ${_fmt.esc(abilities)}`;
        if (img) return sendPhoto(event, ctx, img, cap);
        return _fmt.reply(event, cap);
      } catch (e) { return _fmt.reply(event, `❌ Pokémon tidak ditemukan.`); }
    },
  },
  {
    name: "trivia",
    description: "Kuis trivia random (.trivia)",
    category: "InfoX",
    handler: async (event) => {
      try {
        const d = await fetchJson("https://opentdb.com/api.php?amount=1");
        const r = d.results[0];
        const opts = [...r.incorrect_answers, r.correct_answer].map(decodeEntities).sort(() => Math.random() - 0.5);
        return _fmt.reply(event,
          `❓ <b>Trivia</b> (${_fmt.esc(r.category)})\n\n` +
          `${_fmt.esc(decodeEntities(r.question))}\n\n` +
          opts.map((o, i) => `${i + 1}. ${_fmt.esc(o)}`).join("\n") +
          `\n\nJawaban: <span class="tg-spoiler">${_fmt.esc(decodeEntities(r.correct_answer))}</span>`
        );
      } catch (e) { return _fmt.reply(event, `❌ Gagal ambil trivia: ${_fmt.esc(e.message)}`); }
    },
  },
];

module.exports = { commands };
