// ─────────────────────────────────────────
//  Plugin: AIX — fitur yang butuh API key (dari gwajib.env)
//  Kalau key belum diisi, command kasih tahu cara dapetnya. Bot tetap jalan.
//  Prompt AI bisa dikustom di gwajib.env (var: prompt) + variabel #{name} dll.
// ─────────────────────────────────────────

const _fmt = require("./_format");

async function getText(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) {
    try { const r = await event.message.getReplyMessage(); t = r?.text || r?.message || ""; } catch {}
  }
  return t;
}

// Susun system prompt: pakai custom dari gwajib.env (var prompt) + ganti variabel.
async function buildSystem(event, ctx) {
  const custom = (process.env.prompt || process.env.PROMPT || "").trim();
  if (!custom) return "Kamu asisten yang ramah dan menjawab ringkas dalam Bahasa Indonesia.";
  const client = (ctx && ctx.client) || event.client;
  let name = "", username = "", id = "";
  try { const me = await client.getMe(); name = me.firstName || ""; username = me.username || ""; id = String(me.id || ""); } catch {}
  let grup = "chat pribadi";
  try { const chat = await event.message.getChat(); if (chat && chat.title) grup = chat.title; } catch {}
  const now = new Date();
  const tanggal = now.toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Jakarta" });
  const jam = now.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta" });
  const map = { name, username, id, grup, tanggal, jam };
  return custom.replace(/#?\{(\w+)\}/g, (m, k) => (k.toLowerCase() in map ? map[k.toLowerCase()] : m));
}

async function chatComplete(url, key, model, prompt, system, timeout = 45000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, {
      method: "POST",
      signal: ctrl.signal,
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + key },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: system || "Kamu asisten yang ramah dan menjawab ringkas dalam Bahasa Indonesia." },
          { role: "user", content: prompt },
        ],
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error?.message || ("HTTP " + res.status));
    const out = data?.choices?.[0]?.message?.content;
    if (!out) throw new Error("Respon kosong dari API");
    return out.trim();
  } finally { clearTimeout(t); }
}

// ChatGPT-42 (RapidAPI) — model ChatGPT 4. content = prompt user, system_prompt = var prompt gwajib.env.
async function chatGpt42(key, prompt, system, timeout = 45000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch("https://chatgpt-42.p.rapidapi.com/gpt4", {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "Content-Type": "application/json",
        "x-rapidapi-key": key,
        "x-rapidapi-host": "chatgpt-42.p.rapidapi.com",
      },
      body: JSON.stringify({
        messages: [{ role: "user", content: prompt }],
        system_prompt: system || "",
        temperature: 1.0,
        top_k: 5,
        top_p: 0.9,
        max_tokens: 256,
        web_access: false,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.message || data?.error || ("HTTP " + res.status));
    // Response: { result: "...", status: true, server_code: 1 }
    const out = data?.result || data?.choices?.[0]?.message?.content;
    if (!out) throw new Error("Respon kosong dari API");
    return String(out).trim();
  } finally { clearTimeout(t); }
}

function needKey(event, name, envName, link) {
  return _fmt.reply(event,
    `🔑 <b>Fitur ${name} belum aktif</b>\n\n` +
    `Butuh <code>${envName}</code> di file <code>gwajib.env</code> (opsional).\n` +
    `Cara dapat (gratis): ${link}\n\n` +
    `<i>Isi key-nya, lalu restart bot.</i>`
  );
}

const commands = [
  {
    name: "ai",
    description: "Tanya AI (ChatGPT-4 via RapidAPI) (.ai pertanyaanmu) — butuh RAPIDAPI_KEY",
    category: "AI",
    handler: async (event, args, ctx) => {
      const key = process.env.RAPIDAPI_KEY;
      if (!key) return needKey(event, "AI", "RAPIDAPI_KEY", "https://rapidapi.com/rphrp1985/api/chatgpt-42");
      const q = await getText(event, args);
      if (!q) return _fmt.reply(event, `❌ Format: <code>.ai jelaskan apa itu lubang hitam</code>`);
      try {
        const system = await buildSystem(event, ctx);
        const ans = await chatGpt42(key, q, system);
        let out = ans; if (out.length > 3800) out = out.slice(0, 3800) + "...";
        return _fmt.reply(event, `🤖 <b>AI</b>\n\n${_fmt.esc(out)}`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    },
  },
  {
    name: "groq",
    description: "Tanya AI via Groq (cepat) (.groq pertanyaanmu) — butuh key",
    category: "AI",
    handler: async (event, args, ctx) => {
      const key = process.env.GROQ_API_KEY;
      if (!key) return needKey(event, "Groq", "GROQ_API_KEY", "https://console.groq.com/keys");
      const q = await getText(event, args);
      if (!q) return _fmt.reply(event, `❌ Format: <code>.groq tulis pantun lucu</code>`);
      try {
        const system = await buildSystem(event, ctx);
        const ans = await chatComplete("https://api.groq.com/openai/v1/chat/completions", key, "llama-3.1-8b-instant", q, system);
        let out = ans; if (out.length > 3800) out = out.slice(0, 3800) + "...";
        return _fmt.reply(event, `⚡ <b>Groq AI</b>\n\n${_fmt.esc(out)}`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    },
  },
  {
    name: "weather2",
    description: "Cuaca detail via OpenWeatherMap (.weather2 Jakarta) — butuh key",
    category: "AI",
    handler: async (event, args) => {
      const key = process.env.OPENWEATHER_API_KEY;
      if (!key) return needKey(event, "Weather2", "OPENWEATHER_API_KEY", "https://openweathermap.org/api");
      const kota = args.join(" ") || "Jakarta";
      try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 15000);
        const res = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(kota)}&appid=${key}&units=metric&lang=id`, { signal: ctrl.signal });
        clearTimeout(t);
        const d = await res.json();
        if (d.cod && String(d.cod) !== "200") return _fmt.reply(event, `❌ ${_fmt.esc(d.message || "Kota tidak ditemukan")}`);
        const w = d.weather?.[0]?.description || "-";
        return _fmt.reply(event,
          `🌦️ <b>Cuaca ${_fmt.esc(d.name)}</b>\n` +
          `Kondisi: ${_fmt.esc(w)}\n` +
          `Suhu: <b>${Math.round(d.main.temp)}°C</b> (terasa ${Math.round(d.main.feels_like)}°C)\n` +
          `Kelembapan: ${d.main.humidity}%\n` +
          `Angin: ${d.wind?.speed ?? "-"} m/s`
        );
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    },
  },
];

module.exports = { commands };
