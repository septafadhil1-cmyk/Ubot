// ─────────────────────────────────────────
//  Plugin: Info (help, ping, alive)
//  help dinamis — auto list semua command dari semua plugin
// ─────────────────────────────────────────

const PREFIX = process.env.UBOT_PREFIX || ".";
const fs = require("fs");
const path = require("path");
const _fmt = require("./_format");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
async function reply(event, html) {
  return _fmt.reply(event, html);
}

// Kumpulkan semua command dari semua plugin (dibaca sekali saat load)
function collectAllCommands() {
  const all = [];
  const dir = __dirname;
  const files = fs.readdirSync(dir).filter(f => f.endsWith(".js"));
  for (const file of files) {
    try {
      const mod = require(path.join(dir, file));
      if (mod.commands) {
        for (const c of mod.commands) {
          all.push({ name: c.name, description: c.description || "-", category: c.category || "Umum" });
        }
      }
    } catch {}
  }
  return all;
}

// Fallback: render help berkategori langsung dari ubot (kalau inline total gagal)
async function renderLocalHelp(event) {
  try {
    const cmds = collectAllCommands();
    const categories = {};
    for (const c of cmds) {
      const cat = c.category || "Umum";
      (categories[cat] ||= []).push(c);
    }
    const lines = [
      `🤖 <b>Userbot — Daftar Perintah</b>`,
      `Prefix: <code>${esc(PREFIX)}</code> | Total: ${cmds.length} perintah\n`,
    ];
    const order = ["Umum", "Utilitas", "Fun", "Grup", "Blacklist", "Promosi"];
    const sorted = Object.keys(categories).sort((a, b) => {
      const ia = order.indexOf(a), ib = order.indexOf(b);
      return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
    });
    for (const cat of sorted) {
      lines.push(`📂 <b>${esc(cat)}</b>`);
      for (const c of categories[cat].sort((a, b) => a.name.localeCompare(b.name))) {
        lines.push(`  • <code>${esc(PREFIX + c.name)}</code> — ${esc(c.description)}`);
      }
      lines.push("");
    }
    lines.push(`<i>Powered by UBot TuanPii</i>`);
    await reply(event, lines.join("\n"));
  } catch (e) {
    console.error("renderLocalHelp error:", e.message);
  }
}

module.exports.commands = [
  {
    name: "help",
    description: "Daftar semua perintah ubot",
    category: "Umum",
    handler: async (event, args, ctx) => {
      const msg = event.message;
      const client = ctx.client;
      const BOT_USERNAME = process.env.BOT_USERNAME || "";

      if (!BOT_USERNAME) {
        // Fallback: teks biasa kalau BOT_USERNAME ga diset
        return reply(event, "❌ Set BOT_USERNAME di .env dulu!");
      }

      try {
        const Api = require("telegram").Api;

        // Force-resolve bot entity (penting untuk session ubot yang baru connect)
        let botEntity;
        try {
          botEntity = await client.getInputEntity(BOT_USERNAME.replace("@", ""));
        } catch {
          // Session baru belum punya cache → resolve via getEntity (API call)
          const ent = await client.getEntity(BOT_USERNAME.replace("@", ""));
          botEntity = await client.getInputEntity(ent);
        }

        // Resolve peer chat saat ini (juga bisa gagal di session baru)
        let peerEntity;
        try {
          peerEntity = await client.getInputEntity(msg.peerId);
        } catch {
          const chat = await msg.getChat();
          peerEntity = await client.getInputEntity(chat);
        }

        const me = await client.getMe();
        const ubotName = (me.firstName || "Userbot").slice(0, 30);

        const queryResult = await client.invoke(new Api.messages.GetInlineBotResults({
          bot: botEntity,
          peer: peerEntity,
          query: "help " + ubotName,
          offset: "",
        }));

        if (!queryResult.results || queryResult.results.length === 0) {
          return reply(event, "❌ Bot inline belum siap, coba lagi.");
        }

        // Cari hasil foto (help_main) & teks (help_text)
        const photoRes = queryResult.results.find(r => r.id === "help_main");
        const textRes = queryResult.results.find(r => r.id === "help_text");

        // Coba kirim foto dulu; kalau gagal (WEBPAGE_MEDIA_EMPTY dll) → retry teks
        const trySend = async (resultId) => {
          await client.invoke(new Api.messages.SendInlineBotResult({
            peer: peerEntity,
            queryId: queryResult.queryId,
            id: resultId,
            replyTo: new Api.InputReplyToMessage({ replyToMsgId: msg.id }),
          }));
        };

        const firstId = (photoRes || queryResult.results[0]).id;
        try {
          await trySend(firstId);
        } catch (sendErr) {
          // Foto gagal → fallback ke hasil teks (tombol tetap ada)
          if (textRes && textRes.id !== firstId) {
            try {
              await trySend(textRes.id);
            } catch (e2) {
              // Inline teks pun gagal → render lokal (kategori, tanpa tombol)
              await renderLocalHelp(event);
            }
          } else {
            await renderLocalHelp(event);
          }
        }
      } catch (e) {
        console.error("help inline error:", e.message);
        // Fallback total: render help lokal (selalu jalan)
        await renderLocalHelp(event);
      }
    },
  },
  {
    name: "ping",
    description: "Cek latensi ubot",
    category: "Umum",
    handler: async (event) => {
      const start = Date.now();
      const ms = Date.now() - start;
      return reply(event, `🏓 <b>Pong!</b>\nLatensi: <code>${ms}ms</code>\nStatus: ✅ Online`);
    },
  },
  {
    name: "alive",
    description: "Cek status ubot",
    category: "Umum",
    handler: async (event, args, ctx) => {
      const me = await ctx.client.getMe();
      const text = `✅ <b>Userbot Aktif!</b>\n\n` +
        `Akun: <b>${esc(me.firstName)}</b>\n` +
        `Username: @${esc(me.username || "-")}\n` +
        `<i>Powered by UBot TuanPii</i>`;
      // Tombol "Join Grup" (URL) kalau GRUP_UBOT diset di .env
      const grup = (process.env.GRUP_UBOT || "").trim();
      if (grup) {
        try {
          const { Button } = require("telegram");
          return event.message.reply({
            message: text, parseMode: "html",
            buttons: [[Button.url("👥 Join Grup", grup)]],
          });
        } catch {}
      }
      return reply(event, text);
    },
  },
];
