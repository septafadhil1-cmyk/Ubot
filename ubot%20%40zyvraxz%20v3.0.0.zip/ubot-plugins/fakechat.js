// ─────────────────────────────────────────
//  Plugin: Fake Chat
//  .fakechat <nama> | <pesan>
//  .fakechat <nama> | <pesan1> / <pesan2> / <pesan3>
//  Reply foto → dijadikan avatar
// ─────────────────────────────────────────
const _fmt = require("./_format");

const { createCanvas, loadImage } = require("@napi-rs/canvas");
const fs = require("fs");
const path = require("path");
const os = require("os");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function nameToColor(name) {
  const colors = ["#E17076","#7BC862","#65AADD","#A695E7","#EE7AAE","#6EC9CB","#FAA774","#F0941E"];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

function getInitials(name) {
  return name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
}

function wrapText(ctx, text, maxWidth) {
  const words = text.split(" ");
  const lines = [];
  let line = "";
  for (const word of words) {
    const test = line ? line + " " + word : word;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = word;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function nowTime() {
  return new Date().toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta",
  });
}

// Gambar background wallpaper Telegram (gradient + pattern)
function drawTelegramBg(ctx, W, H) {
  // Gradient diagonal khas Telegram
  const grad = ctx.createLinearGradient(0, 0, W, H);
  grad.addColorStop(0, "#8da89b");
  grad.addColorStop(0.5, "#a9c5b3");
  grad.addColorStop(1, "#7fa890");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);

  // Overlay pattern dot subtle
  ctx.fillStyle = "rgba(255,255,255,0.06)";
  for (let y = 10; y < H; y += 28) {
    for (let x = 10; x < W; x += 28) {
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

async function generateFakeChat({ senderName, messages, avatarBuffer }) {
  const W = 440;
  const PADDING = 14;
  const AVATAR_SIZE = 40;
  const BUBBLE_RADIUS = 16;
  const FONT_MSG = "16px sans-serif";
  const FONT_NAME = "bold 14px sans-serif";
  const FONT_TIME = "11px sans-serif";
  const MAX_BUBBLE_W = W - AVATAR_SIZE - PADDING * 4;
  const LINE_H = 21;
  const TIME_SPACE = 58; // ruang horizontal untuk waktu di baris terakhir

  const tmpCtx = createCanvas(W, 100).getContext("2d");
  tmpCtx.font = FONT_MSG;

  const bubbleData = messages.map(text => ({
    text,
    lines: wrapText(tmpCtx, text, MAX_BUBBLE_W - 28),
  }));

  // Hitung tinggi total
  let totalH = PADDING * 2;
  for (let i = 0; i < bubbleData.length; i++) {
    const nameH = i === 0 ? 22 : 0;
    totalH += nameH + bubbleData[i].lines.length * LINE_H + 24 + 5;
  }

  const canvas = createCanvas(W, Math.max(totalH, 110));
  const ctx = canvas.getContext("2d");

  drawTelegramBg(ctx, W, canvas.height);

  const avatarColor = nameToColor(senderName);
  const initials = getInitials(senderName);

  let yOffset = PADDING;
  let firstBubble = true;

  for (let idx = 0; idx < bubbleData.length; idx++) {
    const { lines } = bubbleData[idx];
    tmpCtx.font = FONT_MSG;

    // Lebar bubble: max dari (lebar teks) atau (lebar baris terakhir + ruang waktu)
    const longestLine = Math.max(...lines.map(l => tmpCtx.measureText(l).width));
    const lastLineW = tmpCtx.measureText(lines[lines.length - 1]).width;
    const nameW = firstBubble ? tmpCtx.measureText(senderName).width : 0;
    const bubbleW = Math.min(
      Math.max(longestLine, lastLineW + TIME_SPACE, nameW) + 28,
      MAX_BUBBLE_W
    );

    const nameH = firstBubble ? 22 : 0;
    const bubbleH = nameH + lines.length * LINE_H + 24;
    const bubbleX = AVATAR_SIZE + PADDING * 2;
    const bubbleY = yOffset;

    // Avatar (hanya bubble pertama)
    if (firstBubble) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(PADDING + AVATAR_SIZE / 2, bubbleY + AVATAR_SIZE / 2, AVATAR_SIZE / 2, 0, Math.PI * 2);
      ctx.clip();
      if (avatarBuffer) {
        try {
          const img = await loadImage(avatarBuffer);
          ctx.drawImage(img, PADDING, bubbleY, AVATAR_SIZE, AVATAR_SIZE);
        } catch {
          ctx.fillStyle = avatarColor;
          ctx.fillRect(PADDING, bubbleY, AVATAR_SIZE, AVATAR_SIZE);
        }
      } else {
        ctx.fillStyle = avatarColor;
        ctx.fillRect(PADDING, bubbleY, AVATAR_SIZE, AVATAR_SIZE);
      }
      ctx.restore();
      if (!avatarBuffer) {
        ctx.fillStyle = "#fff";
        ctx.font = "bold 15px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(initials, PADDING + AVATAR_SIZE / 2, bubbleY + AVATAR_SIZE / 2);
      }
    }

    // Bubble shadow + putih
    ctx.shadowColor = "rgba(0,0,0,0.15)";
    ctx.shadowBlur = 3;
    ctx.shadowOffsetY = 1;
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.moveTo(bubbleX + BUBBLE_RADIUS, bubbleY);
    ctx.lineTo(bubbleX + bubbleW - BUBBLE_RADIUS, bubbleY);
    ctx.quadraticCurveTo(bubbleX + bubbleW, bubbleY, bubbleX + bubbleW, bubbleY + BUBBLE_RADIUS);
    ctx.lineTo(bubbleX + bubbleW, bubbleY + bubbleH - BUBBLE_RADIUS);
    ctx.quadraticCurveTo(bubbleX + bubbleW, bubbleY + bubbleH, bubbleX + bubbleW - BUBBLE_RADIUS, bubbleY + bubbleH);
    ctx.lineTo(bubbleX + BUBBLE_RADIUS, bubbleY + bubbleH);
    ctx.quadraticCurveTo(bubbleX, bubbleY + bubbleH, bubbleX, bubbleY + bubbleH - BUBBLE_RADIUS);
    if (firstBubble) {
      ctx.lineTo(bubbleX, bubbleY + 8);
      ctx.quadraticCurveTo(bubbleX, bubbleY, bubbleX - 7, bubbleY);
      ctx.quadraticCurveTo(bubbleX - 2, bubbleY + 3, bubbleX + 4, bubbleY);
    } else {
      ctx.lineTo(bubbleX, bubbleY + BUBBLE_RADIUS);
      ctx.quadraticCurveTo(bubbleX, bubbleY, bubbleX + BUBBLE_RADIUS, bubbleY);
    }
    ctx.closePath();
    ctx.fill();
    ctx.shadowColor = "transparent";
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;

    // Nama pengirim
    let textY = bubbleY + 12;
    if (firstBubble) {
      ctx.fillStyle = avatarColor;
      ctx.font = FONT_NAME;
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      ctx.fillText(senderName, bubbleX + 12, textY);
      textY += nameH;
    }

    // Teks pesan
    ctx.fillStyle = "#0f0f0f";
    ctx.font = FONT_MSG;
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    for (const line of lines) {
      ctx.fillText(line, bubbleX + 12, textY);
      textY += LINE_H;
    }

    // Waktu + centang biru (sudah dibaca) di pojok kanan bawah bubble
    const timeStr = nowTime();
    const timeY = bubbleY + bubbleH - 7;
    const checkX = bubbleX + bubbleW - 12;

    // Gambar double-check biru (✓✓) — tanda sudah dibaca
    ctx.strokeStyle = "#4fa3e3";
    ctx.lineWidth = 1.6;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    // Centang kedua (belakang)
    ctx.beginPath();
    ctx.moveTo(checkX - 6, timeY - 5);
    ctx.lineTo(checkX - 3.5, timeY - 2);
    ctx.lineTo(checkX + 1, timeY - 8);
    ctx.stroke();
    // Centang pertama (depan)
    ctx.beginPath();
    ctx.moveTo(checkX - 10, timeY - 5);
    ctx.lineTo(checkX - 7.5, timeY - 2);
    ctx.lineTo(checkX - 3, timeY - 8);
    ctx.stroke();

    // Waktu di kiri centang
    ctx.fillStyle = "#a0acbb";
    ctx.font = FONT_TIME;
    ctx.textAlign = "right";
    ctx.textBaseline = "bottom";
    ctx.fillText(timeStr, checkX - 16, timeY);

    yOffset += bubbleH + 5;
    firstBubble = false;
  }

  return canvas.toBuffer("image/png");
}


async function reply(event, html) {
  return _fmt.reply(event, html);
}

module.exports.commands = [
  {
    name: "fakechat",
    description: "Buat screenshot chat Telegram palsu",
    usage: ".fakechat <nama> | <pesan1> / <pesan2>",
    category: "Fun",
    handler: async (event, args) => {
      const msg = event.message;
      const client = msg.client;
      const fullText = args.join(" ");

      if (!fullText.includes("|")) {
        return msg.reply({
          message:
            `<blockquote><b>❌ <b>Cara pakai:</b>\n\n` +
            `• <code>.fakechat Jokowi | Halo bro!</code>\n` +
            `• <code>.fakechat Budi | Halo! / Apa kabar?</code>\n\n` +
            `<i>Pisah beberapa bubble pakai <b>/</b></i>\n` +
            `<i>Reply foto untuk jadikan avatar</i></b></blockquote>`,
          parseMode: "html",
        });
      }

      const [namePart, ...msgParts] = fullText.split("|");
      const senderName = namePart.trim();
      const messages = msgParts.join("|").trim().split("/").map(m => m.trim()).filter(Boolean);

      if (!senderName || !messages.length) {
        return msg.reply({
          message: `<blockquote><b>❌ Format salah. Contoh: <code>.fakechat Budi | Halo!</code></b></blockquote>`,
          parseMode: "html",
        });
      }

      let avatarBuffer = null;
      if (msg.replyTo) {
        try {
          const replied = await msg.getReplyMessage();
          if (replied?.photo || replied?.document) {
            avatarBuffer = await client.downloadMedia(replied, {});
          }
        } catch {}
      }

      try {
        const imgBuffer = await generateFakeChat({ senderName, messages, avatarBuffer });
        const tmpPath = path.join(os.tmpdir(), `fakechat_${Date.now()}.png`);
        fs.writeFileSync(tmpPath, imgBuffer);
        await client.sendFile(msg.peerId, { file: tmpPath, replyTo: msg.id, forceDocument: false });
        fs.unlinkSync(tmpPath);
      } catch (e) {
        console.error("fakechat error:", e.message);
        return msg.reply({
          message: `<blockquote><b>❌ Gagal generate: ${esc(e.message)}</b></blockquote>`,
          parseMode: "html",
        });
      }
    },
  },
];
