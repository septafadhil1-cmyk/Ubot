// ─────────────────────────────────────────
//  Plugin: ConvertX — konversi & hash (tanpa API)
// ─────────────────────────────────────────

const _fmt = require("./_format");
const crypto = require("crypto");

async function getText(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) {
    try { const r = await event.message.getReplyMessage(); t = r?.text || r?.message || ""; } catch {}
  }
  return t;
}

// ── terbilang (angka → kata Indonesia) ──
const SATUAN = ["", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"];
function terbilang(n) {
  n = Math.floor(Math.abs(n));
  if (n < 12) return SATUAN[n];
  if (n < 20) return terbilang(n - 10) + " belas";
  if (n < 100) return terbilang(Math.floor(n / 10)) + " puluh" + (n % 10 ? " " + terbilang(n % 10) : "");
  if (n < 200) return "seratus" + (n % 100 ? " " + terbilang(n % 100) : "");
  if (n < 1000) return terbilang(Math.floor(n / 100)) + " ratus" + (n % 100 ? " " + terbilang(n % 100) : "");
  if (n < 2000) return "seribu" + (n % 1000 ? " " + terbilang(n % 1000) : "");
  if (n < 1e6) return terbilang(Math.floor(n / 1000)) + " ribu" + (n % 1000 ? " " + terbilang(n % 1000) : "");
  if (n < 1e9) return terbilang(Math.floor(n / 1e6)) + " juta" + (n % 1e6 ? " " + terbilang(n % 1e6) : "");
  if (n < 1e12) return terbilang(Math.floor(n / 1e9)) + " miliar" + (n % 1e9 ? " " + terbilang(n % 1e9) : "");
  return terbilang(Math.floor(n / 1e12)) + " triliun" + (n % 1e12 ? " " + terbilang(n % 1e12) : "");
}

function rot(s, n) {
  return s.replace(/[a-z]/gi, c => {
    const base = c <= "Z" ? 65 : 97;
    return String.fromCharCode(((c.charCodeAt(0) - base + n) % 26) + base);
  });
}
function atbash(s) {
  return s.replace(/[a-z]/gi, c => {
    const base = c <= "Z" ? 65 : 97;
    return String.fromCharCode(base + (25 - (c.charCodeAt(0) - base)));
  });
}
function hashCmd(name, algo) {
  return {
    name,
    description: `Hash ${algo.toUpperCase()} dari teks (.${name} teksnya)`,
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.${name} teksnya</code>`);
      const h = crypto.createHash(algo).update(t).digest("hex");
      return _fmt.reply(event, `🔐 <b>${algo.toUpperCase()}</b>\n<code>${h}</code>`);
    },
  };
}

const commands = [
  {
    name: "terbilang",
    description: "Angka → kata Indonesia (.terbilang 1500000)",
    category: "Konversi",
    handler: async (event, args) => {
      const raw = (await getText(event, args)).replace(/[.,\s]/g, "");
      if (!/^-?\d+$/.test(raw)) return _fmt.reply(event, `❌ Masukkan angka. Contoh: <code>.terbilang 21500</code>`);
      const num = parseInt(raw, 10);
      if (Math.abs(num) > 9.99e14) return _fmt.reply(event, `❌ Angka terlalu besar (maks ~triliun).`);
      const words = num === 0 ? "nol" : (num < 0 ? "minus " : "") + terbilang(num);
      return _fmt.reply(event, `🔢 <b>${_fmt.esc(raw)}</b>\n➡️ ${_fmt.esc(words.replace(/\s+/g, " ").trim())}`);
    },
  },
  {
    name: "rupiah",
    description: "Format angka jadi Rupiah (.rupiah 1500000)",
    category: "Konversi",
    handler: async (event, args) => {
      const raw = (await getText(event, args)).replace(/[.,\s]/g, "");
      if (!/^-?\d+$/.test(raw)) return _fmt.reply(event, `❌ Masukkan angka. Contoh: <code>.rupiah 1500000</code>`);
      const num = parseInt(raw, 10);
      const fmt = "Rp " + num.toLocaleString("id-ID");
      return _fmt.reply(event, `💰 <code>${_fmt.esc(fmt)}</code>`);
    },
  },
  {
    name: "rot13",
    description: "Sandi ROT13 (.rot13 teksnya) — jalankan lagi untuk decode",
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.rot13 teksnya</code>`);
      return _fmt.reply(event, `🔁 <code>${_fmt.esc(rot(t, 13))}</code>`);
    },
  },
  {
    name: "atbash",
    description: "Sandi Atbash a↔z (.atbash teksnya)",
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.atbash teksnya</code>`);
      return _fmt.reply(event, `🔁 <code>${_fmt.esc(atbash(t))}</code>`);
    },
  },
  {
    name: "urlencode",
    description: "Encode teks jadi URL (.urlencode halo dunia)",
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.urlencode teksnya</code>`);
      return _fmt.reply(event, `🔗 <code>${_fmt.esc(encodeURIComponent(t))}</code>`);
    },
  },
  {
    name: "urldecode",
    description: "Decode URL jadi teks (.urldecode halo%20dunia)",
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.urldecode teks%20nya</code>`);
      try { return _fmt.reply(event, `🔗 <code>${_fmt.esc(decodeURIComponent(t))}</code>`); }
      catch { return _fmt.reply(event, `❌ Format URL tidak valid.`); }
    },
  },
  {
    name: "slugify",
    description: "Ubah jadi slug url-friendly (.slugify Judul Artikel Ku)",
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.slugify Judul Artikelku</code>`);
      const slug = t.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
      return _fmt.reply(event, `🔗 <code>${_fmt.esc(slug || "-")}</code>`);
    },
  },
  {
    name: "ascii",
    description: "Teks → kode ASCII/Unicode (.ascii Hi)",
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.ascii Hi</code>`);
      const codes = [...t].map(c => c.codePointAt(0)).join(" ");
      return _fmt.reply(event, `🔢 <code>${_fmt.esc(codes)}</code>`);
    },
  },
  {
    name: "unascii",
    description: "Kode ASCII → teks (.unascii 72 105)",
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.unascii 72 105</code>`);
      try {
        const out = t.trim().split(/\s+/).map(n => String.fromCodePoint(parseInt(n, 10))).join("");
        return _fmt.reply(event, `🔤 ${_fmt.esc(out)}`);
      } catch { return _fmt.reply(event, `❌ Hanya angka dipisah spasi.`); }
    },
  },
  {
    name: "jsonpretty",
    description: "Rapikan JSON (.jsonpretty {\"a\":1})",
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.jsonpretty {\"a\":1}</code>`);
      try {
        let out = JSON.stringify(JSON.parse(t), null, 2);
        if (out.length > 3500) out = out.slice(0, 3500) + "\n...";
        return _fmt.reply(event, `🧾 <b>JSON</b>\n<code>${_fmt.esc(out)}</code>`);
      } catch (e) { return _fmt.reply(event, `❌ JSON tidak valid: ${_fmt.esc(e.message)}`); }
    },
  },
  {
    name: "jsonmin",
    description: "Padatkan JSON jadi 1 baris (.jsonmin {...})",
    category: "Konversi",
    handler: async (event, args) => {
      const t = await getText(event, args);
      if (!t) return _fmt.reply(event, `❌ Format: <code>.jsonmin { "a": 1 }</code>`);
      try { return _fmt.reply(event, `🧾 <code>${_fmt.esc(JSON.stringify(JSON.parse(t)))}</code>`); }
      catch (e) { return _fmt.reply(event, `❌ JSON tidak valid: ${_fmt.esc(e.message)}`); }
    },
  },
  hashCmd("md5", "md5"),
  hashCmd("sha1", "sha1"),
  hashCmd("sha256", "sha256"),
];

module.exports = { commands };
