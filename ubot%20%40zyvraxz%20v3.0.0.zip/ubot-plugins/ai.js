// ─────────────────────────────────────────
//  Plugin: AI (folder AI) — fitur AI canggih pakai Groq
//   • .visionimage  → lihat & deskripsikan foto (model qwen/qwen3.6-27b, Vision)
//   • .ubot         → kendalikan ubot via perintah natural (qwen/qwen3.6-27b, Function Calling / Tool Use)
//   • .code         → asisten yang bisa BIKIN FILE / ZIP (openai/gpt-oss-120b, Reasoning)
//
//  Semua butuh GROQ_API_KEY (dari gwajib.env). Kalau kosong → kasih panduan, bot tetap jalan.
//  Prompt kepribadian diambil dari gwajib.env (var: prompt) + variabel #{name} dll — SAMA seperti .ai/.groq.
// ─────────────────────────────────────────

const _fmt = require("./_format");
const fs = require("fs");
const os = require("os");
const path = require("path");

const GROQ_BASE = "https://api.groq.com/openai/v1/chat/completions";
const CEREBRAS_BASE = "https://api.cerebras.ai/v1/chat/completions"; // fallback .code saat Groq limit
// .cimage sekarang pakai RapidAPI (DALL-E based image gen) — lihat command .cimage di bawah.
const VISION_MODEL = "qwen/qwen3.6-27b";   // vision + tool use
const UBOT_MODEL = "qwen/qwen3.6-27b";     // function calling / tool use
const CODE_MODEL = "openai/gpt-oss-120b";  // reasoning (Groq)
const CODE_MODEL_CEREBRAS = "gpt-oss-120b"; // model sama di Cerebras (nama beda)

// Fallback .cimage: Krea 2 Turbo di HuggingFace (kalau kuota RapidAPI habis). Butuh HF_TOKEN.
// Krea 2 Turbo: 8 langkah, guidance 0.0, Square 1024x1024. Response = bytes gambar (blob).
async function genKrea2(hfKey, prompt) {
  const MODEL = "krea/Krea-2-Turbo";
  const body = JSON.stringify({
    inputs: prompt,
    parameters: { width: 1024, height: 1024, num_inference_steps: 8, guidance_scale: 0.0 },
  });
  const urls = [
    `https://router.huggingface.co/hf-inference/models/${MODEL}`,
    `https://api-inference.huggingface.co/models/${MODEL}`,
  ];
  let lastErr = null;
  for (const url of urls) {
    for (let attempt = 0; attempt < 3; attempt++) {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 120000);
      try {
        const res = await fetch(url, {
          method: "POST", signal: ctrl.signal,
          headers: { "Authorization": "Bearer " + hfKey, "Content-Type": "application/json", "Accept": "image/png" },
          body,
        });
        const ct = res.headers.get("content-type") || "";
        if (res.ok && ct.startsWith("image/")) {
          const buf = Buffer.from(await res.arrayBuffer());
          clearTimeout(t);
          if (buf.length) return buf;
          throw new Error("Krea 2 balikin gambar kosong.");
        }
        const txt = await res.text().catch(() => "");
        let msg = txt;
        try { const j = JSON.parse(txt); msg = j.error || j.message || txt; } catch {}
        if (res.status === 503 || /loading|currently loading|is starting/i.test(String(msg))) {
          clearTimeout(t); await new Promise(r => setTimeout(r, 8000)); continue;
        }
        lastErr = new Error("Krea 2: " + (msg || ("HTTP " + res.status))); clearTimeout(t); break;
      } catch (e) { lastErr = e; clearTimeout(t); if (/abort/i.test(String(e.message))) break; }
    }
  }
  throw (lastErr || new Error("Krea 2 gagal (HuggingFace)."));
}

// ── Ambil teks dari args atau reply ──
async function getText(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) {
    try { const r = await event.message.getReplyMessage(); t = r?.text || r?.message || ""; } catch {}
  }
  return t;
}

// ── Susun system prompt: pakai custom dari gwajib.env (var prompt) + ganti variabel ──
// (disalin dari aix.js biar konsisten — bot "tahu" siapa dia & siapa user)
async function buildSystem(event, ctx, extra = "") {
  const custom = (process.env.prompt || process.env.PROMPT || "").trim();
  const client = (ctx && ctx.client) || event.client;
  let name = "", username = "", id = "";
  try { const me = await client.getMe(); name = me.firstName || ""; username = me.username || ""; id = String(me.id || ""); } catch {}
  let grup = "chat pribadi";
  try { const chat = await event.message.getChat(); if (chat && chat.title) grup = chat.title; } catch {}
  // siapa USER (pengirim perintah)
  let userName = "", userUname = "", userId = "";
  try {
    const sender = await event.message.getSender();
    userName = sender?.firstName || ""; userUname = sender?.username || ""; userId = String(sender?.id || "");
  } catch {}
  const now = new Date();
  const tanggal = now.toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Jakarta" });
  const jam = now.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta" });
  const map = { name, username, id, grup, tanggal, jam,
    user: userName, useruname: userUname, userid: userId };
  let base;
  if (custom) base = custom.replace(/#?\{(\w+)\}/g, (m, k) => (k.toLowerCase() in map ? map[k.toLowerCase()] : m));
  else base = `Kamu adalah userbot Telegram bernama ${name || "Userbot"} (@${username || "-"}). Kamu menjawab ringkas dan ramah dalam Bahasa Indonesia.`;
  // info konteks tambahan biar AI sadar lingkungannya
  base += `\n\n[KONTEKS] Kamu adalah userbot Telegram bernama "${name}" (@${username}, id ${id}). ` +
    `Pemilik/operator yang sedang memberi perintah: "${userName}" (@${userUname || "-"}, id ${userId}). ` +
    `Lokasi chat: ${grup}. Tanggal: ${tanggal}, jam ${jam} WIB.`;
  if (extra) base += "\n\n" + extra;
  return base;
}

// ── Pesan kalau key belum diisi ──
function needKey(event) {
  return _fmt.reply(event,
    `🔑 <b>Fitur AI belum aktif</b>\n\n` +
    `Butuh <code>GROQ_API_KEY</code> di file <code>gwajib.env</code>.\n` +
    `Daftar gratis: https://console.groq.com/keys\n\n` +
    `<i>Isi key-nya, lalu restart bot.</i>`
  );
}

// ── Helper: panggil Groq chat completion (messages bebas, biar bisa vision/tools) ──
async function groqChat(body, timeout = 60000) {
  const key = process.env.GROQ_API_KEY;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(GROQ_BASE, {
      method: "POST",
      signal: ctrl.signal,
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + key },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) { const e = new Error(data?.error?.message || ("HTTP " + res.status)); e.status = res.status; throw e; }
    return data;
  } finally { clearTimeout(t); }
}

// ── Helper: panggil Cerebras (OpenAI-compatible) — dipakai sebagai CADANGAN .code ──
async function cerebrasChat(body, timeout = 90000) {
  const key = process.env.CEREBRAS_API_KEY;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(CEREBRAS_BASE, {
      method: "POST",
      signal: ctrl.signal,
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + key },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) { const e = new Error(data?.error?.message || ("HTTP " + res.status)); e.status = res.status; throw e; }
    return data;
  } finally { clearTimeout(t); }
}

// Deteksi error = rate-limit / kuota habis (buat trigger fallback Cerebras)
function isLimitError(status, msg) {
  if (status === 429) return true;
  const m = String(msg || "").toLowerCase();
  return /rate.?limit|too many requests|quota|limit reached|exceeded|insufficient|tpm|rpm|over capacity|429/.test(m);
}

// ════════════════════════════════════════════════════════
//  1) .visionimage — lihat foto & deskripsikan
// ════════════════════════════════════════════════════════
async function getImageBase64(event) {
  const msg = event.message;
  // Cari media: di pesan ini (foto + caption) ATAU di pesan yang di-reply
  let mediaMsg = null;
  if (msg.media && (msg.photo || (msg.document && /image/i.test(msg.document.mimeType || "")))) {
    mediaMsg = msg;
  } else if (msg.replyTo) {
    try {
      const r = await msg.getReplyMessage();
      if (r && (r.photo || (r.document && /image/i.test(r.document?.mimeType || "")) || r.media)) mediaMsg = r;
    } catch {}
  }
  if (!mediaMsg) return null;
  const client = event.client;
  const buf = await client.downloadMedia(mediaMsg, {});
  if (!buf || !buf.length) return null;
  // Tebak mime (default jpeg)
  let mime = "image/jpeg";
  if (mediaMsg.document?.mimeType && /image\//i.test(mediaMsg.document.mimeType)) mime = mediaMsg.document.mimeType;
  return `data:${mime};base64,${Buffer.from(buf).toString("base64")}`;
}

// ════════════════════════════════════════════════════════
//  2) .ubot — Function Calling: kendalikan ubot
// ════════════════════════════════════════════════════════
// Definisi tool yang bisa "dijalankan" AI. Eksekusi nyata ada di runUbotTool().
const UBOT_TOOLS = [
  {
    type: "function",
    function: {
      name: "execute_command",
      description: "JALANKAN/EKSEKUSI sebuah command ubot beneran (bukan cuma nampilin panduan). Pakai ini kalau user minta MELAKUKAN sesuatu lewat command, mis. 'spam 10 halo', 'bikin sticker', 'cek cuaca jakarta', 'ping', dll. Kamu yang tentuin command-nya apa & argumennya gimana berdasarkan daftar command yang tersedia.",
      parameters: {
        type: "object",
        properties: {
          command: { type: "string", description: "Nama command TANPA prefix, mis. 'spam', 'ping', 'sticker', 'weather2'." },
          args_text: { type: "string", description: "Argumen command sebagai 1 string, persis seperti yang user ketik setelah nama command. Contoh untuk 'spam 10 halo' → command='spam', args_text='10 halo'. Kosongkan kalau command ga butuh argumen." },
        },
        required: ["command"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "open_help_folder",
      description: "Buka/tampilkan sebuah folder (kategori) menu help ubot, misalnya folder 'AI', 'Fun', 'Tools', 'Islami', dll. Pakai kalau user minta MELIHAT isi folder/kategori command (bukan menjalankan).",
      parameters: {
        type: "object",
        properties: {
          folder: { type: "string", description: "Nama folder/kategori, contoh: AI, Fun, Tools, Utilitas, Islami, Grup, Generator, Math, Convert, Note, Role" },
        },
        required: ["folder"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "show_command_info",
      description: "Tampilkan detail/panduan satu command tertentu. Pakai kalau user tanya cara pakai sebuah command.",
      parameters: {
        type: "object",
        properties: { command: { type: "string", description: "Nama command tanpa prefix, contoh: carbon, sticker, ai" } },
        required: ["command"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "show_help_menu",
      description: "Tampilkan menu utama help ubot (daftar semua folder/command). Pakai kalau user minta menu/help/daftar fitur.",
      parameters: { type: "object", properties: {} },
    },
  },
  {
    type: "function",
    function: {
      name: "show_self_info",
      description: "Tampilkan info tentang ubot ini (nama, username, status) dan/atau info user yang bertanya. Pakai kalau user tanya 'kamu siapa', 'aku siapa', 'status kamu'.",
      parameters: {
        type: "object",
        properties: { about: { type: "string", enum: ["bot", "user", "both"], description: "Info yang diminta" } },
      },
    },
  },
];

// Eksekusi tool yang dipilih AI → balikin {text, action}
async function runUbotTool(toolName, argsObj, event, ctx) {
  const client = ctx.client;
  const prefix = ctx.prefix || ".";
  switch (toolName) {
    case "execute_command": {
      const cmdName = String(argsObj.command || "").replace(/^[./!]/, "").trim().toLowerCase();
      const argsText = String(argsObj.args_text || "").trim();
      if (!cmdName) return { text: `⚠️ AI ga nyebut command apa.`, did: "Command kosong" };
      // Cegah rekursi & command yang ga boleh dipanggil dari AI
      const blocked = new Set(["ubot", "code"]);
      if (blocked.has(cmdName)) return { text: `⚠️ Command <code>${prefix}${_fmt.esc(cmdName)}</code> ga bisa dijalankan lewat .ubot.`, did: `Tolak ${cmdName}` };
      const plugins = ctx.ubotPlugins;
      if (!plugins || !plugins.get) return { text: `⚠️ Eksekusi command ga tersedia.`, did: "No registry" };
      const target = plugins.get(cmdName);
      if (!target) return { text: `❓ Command <code>${prefix}${_fmt.esc(cmdName)}</code> ga ada. Coba <code>${prefix}help</code>.`, did: `Command tidak ada` };
      // Split args_text jadi array (spasi), biar sama kayak dispatch normal
      const cmdArgs = argsText.length ? argsText.split(/\s+/) : [];
      // Dukung targetUser command (mis. addprem) kalau lagi reply seseorang
      let effArgs = cmdArgs;
      if (target.targetUser && event.message.replyTo?.replyToMsgId) {
        const firstIsId = cmdArgs[0] && /^\d{5,}$/.test(cmdArgs[0]);
        if (!firstIsId) {
          try {
            const replied = await event.message.getReplyMessage();
            const rSender = replied ? await replied.getSender() : null;
            const rid = rSender?.id?.toString();
            if (rid && rSender.className === "User") effArgs = [rid, ...cmdArgs];
          } catch {}
        }
      }
      try {
        // Jalankan handler command target dengan ctx yang sama (termasuk ubotPlugins biar konsisten)
        await target.handler(event, effArgs, { client, ownerId: ctx.ownerId, prefix, ubotPlugins: plugins });
        const shown = argsText ? `${prefix}${cmdName} ${argsText}` : `${prefix}${cmdName}`;
        return { text: `✅ Menjalankan <code>${_fmt.esc(shown)}</code>`, did: `Eksekusi ${cmdName}` };
      } catch (e) {
        return { text: `❌ Gagal jalanin <code>${prefix}${_fmt.esc(cmdName)}</code>: ${_fmt.esc(e.message)}`, did: `Error ${cmdName}` };
      }
    }
    case "show_help_menu":
      return { text: `📂 Membuka menu utama help...\nKetik <code>${prefix}help</code> untuk menu lengkap dengan tombol.`, did: "Membuka menu help" };
    case "open_help_folder": {
      const folder = (argsObj.folder || "").trim();
      // Ambil command dari kategori itu lewat plugin yang ke-load
      const cats = collectCats();
      // cari kategori case-insensitive
      const key = Object.keys(cats).find(c => c.toLowerCase() === folder.toLowerCase())
        || Object.keys(cats).find(c => c.toLowerCase().includes(folder.toLowerCase()));
      if (!key) return { text: `📂 Folder "<b>${_fmt.esc(folder)}</b>" tidak ketemu. Coba <code>${prefix}help</code>.`, did: "Folder tidak ada" };
      const cmds = cats[key];
      const list = cmds.map(c => `• <code>${prefix}${c.name}</code> — ${_fmt.esc(c.description || "-")}`).join("\n");
      return { text: `📂 <b>Folder ${_fmt.esc(key)}</b> (${cmds.length} command)\n\n${list}`, did: `Membuka folder ${key}` };
    }
    case "show_command_info": {
      const cmd = (argsObj.command || "").replace(/^[./!]/, "").trim().toLowerCase();
      const cats = collectCats();
      let found = null, cat = "";
      for (const [c, arr] of Object.entries(cats)) { const f = arr.find(x => x.name === cmd); if (f) { found = f; cat = c; break; } }
      if (!found) return { text: `❓ Command "<code>${_fmt.esc(cmd)}</code>" tidak ada. Coba <code>${prefix}help</code>.`, did: "Command tidak ada" };
      return { text: `📦 <b>${_fmt.esc(found.name)}</b> (folder ${_fmt.esc(cat)})\n\n<b>Cara pakai:</b> <code>${prefix}${found.name}</code>\n<b>Fungsi:</b> ${_fmt.esc(found.description || "-")}`, did: `Info command ${cmd}` };
    }
    case "show_self_info": {
      const about = argsObj.about || "both";
      let me = {}, sender = {};
      try { const m = await client.getMe(); me = { name: m.firstName, un: m.username, id: m.id?.toString() }; } catch {}
      try { const s = await event.message.getSender(); sender = { name: s?.firstName, un: s?.username, id: s?.id?.toString() }; } catch {}
      let txt = "";
      if (about === "bot" || about === "both")
        txt += `🤖 <b>Ubot ini:</b>\nNama: <b>${_fmt.esc(me.name || "-")}</b>\nUsername: @${_fmt.esc(me.un || "-")}\nID: <code>${me.id || "-"}</code>\n`;
      if (about === "user" || about === "both")
        txt += `${txt ? "\n" : ""}👤 <b>Kamu:</b>\nNama: <b>${_fmt.esc(sender.name || "-")}</b>\nUsername: @${_fmt.esc(sender.un || "-")}\nID: <code>${sender.id || "-"}</code>`;
      return { text: txt || "Tidak ada info.", did: "Menampilkan info" };
    }
    default:
      return { text: `⚠️ Aksi "${_fmt.esc(toolName)}" belum didukung.`, did: "Aksi tak dikenal" };
  }
}

// Kumpulkan kategori→command dari semua plugin (buat tool ubot)
function collectCats() {
  const dir = __dirname;
  const cats = {};
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith(".js"))) {
    if (file === "_format.js") continue;
    try {
      const mod = require(path.join(dir, file));
      if (mod.commands) for (const c of mod.commands) {
        const cat = c.category || "Umum";
        (cats[cat] ||= []).push({ name: c.name, description: c.description });
      }
    } catch {}
  }
  return cats;
}

// ════════════════════════════════════════════════════════
//  3) .code — Reasoning: bisa bikin FILE / ZIP
// ════════════════════════════════════════════════════════
// AI diminta balas JSON: { reply, files:[{name, content}], zip:{name, files:[{name,content}]} }
// Lalu kita kirim file/zip-nya via Telegram.
const CODE_SYSTEM_EXTRA =
  `Kamu adalah asisten coding serbabisa di dalam userbot Telegram. Kamu BISA membuat file dan arsip ZIP untuk dikirim ke user.\n` +
  `WAJIB jawab HANYA dalam format JSON valid (tanpa markdown, tanpa teks lain di luar JSON), dengan struktur:\n` +
  `{\n` +
  `  "reply": "<pesan singkat untuk user, boleh kosong>",\n` +
  `  "files": [ { "name": "namafile.ext", "content": "isi file" } ],\n` +
  `  "zip": { "name": "arsip.zip", "files": [ { "name": "path/dalam/zip.ext", "content": "isi" } ] }\n` +
  `}\n` +
  `Aturan:\n` +
  `- Kalau user minta SATU/BEBERAPA file biasa → isi "files". Kosongkan "zip" (null).\n` +
  `- Kalau user minta ZIP → isi "zip" (boleh berisi banyak file). "files" boleh kosong.\n` +
  `- Kalau cuma tanya/ngobrol tanpa minta file → "files":[] dan "zip":null, jawab di "reply".\n` +
  `- "content" adalah isi file mentah (string). File kosong = "content":"".\n` +
  `- Nama file harus valid & aman (tanpa ../ atau path absolut).\n` +
  `- JANGAN bungkus JSON dengan \`\`\`. Output langsung objek JSON.`;

function safeName(n, fallback) {
  let s = String(n || fallback || "file").replace(/[\r\n]/g, "").trim();
  s = s.replace(/^([A-Za-z]:)?[\\/]+/, "").replace(/\.\.[\\/]/g, ""); // buang absolut & ../
  s = s.replace(/[^\w.\-/]+/g, "_");
  if (!s || s === "/" ) s = fallback || "file";
  return s.slice(0, 120);
}

function extractJson(text) {
  let t = String(text || "").trim();
  // buang fence kalau model bandel
  t = t.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  // ambil objek JSON pertama..terakhir
  const a = t.indexOf("{"); const b = t.lastIndexOf("}");
  if (a !== -1 && b !== -1 && b > a) t = t.slice(a, b + 1);
  return JSON.parse(t);
}

async function sendOneFile(client, peerId, replyToId, name, content) {
  const fname = safeName(name, "file.txt");
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "ubotcode_"));
  const full = path.join(tmpDir, path.basename(fname));
  fs.writeFileSync(full, content == null ? "" : String(content));
  try {
    await client.sendFile(peerId, { file: full, forceDocument: true, replyTo: replyToId, caption: `📄 <code>${_fmt.esc(fname)}</code>`, parseMode: "html" });
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

// ── Pure-Node ZIP writer (store, no compression) — zero dependency, selalu jalan ──
// Bikin file .zip valid tanpa butuh library eksternal (aman di Pterodactyl tanpa npm install).
function crc32(buf) {
  let c, crc = 0xffffffff;
  if (!crc32.table) {
    crc32.table = [];
    for (let n = 0; n < 256; n++) {
      c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      crc32.table[n] = c >>> 0;
    }
  }
  for (let i = 0; i < buf.length; i++) crc = crc32.table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function dosTime(d = new Date()) {
  const time = ((d.getHours() & 0x1f) << 11) | ((d.getMinutes() & 0x3f) << 5) | ((Math.floor(d.getSeconds() / 2)) & 0x1f);
  const date = (((d.getFullYear() - 1980) & 0x7f) << 9) | (((d.getMonth() + 1) & 0xf) << 5) | (d.getDate() & 0x1f);
  return { time, date };
}
function buildZipBuffer(entries) {
  // entries: [{name, content(Buffer)}]
  const { time, date } = dosTime();
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const e of entries) {
    const nameBuf = Buffer.from(e.name, "utf8");
    const data = Buffer.isBuffer(e.content) ? e.content : Buffer.from(String(e.content == null ? "" : e.content), "utf8");
    const crc = crc32(data);
    // Local file header
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0);
    lh.writeUInt16LE(20, 4);      // version needed
    lh.writeUInt16LE(0x0800, 6);  // flags: UTF-8 filename
    lh.writeUInt16LE(0, 8);       // method: store
    lh.writeUInt16LE(time, 10);
    lh.writeUInt16LE(date, 12);
    lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(data.length, 18); // compressed size
    lh.writeUInt32LE(data.length, 22); // uncompressed size
    lh.writeUInt16LE(nameBuf.length, 26);
    lh.writeUInt16LE(0, 28);      // extra len
    locals.push(lh, nameBuf, data);

    // Central directory header
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0);
    ch.writeUInt16LE(20, 4);      // version made by
    ch.writeUInt16LE(20, 6);      // version needed
    ch.writeUInt16LE(0x0800, 8);  // flags
    ch.writeUInt16LE(0, 10);      // method
    ch.writeUInt16LE(time, 12);
    ch.writeUInt16LE(date, 14);
    ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(data.length, 20);
    ch.writeUInt32LE(data.length, 24);
    ch.writeUInt16LE(nameBuf.length, 28);
    ch.writeUInt16LE(0, 30);      // extra len
    ch.writeUInt16LE(0, 32);      // comment len
    ch.writeUInt16LE(0, 34);      // disk number
    ch.writeUInt16LE(0, 36);      // internal attrs
    ch.writeUInt32LE(0, 38);      // external attrs
    ch.writeUInt32LE(offset, 42); // local header offset
    centrals.push(ch, nameBuf);

    offset += lh.length + nameBuf.length + data.length;
  }
  const localPart = Buffer.concat(locals);
  const centralPart = Buffer.concat(centrals);
  // End of central directory
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralPart.length, 12);
  eocd.writeUInt32LE(localPart.length, 16);
  eocd.writeUInt16LE(0, 20);
  return Buffer.concat([localPart, centralPart, eocd]);
}

async function sendZip(client, peerId, replyToId, zipName, files) {
  const entries = (files || []).map(f => ({ name: safeName(f.name, "file.txt"), content: f.content == null ? "" : String(f.content) }));
  const zname = safeName(zipName, "arsip.zip").replace(/\.zip$/i, "") + ".zip";
  const buf = buildZipBuffer(entries);
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "ubotzip_"));
  const full = path.join(tmpDir, path.basename(zname));
  fs.writeFileSync(full, buf);
  try {
    await client.sendFile(peerId, { file: full, forceDocument: true, replyTo: replyToId, caption: `🗜️ <code>${_fmt.esc(zname)}</code> (${entries.length} file)`, parseMode: "html" });
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

// ════════════════════════════════════════════════════════
//  COMMANDS
// ════════════════════════════════════════════════════════
const commands = [
  // ── .visionimage ──
  {
    name: "visionimage",
    description: "Lihat & deskripsikan foto pakai AI (reply foto / kirim foto + caption). Contoh: .visionimage ada apa di foto ini? — butuh GROQ_API_KEY",
    category: "AI",
    handler: async (event, args, ctx) => {
      if (!process.env.GROQ_API_KEY) return needKey(event);
      let img;
      try { img = await getImageBase64(event); }
      catch (e) { return _fmt.reply(event, `❌ Gagal ambil foto: ${_fmt.esc(e.message)}`); }
      if (!img) return _fmt.reply(event, `❌ Reply sebuah <b>foto</b> atau kirim foto bareng <code>.visionimage</code>.\nContoh: reply foto → <code>.visionimage ada apa di foto ini?</code>`);

      const q = (await getText(event, args)) || "Deskripsikan gambar ini secara detail dalam Bahasa Indonesia.";
      let thinking;
      try { thinking = await event.message.reply({ message: `<blockquote><b>👁️ Menganalisis gambar...</b></blockquote>`, parseMode: "html" }); } catch {}
      try {
        const system = await buildSystem(event, ctx, "Kamu sedang melihat sebuah gambar yang dikirim user. Jelaskan dengan akurat sesuai yang terlihat.");
        const data = await groqChat({
          model: VISION_MODEL,
          messages: [
            { role: "system", content: system },
            { role: "user", content: [
              { type: "text", text: q },
              { type: "image_url", image_url: { url: img } },
            ] },
          ],
          temperature: 0.4,
          max_tokens: 1500,
        });
        let out = data?.choices?.[0]?.message?.content?.trim() || "(kosong)";
        if (out.length > 3800) out = out.slice(0, 3800) + "...";
        const body = `<blockquote><b>👁️ <b>Vision</b>\n\n${_fmt.esc(out)}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: body, parseMode: "html" }); return; } catch {} }
        return event.message.reply({ message: body, parseMode: "html" });
      } catch (e) {
        const err = `<blockquote><b>❌ Gagal: ${_fmt.esc(e.message)}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); return; } catch {} }
        return event.message.reply({ message: err, parseMode: "html" });
      }
    },
  },

  // ── .ubot (Function Calling / Tool Use) ──
  {
    name: "ubot",
    description: "Kendalikan & JALANKAN command ubot pakai bahasa natural. Contoh: .ubot spam 10 halo / .ubot cek cuaca jakarta / .ubot buka folder ai — butuh GROQ_API_KEY",
    category: "AI",
    handler: async (event, args, ctx) => {
      if (!process.env.GROQ_API_KEY) return needKey(event);
      const q = await getText(event, args);
      if (!q) return _fmt.reply(event, `❌ Format: <code>.ubot spam 10 halo</code>, <code>.ubot cek cuaca jakarta</code>, atau <code>.ubot buka folder ai</code>`);

      try {
        // Daftar command yang tersedia (biar AI tahu apa yang bisa dieksekusi)
        const cats = collectCats();
        const cmdList = Object.entries(cats).map(([cat, arr]) =>
          `[${cat}] ` + arr.map(c => c.name).join(", ")).join("\n");

        const system = await buildSystem(event, ctx,
          "Kamu PUNYA akses tool untuk MENGENDALIKAN & MENJALANKAN command ubot. " +
          "Kalau user minta MELAKUKAN sesuatu (mis. 'spam 10 halo', 'cek cuaca jakarta', 'bikin sticker', 'ping'), " +
          "PANGGIL tool execute_command dengan nama command yang tepat + argumennya. " +
          "Kalau user cuma minta LIHAT folder/menu/panduan, pakai tool tampilan (open_help_folder/show_command_info/show_help_menu). " +
          "Kalau cuma ngobrol, jawab biasa tanpa tool. Jawaban akhir ringkas, Bahasa Indonesia.\n\n" +
          "Daftar command yang tersedia (nama command per kategori):\n" + cmdList);

        const messages = [
          { role: "system", content: system },
          { role: "user", content: q },
        ];
        // Putaran 1: minta model pilih tool
        const first = await groqChat({
          model: UBOT_MODEL,
          messages,
          tools: UBOT_TOOLS,
          tool_choice: "auto",
          temperature: 0.3,
          max_tokens: 800,
        });
        const m = first?.choices?.[0]?.message || {};
        const calls = m.tool_calls || [];

        if (!calls.length) {
          // tidak ada tool → jawab langsung
          let out = (m.content || "").trim() || "Siap! Ada yang bisa dibantu?";
          if (out.length > 3500) out = out.slice(0, 3500) + "...";
          return _fmt.reply(event, `🛰️ <b>Ubot AI</b>\n\n${out}`);
        }

        // Jalankan semua tool yang diminta, kumpulkan hasil
        const segments = [];
        const didList = [];
        messages.push({ role: "assistant", content: m.content || "", tool_calls: calls });
        for (const call of calls) {
          let argObj = {};
          try { argObj = JSON.parse(call.function?.arguments || "{}"); } catch {}
          const res = await runUbotTool(call.function?.name, argObj, event, ctx);
          segments.push(res.text);
          didList.push(res.did);
          messages.push({ role: "tool", tool_call_id: call.id, name: call.function?.name, content: res.text.replace(/<[^>]+>/g, "") });
        }

        // Header kecil "tindakan" + isi hasil tool
        const header = `🛰️ <b>Ubot AI</b>\n<i>${_fmt.esc(didList.join(" • "))}</i>`;
        const full = `<blockquote><b>${header}</b></blockquote>\n` + segments.map(s => `<blockquote><b>${s}</b></blockquote>`).join("\n");
        return event.message.reply({ message: full, parseMode: "html" });
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },

  // ── .code (Reasoning + bikin file/zip) ──
  {
    name: "code",
    description: "Asisten coding yang bisa BIKIN file/zip langsung dikirim via Telegram. Contoh: .code bikin index.js kosong / .code bikinin zip isi index.js — butuh GROQ_API_KEY (fallback Cerebras saat limit)",
    category: "AI",
    handler: async (event, args, ctx) => {
      const groqKey = process.env.GROQ_API_KEY;
      const cereKey = process.env.CEREBRAS_API_KEY;
      if (!groqKey && !cereKey) return needKey(event);
      const q = await getText(event, args);
      if (!q) return _fmt.reply(event, `❌ Format:\n• <code>.code bikin index.js kosong</code>\n• <code>.code bikinin zip isi index.js kosong</code>\n• <code>.code buatkan script python hello world</code>`);

      let thinking;
      try { thinking = await event.message.reply({ message: `<blockquote><b>🧠 Berpikir & menyiapkan file...</b></blockquote>`, parseMode: "html" }); } catch {}

      const system = await buildSystem(event, ctx, CODE_SYSTEM_EXTRA);
      const baseBody = {
        messages: [ { role: "system", content: system }, { role: "user", content: q } ],
        temperature: 0.3, max_tokens: 6000, reasoning_effort: "high",
        response_format: { type: "json_object" },
      };

      let data = null, usedCerebras = false, lastErr = null;
      // 1) Coba Groq dulu
      if (groqKey) {
        try { data = await groqChat({ ...baseBody, model: CODE_MODEL }, 90000); }
        catch (e) {
          lastErr = e;
          // bukan limit & ga ada cerebras → langsung lapor error
          if (!cereKey) {
            const err = `<blockquote><b>❌ Gagal: ${_fmt.esc(e.message)}</b></blockquote>`;
            if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); return; } catch {} }
            return event.message.reply({ message: err, parseMode: "html" });
          }
          // ada cerebras → fallback (khususnya kalau limit)
        }
      }
      // 2) Fallback Cerebras
      if (!data && cereKey) {
        usedCerebras = true;
        const why = (lastErr && isLimitError(lastErr.status, lastErr.message)) ? "Groq limit" : "Groq gagal";
        if (thinking) { try { await thinking.edit({ text: `<blockquote><b>⚠️ ${why} — pindah ke Cerebras (cadangan)...\n🧠 Menyiapkan file...</b></blockquote>`, parseMode: "html" }); } catch {} }
        try { data = await cerebrasChat({ ...baseBody, model: CODE_MODEL_CEREBRAS }, 90000); }
        catch (e) {
          const err = `<blockquote><b>❌ Groq & Cerebras dua-duanya gagal.\nGroq: ${_fmt.esc(lastErr?.message || "-")}\nCerebras: ${_fmt.esc(e.message)}</b></blockquote>`;
          if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); return; } catch {} }
          return event.message.reply({ message: err, parseMode: "html" });
        }
      }
      if (!data) {
        const err = `<blockquote><b>❌ Gagal: ${_fmt.esc(lastErr?.message || "tidak ada respon")}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); return; } catch {} }
        return event.message.reply({ message: err, parseMode: "html" });
      }

      try {
        const tag = usedCerebras ? " <i>(via Cerebras)</i>" : "";
        const raw = data?.choices?.[0]?.message?.content || "";
        let parsed;
        try { parsed = extractJson(raw); }
        catch (e) {
          // Model ga balikin JSON → tampilkan sebagai teks biasa
          let out = raw.trim() || "(kosong)";
          if (out.length > 3500) out = out.slice(0, 3500) + "...";
          const body = `<blockquote><b>🧠 Code${tag}\n\n${_fmt.esc(out)}</b></blockquote>`;
          if (thinking) { try { await thinking.edit({ text: body, parseMode: "html" }); return; } catch {} }
          return event.message.reply({ message: body, parseMode: "html" });
        }

        const client = ctx.client;
        const peerId = event.message.peerId;
        const replyToId = event.message.id;
        const files = Array.isArray(parsed.files) ? parsed.files : [];
        const zip = parsed.zip && Array.isArray(parsed.zip.files) ? parsed.zip : null;

        const replyText = (parsed.reply || "").toString().trim();
        const body = `<blockquote><b>🧠 Code${tag}${replyText ? "\n\n" + _fmt.esc(replyText.slice(0, 3000)) : ""}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: body, parseMode: "html" }); } catch {} }
        else { try { await event.message.reply({ message: body, parseMode: "html" }); } catch {} }

        // Kirim file biasa
        let sent = 0;
        for (const f of files.slice(0, 15)) {
          try { await sendOneFile(client, peerId, replyToId, f.name, f.content); sent++; } catch (e) { /* skip */ }
        }
        // Kirim zip
        if (zip && zip.files.length) {
          try { await sendZip(client, peerId, replyToId, zip.name, zip.files); sent++; } catch (e) {
            try { await event.message.reply({ message: `<blockquote><b>❌ Gagal bikin zip: ${_fmt.esc(e.message)}</b></blockquote>`, parseMode: "html" }); } catch {}
          }
        }
        if (!sent && !replyText) {
          try { await event.message.reply({ message: `<blockquote><b>ℹ️ Tidak ada file dihasilkan.</b></blockquote>`, parseMode: "html" }); } catch {}
        }
      } catch (e) {
        const err = `<blockquote><b>❌ Gagal: ${_fmt.esc(e.message)}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); return; } catch {} }
        return event.message.reply({ message: err, parseMode: "html" });
      }
    },
  },

  // ── .cimage (RapidAPI — DALL-E based, High quality image gen) ──
  //   Format: .cimage {prompt} | {width} | {height}   (width/height opsional, default 512)
  {
    name: "cimage",
    description: "Bikin gambar dari teks (RapidAPI DALL-E, fallback Krea 2/HuggingFace). Format: .cimage <prompt> | <width> | <height>",
    category: "AI",
    handler: async (event, args, ctx) => {
      const key = process.env.RAPIDAPI_KEY;
      const hfKey = process.env.HF_TOKEN || process.env.HUGGINGFACE_API_KEY;
      if (!key && !hfKey) return _fmt.reply(event,
        `🔑 <b>Fitur Cimage belum aktif</b>\n\nButuh <code>RAPIDAPI_KEY</code> (atau <code>HF_TOKEN</code> buat Krea 2) di <code>gwajib.env</code>.`);

      // Parse: prompt | width | height
      let raw = args.join(" ").trim();
      if (!raw && event.message.replyTo) { try { const r = await event.message.getReplyMessage(); raw = (r?.text || r?.message || "").trim(); } catch {} }
      if (!raw) return _fmt.reply(event, `❌ Format: <code>.cimage seekor anjing lucu | 512 | 512</code>\n<i>(width & height opsional, default 512)</i>`);

      const parts = raw.split("|").map(s => s.trim());
      const prompt = parts[0];
      let width = parseInt(parts[1]) || 512;
      let height = parseInt(parts[2]) || 512;
      // batasi ukuran wajar
      width = Math.max(128, Math.min(1024, width));
      height = Math.max(128, Math.min(1024, height));
      if (!prompt) return _fmt.reply(event, `❌ Prompt kosong. Format: <code>.cimage anjing lucu | 512 | 512</code>`);

      let thinking;
      try { thinking = await event.message.reply({ message: `<blockquote><b>🎨 Membuat gambar (${width}x${height})...</b></blockquote>`, parseMode: "html" }); } catch {}

      try {
        // ── Coba RapidAPI dulu; kalau kuota habis/limit → fallback Krea 2 (HuggingFace) ──
        let buf = null, sourceLabel = "";
        let rapidExhausted = false;

        // Attempt 1: RapidAPI (DALL-E based)
        if (process.env.RAPIDAPI_KEY) {
          try {
            const ENDPOINTS = [
              "https://chatgpt-42.p.rapidapi.com/texttoimage",
              "https://chatgpt-42.p.rapidapi.com/texttoimage3",
              "https://chatgpt-42.p.rapidapi.com/matag2image",
              "https://chatgpt-42.p.rapidapi.com/dalle",
              "https://chatgpt-42.p.rapidapi.com/dalle2",
              "https://chatgpt-42.p.rapidapi.com/dalle3",
            ];
            let data = null, lastErr = null;
            for (const url of ENDPOINTS) {
              const ctrl = new AbortController();
              const t = setTimeout(() => ctrl.abort(), 120000);
              try {
                const res = await fetch(url, {
                  method: "POST", signal: ctrl.signal,
                  headers: { "Content-Type": "application/json", "x-rapidapi-key": process.env.RAPIDAPI_KEY, "x-rapidapi-host": "chatgpt-42.p.rapidapi.com" },
                  body: JSON.stringify({ text: prompt, width, height }),
                });
                const j = await res.json().catch(() => ({}));
                if (res.ok && (j?.generated_image || j?.url || j?.result || j?.image)) { data = j; clearTimeout(t); break; }
                const msg = j?.message || j?.error || ("HTTP " + res.status);
                // Kuota RapidAPI habis (429 / "exceeded the ... requests per ...") → tandai buat fallback
                if (res.status === 429 || /exceed|quota|limit|too many|subscribe|not subscribed|monthly/i.test(String(msg))) { rapidExhausted = true; lastErr = new Error(msg); clearTimeout(t); break; }
                lastErr = new Error(msg);
                if (!/does not exist|not found|404|no such|invalid endpoint/i.test(String(msg))) { clearTimeout(t); throw lastErr; }
              } catch (e) {
                lastErr = e;
                if (/exceed|quota|limit|too many|subscribe|429/i.test(String(e.message))) { rapidExhausted = true; clearTimeout(t); break; }
                if (!/does not exist|not found|404|no such|invalid endpoint|abort/i.test(String(e.message))) { clearTimeout(t); throw e; }
              } finally { clearTimeout(t); }
            }
            if (data) {
              const imgUrl = data?.generated_image || data?.url || data?.result || data?.image;
              if (imgUrl) {
                const dctrl = new AbortController(); const dt = setTimeout(() => dctrl.abort(), 60000);
                try {
                  const imgRes = await fetch(imgUrl, { signal: dctrl.signal, redirect: "follow", headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36", "Accept": "*/*" } });
                  if (imgRes.ok) { buf = Buffer.from(await imgRes.arrayBuffer()); sourceLabel = "DALL-E (RapidAPI)"; }
                } finally { clearTimeout(dt); }
              }
            }
            if (!buf && !rapidExhausted && lastErr) throw lastErr;
          } catch (e) {
            // kalau bukan soal kuota → lempar (biar user tau errornya). Kalau kuota → lanjut Krea.
            if (!rapidExhausted && !/exceed|quota|limit|too many|subscribe|429/i.test(String(e.message))) throw e;
            rapidExhausted = true;
          }
        } else {
          rapidExhausted = true; // ga ada RapidAPI key → langsung Krea
        }

        // Attempt 2: Krea 2 Turbo (HuggingFace) — kalau RapidAPI habis/ga ada
        if (!buf && rapidExhausted) {
          const hfKey = process.env.HF_TOKEN || process.env.HUGGINGFACE_API_KEY;
          if (!hfKey) throw new Error("Kuota RapidAPI habis & HF_TOKEN belum diisi buat fallback Krea 2. Isi HF_TOKEN di gwajib.env.");
          if (thinking) { try { await thinking.edit({ text: `<blockquote><b>🎨 RapidAPI limit — pakai Krea 2 Turbo (1024x1024)...</b></blockquote>`, parseMode: "html" }); } catch {} }
          buf = await genKrea2(hfKey, prompt);
          sourceLabel = "Krea 2 Turbo (HuggingFace)";
        }

        if (!buf || !buf.length) throw new Error("Gagal menghasilkan gambar.");

        const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "ubotimg_"));
        const out = path.join(tmpDir, "cimage.png");
        fs.writeFileSync(out, buf);
        try {
          const dimLabel = /Krea/.test(sourceLabel) ? "1024x1024" : `${width}x${height}`;
          const caption = `🎨 <b>${_fmt.esc(prompt.slice(0, 200))}</b>\n<i>${dimLabel} · ${_fmt.esc(sourceLabel)}</i>`;
          await ctx.client.sendFile(event.message.peerId, { file: out, replyTo: event.message.id, forceDocument: false, caption, parseMode: "html" });
          if (thinking) { try { await thinking.delete(); } catch {} }
        } finally { try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {} }
      } catch (e) {
        const err = `<blockquote><b>❌ Gagal: ${_fmt.esc(e.message)}</b></blockquote>`;
        if (thinking) { try { await thinking.edit({ text: err, parseMode: "html" }); return; } catch {} }
        return event.message.reply({ message: err, parseMode: "html" });
      }
    },
  },
];

module.exports = { commands };
