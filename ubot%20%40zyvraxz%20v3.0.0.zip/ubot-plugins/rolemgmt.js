// ─────────────────────────────────────────
//  Plugin: Manajemen Role lewat Userbot
//  Command nambah/extend/remove user — sesuai role pemilik ubot.
//  Reseller cuma bisa .addprem | Admin +.addreseller | Owner +.addadmin | dst.
//  Plus command LIHAT role: .list, .listprem, .listreseller, dst + .role (cek role target).
//  Semua operasi ke database yang SAMA dengan bot manager.
// ─────────────────────────────────────────
const _fmt = require("./_format");
const db = require("../lib/database");

const esc = _fmt.esc;

// Label + emoji tiap role (buat tampilan list/role)
const ROLE_LABEL = {
  prem: "💎 Prem",
  reseller: "🪙 Reseller",
  admin: "🛡️ Admin",
  owner: "👑 Owner",
  tk: "🐉 TK",
  ceo: "🌟 CEO",
  allrole: "🌈 Allrole",
  pemilik: "♾️ Pemilik",
  user: "👤 User",
};

// Urutan role dari tertinggi ke terendah (buat .list & .list{role})
const ROLE_ORDER = ["allrole", "ceo", "tk", "owner", "admin", "reseller", "prem"];

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

// Format tanggal WIB
function tgl(ts) {
  if (!ts) return "permanen";
  return new Date(ts).toLocaleDateString("id-ID", {
    day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Jakarta",
  });
}

// Username bot manager (buat petunjuk connect) — di-auto-set index.js pas boot
function botUsername() {
  return (process.env.BOT_USERNAME || "").trim();
}

// Petunjuk connect ubot: user yang baru di-add harus chat bot manager buat nyambungin ubotnya
function connectHint(role) {
  const usn = botUsername();
  if (!usn) return "";
  return (
    `\n\n📌 <b>Biar ${esc(role)} bisa mulai pakai ubot:</b>\n` +
    `Suruh dia chat bot <b>${esc(usn)}</b> → ketik <code>/start</code> → tekan tombol <b>🤖 Buat Userbot</b> (atau ketik <code>/connect</code>) buat nyambungin akunnya.`
  );
}

// Resolve username + nama dari sebuah user id (via client, fallback riwayat username)
async function resolveUser(client, id) {
  let username = null, name = null;
  try {
    const ent = await client.getEntity(parseInt(id));
    if (ent) { username = ent.username || null; name = ent.firstName || ent.username || null; }
  } catch { /* ga kenal / ga bisa resolve → fallback ke riwayat */ }
  if (!username) {
    try {
      const hist = require("../lib/usnHistory").getHistory(id);
      if (hist && hist.length) username = hist[hist.length - 1].username || null;
    } catch {}
  }
  return { username, name };
}

// Baris satu user di daftar: "• 123456 — @usn"
async function userLine(client, u) {
  const { username } = await resolveUser(client, u.id);
  const usnTxt = username ? `@${esc(username)}` : "<i>tanpa username</i>";
  return `• <code>${esc(u.id)}</code> — ${usnTxt}`;
}

// ── HANDLER: .add{role} ──
// Bikin handler generik buat .add{role}
function makeAddHandler(targetRole) {
  return async (event, args, ctx) => {
    // Cek izin: role pemilik ubot harus boleh nambah targetRole
    if (!db.canAddRole(ctx.ownerId, targetRole)) {
      return _fmt.reply(event,
        `❌ Role kamu tidak bisa menambahkan <b>${targetRole}</b>.\n` +
        `Command ini cuma buat role yang setingkat di atas <b>${targetRole}</b>.`);
    }
    const targetId = args[0];
    if (!targetId || isNaN(parseInt(targetId))) {
      return _fmt.reply(event, `❌ Format: <code>.add${targetRole} &lt;user_id&gt; [hari]</code>`);
    }
    if (db.OWNER_IDS.includes(targetId.toString())) {
      return _fmt.reply(event, `❌ User itu Pemilik, tidak bisa diubah.`);
    }
    const days = args[1] ? parseInt(args[1]) : 30;
    if (isNaN(days) || days < 1) return _fmt.reply(event, `❌ Durasi hari tidak valid.`);

    const added = db.addUser(targetId, targetRole, ctx.ownerId, days);
    return _fmt.reply(event,
      `✅ <b>${targetRole}</b> ditambahkan!\n\n` +
      `user id: <code>${targetId}</code>\n` +
      `role: <b>${targetRole}</b>\n` +
      `aktif: <b>${days} hari</b> (sampai ${tgl(added.expiresAt)})` +
      connectHint(targetRole));
  };
}

// Daftar role yang bisa ditambah (otomatis bikin command .add{role})
// "allrole" 🌈 = setara CEO, cuma bisa dikasih pemilik (dijaga CAN_ADD di database.js).
const ADD_ROLES = ["prem", "reseller", "admin", "owner", "tk", "ceo", "allrole", "pemilik"];

const commands = ADD_ROLES.map((r) => ({
  name: `add${r}`,
  description: `Tambah user role ${r} (sesuai izin role kamu) — bisa sambil reply orang`,
  category: "Role",
  targetUser: true, // boleh dipakai dengan reply: id orang yang di-reply jadi args[0]
  handler: makeAddHandler(r),
}));

// ── HANDLER: .list{role} — daftar user 1 role tertentu ──
function makeListHandler(role) {
  return async (event, args, ctx) => {
    // getAllManaged() = semua user aktif (non-expired, non-pemilik) → filter role-nya
    const users = db.getAllManaged().filter((u) => u.role === role);
    const label = ROLE_LABEL[role] || role;
    if (!users.length) {
      return _fmt.reply(event, `📋 <b>Daftar ${label}</b>\n\nBelum ada user dengan role ini.`);
    }
    const lines = await Promise.all(users.map((u) => userLine(ctx.client, u)));
    return _fmt.reply(event,
      `📋 <b>Daftar ${label}</b>\n` +
      `Total: <b>${users.length}</b> user\n\n` +
      lines.join("\n"));
  };
}

for (const r of ROLE_ORDER) {
  commands.push({
    name: `list${r}`,
    description: `Lihat semua user role ${r} (id + username) yang terdaftar`,
    category: "Role",
    handler: makeListHandler(r),
  });
}

// ── HANDLER: .list — semua role sekaligus ──
commands.push({
  name: "list",
  description: "Lihat SEMUA user terdaftar (role + username + id)",
  category: "Role",
  handler: async (event, args, ctx) => {
    const managed = db.getAllManaged();
    if (!managed.length) {
      return _fmt.reply(event, `📋 <b>Daftar Semua Role</b>\n\nBelum ada user terdaftar.`);
    }
    // Kelompokkan per role
    const byRole = {};
    for (const u of managed) (byRole[u.role] ||= []).push(u);

    const blocks = [`📋 <b>Daftar Semua Role</b>`, `Total: <b>${managed.length}</b> user\n`];
    for (const role of ROLE_ORDER) {
      const arr = byRole[role];
      if (!arr || !arr.length) continue;
      const lines = await Promise.all(arr.map((u) => userLine(ctx.client, u)));
      blocks.push(`${ROLE_LABEL[role] || role} — ${arr.length}`);
      blocks.push(lines.join("\n"));
      blocks.push("");
    }
    return _fmt.reply(event, blocks.join("\n").trim());
  },
});

// ── HANDLER: .role — cek role + detail user target (id / reply) ──
commands.push({
  name: "role",
  description: "Cek role & detail user — .role <id> atau reply pesan target",
  category: "Role",
  targetUser: true,
  handler: async (event, args, ctx) => {
    // Default: cek diri sendiri kalau ga ada target
    const targetId = (args[0] || ctx.ownerId).toString();
    const isSelf = targetId === ctx.ownerId.toString();

    const role = db.getRole(targetId);
    const u = db.getUser(targetId);
    const { username, name } = await resolveUser(ctx.client, targetId);

    const label = ROLE_LABEL[role] || role;
    const usnTxt = username ? `@${esc(username)}` : "tanpa username";
    const lines = [
      `🔎 <b>Info Role${isSelf ? " (kamu)" : ""}</b>`,
      `⏣────────────────⏣\n`,
      `nama: <b>${esc(name || "-")}</b>`,
      `user id: <code>${esc(targetId)}</code>`,
      `username: ${usnTxt}`,
      `role: <b>${label}</b>`,
    ];
    if (db.OWNER_IDS.includes(targetId)) {
      lines.push(`\n<i>User ini Pemilik (kuasa penuh, tidak pernah expired).</i>`);
    } else if (u && role !== "user") {
      lines.push(`ditambah oleh: <code>${esc(u.addedBy || "-")}</code>`);
      lines.push(`sejak: <b>${tgl(u.addedAt)}</b>`);
      lines.push(`aktif sampai: <b>${tgl(u.expiresAt)}</b>`);
    } else {
      lines.push(`\n<i>User biasa — belum punya akses ubot.</i>`);
    }
    return _fmt.reply(event, lines.join("\n"));
  },
});

// ── HANDLER: .removenousn — hapus semua user TANPA username (role di bawah kamu) ──
commands.push({
  name: "removenousn",
  description: "Hapus SEMUA user terdaftar yang tanpa username (cuma role di bawah kamu)",
  category: "Role",
  handler: async (event, args, ctx) => {
    const myRole = db.getRole(ctx.ownerId);
    // Cuma proses user dengan role DI BAWAH kamu (aman: ga bisa nyentuh yang setara/lebih tinggi)
    const managed = db.getAllManaged().filter((u) => db.ROLES[u.role] < db.ROLES[myRole]);
    if (!managed.length) {
      return _fmt.reply(event, `ℹ️ Tidak ada user (di bawah role kamu) untuk dicek.`);
    }
    await _fmt.reply(event, `🔎 Mengecek ${managed.length} user... (resolve username, sabar ya)`);

    const noUsn = [];
    for (const u of managed) {
      const { username } = await resolveUser(ctx.client, u.id);
      if (!username) noUsn.push(u);
      await sleep(120); // jeda kecil biar ga kena limit resolve
    }
    if (!noUsn.length) {
      return _fmt.reply(event, `✅ Semua user (di bawah role kamu) punya username. Tidak ada yang dihapus.`);
    }

    let removed = 0;
    const removedIds = [];
    for (const u of noUsn) {
      if (db.OWNER_IDS.includes(u.id.toString())) continue; // jangan sentuh pemilik
      if (db.removeUser(u.id)) {
        removed++;
        removedIds.push(u.id);
        try { await require("../lib/ubotManager").stopUbot(u.id.toString()); } catch {}
      }
    }
    const preview = removedIds.slice(0, 20).map((id) => `• <code>${esc(id)}</code>`).join("\n");
    return _fmt.reply(event,
      `🗑 <b>Removenousn selesai</b>\n\n` +
      `dicek: <b>${managed.length}</b> user\n` +
      `tanpa username: <b>${noUsn.length}</b>\n` +
      `dihapus: <b>${removed}</b>\n\n` +
      (preview ? `${preview}${removedIds.length > 20 ? `\n… +${removedIds.length - 20} lagi` : ""}` : ""));
  },
});

// .extend <id> <hari>
commands.push({
  name: "extend",
  description: "Perpanjang masa aktif user (role di bawah kamu) — bisa sambil reply orang",
  category: "Role",
  targetUser: true,
  handler: async (event, args, ctx) => {
    const targetId = args[0];
    const days = parseInt(args[1]);
    if (!targetId || isNaN(days) || days < 1) {
      return _fmt.reply(event, `❌ Format: <code>.extend &lt;user_id&gt; &lt;hari&gt;</code>`);
    }
    const t = db.getUser(targetId);
    if (!t) return _fmt.reply(event, `❌ User <code>${targetId}</code> belum terdaftar.`);
    const myRole = db.getRole(ctx.ownerId);
    if (db.ROLES[t.role] >= db.ROLES[myRole]) {
      return _fmt.reply(event, `❌ Tidak bisa extend user dengan role setara/lebih tinggi.`);
    }
    const exp = db.extendUser(targetId, days);
    return _fmt.reply(event,
      `✅ <b>Extend berhasil</b>\n\n` +
      `user id: <code>${targetId}</code>\n` +
      `tambah: <b>${days} hari</b>\n` +
      `expired: <b>${tgl(exp)}</b>`);
  },
});

// .remove <id> — cuma role di bawah pemilik ubot
commands.push({
  name: "remove",
  description: "Hapus user (jadi user biasa) — cuma role di bawah kamu, bisa sambil reply orang",
  category: "Role",
  targetUser: true,
  handler: async (event, args, ctx) => {
    const targetId = args[0];
    if (!targetId) return _fmt.reply(event, `❌ Format: <code>.remove &lt;user_id&gt;</code>`);
    if (db.OWNER_IDS.includes(targetId.toString())) {
      return _fmt.reply(event, `❌ Tidak bisa menghapus Pemilik.`);
    }
    const myRole = db.getRole(ctx.ownerId);
    const tRole = db.getRole(targetId);
    if (tRole === "user") return _fmt.reply(event, `ℹ️ User <code>${targetId}</code> memang bukan member.`);
    if (db.ROLES[tRole] >= db.ROLES[myRole]) {
      return _fmt.reply(event, `❌ Cuma bisa hapus user dengan role DI BAWAH kamu.`);
    }
    const ok = db.removeUser(targetId);
    // Matikan ubot target (lazy require biar ga circular)
    try { await require("../lib/ubotManager").stopUbot(targetId.toString()); } catch {}
    return _fmt.reply(event, ok
      ? `✅ User <code>${targetId}</code> dihapus (balik jadi user biasa).`
      : `❌ Gagal menghapus.`);
  },
});

module.exports = { commands };
