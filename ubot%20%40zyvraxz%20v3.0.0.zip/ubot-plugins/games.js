// ─────────────────────────────────────────
//  Plugin: GAME (individu + party)
//  - Game individu: main sendiri (owner). Jawaban diketik tanpa prefix.
//  - Game party: di grup, join ketik "Bergabung", host .mulai / .batal.
//  Interceptor dipanggil ubotManager utk nangkep pesan polos (join/jawaban/gerakan).
// ─────────────────────────────────────────
const _fmt = require("./_format");
const esc = _fmt.esc;

// ── STATE ──
const soloGames = new Map();   // key ownerId:chatId -> { type, ...data }
const lobbies = new Map();     // key ownerId:chatId -> { type,label,status,players,data,... }
const botMsgIds = new Set();   // "chatId:msgId" output bot (biar ga dianggap jawaban)
const lastGame = new Map();     // chatKey -> { kind:"solo"|"party", type } (buat .lagi)
function prefOf(ownerId) { try { return require("./prefixStore").getPrefix(ownerId); } catch { return process.env.UBOT_PREFIX || "."; } }

// ── HELPER ──
function chatIdOf(msg) {
  if (msg.chatId != null) return msg.chatId.toString();
  const p = msg.peerId;
  return (p?.channelId || p?.chatId || p?.userId || "0").toString();
}
function rint(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function norm(s) { return (s || "").toLowerCase().trim().replace(/[^a-z0-9 ]/gi, "").replace(/\s+/g, " "); }
function scramble(w) {
  const a = w.split("");
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  const r = a.join("");
  return r === w ? scramble(w) : r;
}

async function gsend(client, peer, html, buttons) {
  try {
    const sent = await client.sendMessage(peer, { message: html, parseMode: "html", buttons });
    if (sent && sent.id != null) {
      const cid = (sent.chatId != null ? sent.chatId.toString() : chatIdOf(sent));
      botMsgIds.add(cid + ":" + sent.id);
      if (botMsgIds.size > 600) { const it = botMsgIds.values(); for (let i = 0; i < 250; i++) botMsgIds.delete(it.next().value); }
    }
    return sent;
  } catch (e) { return null; }
}
async function nameOf(client, senderId, msg) {
  try { const s = await msg.getSender(); const n = [s.firstName, s.lastName].filter(Boolean).join(" "); if (n) return n; if (s.username) return "@" + s.username; } catch {}
  return "Pemain " + (senderId || "").toString().slice(-4);
}
function wrap(t) { return `<blockquote>${t}</blockquote>`; }

// ── DATA BANK ──
const IBUKOTA = [["Indonesia", "jakarta"], ["Jepang", "tokyo"], ["Inggris", "london"], ["Prancis", "paris"], ["Mesir", "kairo"], ["Korea Selatan", "seoul"], ["Thailand", "bangkok"], ["Australia", "canberra"], ["Italia", "roma"], ["Spanyol", "madrid"]];
const BENDERA = [["🇮🇩", "indonesia"], ["🇯🇵", "jepang"], ["🇰🇷", "korea selatan"], ["🇧🇷", "brazil"], ["🇩🇪", "jerman"], ["🇫🇷", "prancis"], ["🇮🇹", "italia"], ["🇬🇧", "inggris"], ["🇪🇸", "spanyol"], ["🇨🇳", "china"]];
const HEWAN = [["🦁", "singa"], ["🐘", "gajah"], ["🐯", "harimau"], ["🦒", "jerapah"], ["🐊", "buaya"], ["🦍", "gorila"], ["🦘", "kanguru"], ["🦨", "sigung"], ["🦅", "elang"], ["🐬", "lumba lumba"]];
const BUAH = [["🍎", "apel"], ["🍌", "pisang"], ["🍇", "anggur"], ["🍉", "semangka"], ["🍓", "stroberi"], ["🍍", "nanas"], ["🥭", "mangga"], ["🍑", "persik"], ["🍒", "ceri"], ["🥥", "kelapa"]];
const WARNA = [["🟥", "merah"], ["🟦", "biru"], ["🟩", "hijau"], ["🟨", "kuning"], ["🟧", "oranye"], ["🟪", "ungu"], ["⬛", "hitam"], ["⬜", "putih"], ["🟫", "coklat"]];
const EMOJI = [["✈️🌍", "liburan"], ["🍿🎬", "bioskop"], ["📚✏️", "belajar"], ["⚽🥅", "sepak bola"], ["🌧️☂️", "hujan"], ["🎂🎉", "ulang tahun"], ["🛏️😴", "tidur"], ["🍳🥓", "sarapan"], ["💰🏦", "bank"], ["🚑🏥", "rumah sakit"]];
const TEKATEKI = [["Punya gigi tapi tak bisa menggigit, apakah itu?", "sisir"], ["Semakin diisi semakin ringan, apakah itu?", "balon"], ["Naik turun tak pernah lelah, apakah itu?", "tangga"], ["Punya jarum tapi tak bisa menjahit, apakah itu?", "jam"], ["Kalau dipukul makin keras, makin nyaring bunyinya, apakah itu?", "kentongan"], ["Punya kaki empat tapi tak bisa jalan, apakah itu?", "meja"], ["Hitam saat dibeli, merah saat dipakai, abu saat dibuang, apakah itu?", "arang"]];
const PERIBAHASA = [["Ada gula ada", "semut"], ["Sedia payung sebelum", "hujan"], ["Bagai air di daun", "talas"], ["Tong kosong nyaring", "bunyinya"], ["Berakit-rakit ke", "hulu"], ["Air susu dibalas air", "tuba"], ["Sambil menyelam minum", "air"], ["Besar pasak daripada", "tiang"]];
const SINONIM = [["pintar", ["pandai", "cerdas", "cerdik"]], ["besar", ["gede", "raksasa"]], ["cantik", ["elok", "ayu", "rupawan"]], ["cepat", ["kilat", "gesit", "laju"]], ["senang", ["bahagia", "gembira", "riang"]], ["kuat", ["perkasa", "tangguh"]]];
const LAWANKATA = [["besar", "kecil"], ["tinggi", "rendah"], ["cepat", "lambat"], ["panas", "dingin"], ["terang", "gelap"], ["berat", "ringan"], ["jauh", "dekat"], ["tua", "muda"], ["mahal", "murah"], ["kaya", "miskin"]];
const PROFESI = [["Mengajar murid di sekolah", "guru"], ["Mengobati pasien sakit", "dokter"], ["Memadamkan kebakaran", "pemadam kebakaran"], ["Menerbangkan pesawat", "pilot"], ["Menangkap penjahat", "polisi"], ["Memasak di restoran", "koki"], ["Membela perkara di pengadilan", "pengacara"], ["Memotong rambut", "tukang cukur"]];
const KOTA = [["Kota kembang", "bandung"], ["Kota pahlawan", "surabaya"], ["Kota gudeg", "yogyakarta"], ["Kota hujan", "bogor"], ["Kota apel", "malang"], ["Kota seribu sungai", "banjarmasin"], ["Kota udang", "cirebon"]];
const SAINS = [["Planet terdekat dengan matahari?", "merkurius"], ["Gas yang dihirup manusia untuk bernapas?", "oksigen"], ["Berapa jumlah kaki laba-laba?", "8"], ["Organ tubuh untuk memompa darah?", "jantung"], ["Rumus kimia air?", "h2o"], ["Bagian tumbuhan tempat fotosintesis?", "daun"], ["Hewan mamalia yang bisa terbang?", "kelelawar"]];
const SEJARAH = [["Tahun kemerdekaan Indonesia?", "1945"], ["Presiden pertama Indonesia?", "soekarno"], ["Proklamator selain Soekarno?", "hatta"], ["Kerajaan Hindu-Buddha terbesar di Nusantara?", "majapahit"], ["Tanggal Sumpah Pemuda?", "28 oktober"], ["Pahlawan dari Aceh berjuluk wanita pemberani?", "cut nyak dien"]];
const GEOGRAFI = [["Gunung tertinggi di dunia?", "everest"], ["Benua terbesar?", "asia"], ["Samudra terluas?", "pasifik"], ["Negara terluas di dunia?", "rusia"], ["Sungai terpanjang di dunia?", "nil"], ["Gurun terluas di dunia?", "sahara"], ["Pulau terbesar di Indonesia?", "kalimantan"]];
const KUIS = [["Ibukota Indonesia?", "jakarta"], ["1 lusin sama dengan berapa?", "12"], ["Warna campuran biru dan kuning?", "hijau"], ["Hewan berkantung dari Australia?", "kanguru"], ["Alat untuk melihat benda jauh?", "teropong"], ["Berapa hari dalam seminggu?", "7"], ["Mata uang Jepang?", "yen"]];
const SCRAMBLE_WORDS = ["kucing", "matahari", "komputer", "sepatu", "jendela", "pelangi", "gunung", "sekolah", "telepon", "kemerdekaan", "semangka", "harimau"];
const KETIK_PHRASES = ["aku suka main game", "hari ini cuaca cerah", "ayo kita menang", "kerja keras pasti hasil", "jangan menyerah kawan", "kopi pagi paling enak"];
const PROFESI2 = PROFESI;
const FAMILY = [["Sebutkan buah berwarna merah", ["apel", "stroberi", "semangka", "ceri", "delima"]], ["Sebutkan hewan berkaki empat", ["kucing", "anjing", "sapi", "kambing", "kuda", "gajah"]], ["Sebutkan warna pelangi", ["merah", "jingga", "kuning", "hijau", "biru", "nila", "ungu"]], ["Sebutkan alat transportasi darat", ["mobil", "motor", "bus", "kereta", "sepeda", "becak"]]];
const GOMBAL = ["Kamu tau bedanya kamu sama bintang? Bintang di langit, kamu di hatiku.", "Kalau kamu jadi wifi, aku mau connect terus.", "Aku bukan fotografer, tapi aku bisa bayangin kita bareng.", "Kamu capek nggak? Soalnya dari tadi muter terus di pikiranku.", "Aku mau jadi matematika, biar bisa nambahin kebahagiaanmu."];
const MOTIVASI = ["Sekecil apa pun langkahmu, itu tetap kemajuan.", "Gagal cuma cara semesta bilang: coba lagi dengan cara beda.", "Kamu nggak harus hebat untuk mulai, tapi harus mulai untuk jadi hebat.", "Istirahat boleh, menyerah jangan.", "Hari sulit nggak akan bertahan, tapi orang kuat akan."];
const FAKTA = ["Madu nggak pernah basi, bisa awet ribuan tahun.", "Jantung udang ada di kepalanya.", "Gurita punya tiga jantung.", "Pisang secara botani termasuk buah beri.", "Manusia dan jerapah sama-sama punya 7 ruas tulang leher."];
const RAMAL = ["Hari ini rezekimu datang dari arah tak terduga.", "Seseorang dari masa lalu bakal menghubungimu.", "Sabar hari ini, besok membawa kabar baik.", "Jangan ambil keputusan besar sebelum makan dulu.", "Keberuntunganmu ada di angka 7 hari ini."];

// ════════════════ GAME INDIVIDU (ONE-SHOT) ════════════════
function oneShot(handler) { return async (event, args, ctx) => { try { await handler(event, args, ctx); } catch (e) {} }; }

const commands = [];

commands.push({ name: "dadu", description: "Lempar dadu 🎲", category: "Game", handler: oneShot(async (e) => _fmt.reply(e, wrap(`🎲 Dadu keluar: <b>${rint(1, 6)}</b>`))) });
commands.push({ name: "dadukembar", description: "Lempar 2 dadu", category: "Game", handler: oneShot(async (e) => { const a = rint(1, 6), b = rint(1, 6); _fmt.reply(e, wrap(`🎲🎲 <b>${a}</b> & <b>${b}</b> = <b>${a + b}</b>${a === b ? " — KEMBAR! 🎉" : ""}`)); }) });
commands.push({ name: "koin", description: "Lempar koin (angka/gambar)", category: "Game", handler: oneShot(async (e) => _fmt.reply(e, wrap(`🪙 ${pick(["ANGKA", "GAMBAR"])}!`))) });
commands.push({ name: "suit", description: "Suit lawan bot: .suit batu/gunting/kertas", category: "Game", handler: oneShot(async (e, a) => { const me = norm(a[0] || ""); const opt = ["batu", "gunting", "kertas"]; if (!opt.includes(me)) return _fmt.reply(e, "❌ Pilih: batu / gunting / kertas"); const bot = pick(opt); const win = { batu: "gunting", gunting: "kertas", kertas: "batu" }; let r = me === bot ? "SERI 🤝" : (win[me] === bot ? "KAMU MENANG 🎉" : "KAMU KALAH 😅"); _fmt.reply(e, wrap(`✊ Kamu: <b>${me}</b>\n🤖 Bot: <b>${bot}</b>\n\n<b>${r}</b>`)); }) });
commands.push({ name: "bola8", description: "Tanya bola ajaib: .bola8 <pertanyaan>", category: "Game", handler: oneShot(async (e, a) => { if (!a.length) return _fmt.reply(e, "❌ Format: .bola8 <pertanyaan>"); const ans = ["Iya, pasti!", "Sepertinya tidak.", "Coba tanya lagi nanti.", "Tentu saja.", "Jangan harap.", "Mungkin iya.", "Tidak sekarang.", "Sudah pasti!"]; _fmt.reply(e, wrap(`🎱 ${pick(ans)}`)); }) });
commands.push({ name: "kartu", description: "Tarik kartu remi acak", category: "Game", handler: oneShot(async (e) => { const v = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]; const s = ["♠️", "♥️", "♦️", "♣️"]; _fmt.reply(e, wrap(`🃏 Kamu menarik: <b>${pick(v)}${pick(s)}</b>`)); }) });
commands.push({ name: "ramal", description: "Ramalan iseng hari ini", category: "Game", handler: oneShot(async (e) => _fmt.reply(e, wrap(`🔮 ${pick(RAMAL)}`))) });
commands.push({ name: "pilihin", description: "Bot pilihin: .pilihin a,b,c", category: "Game", handler: oneShot(async (e, a) => { const opt = a.join(" ").split(",").map(s => s.trim()).filter(Boolean); if (opt.length < 2) return _fmt.reply(e, "❌ Format: .pilihin nasi,mie,roti"); _fmt.reply(e, wrap(`🤔 Aku pilih: <b>${esc(pick(opt))}</b>`)); }) });
commands.push({ name: "gombal", description: "Gombalan acak", category: "Game", handler: oneShot(async (e) => _fmt.reply(e, wrap(`😏 ${esc(pick(GOMBAL))}`))) });
commands.push({ name: "faktaunik", description: "Fakta unik acak", category: "Game", handler: oneShot(async (e) => _fmt.reply(e, wrap(`💡 ${esc(pick(FAKTA))}`))) });
commands.push({ name: "motivasi", description: "Kata motivasi acak", category: "Game", handler: oneShot(async (e) => _fmt.reply(e, wrap(`🔥 ${esc(pick(MOTIVASI))}`))) });
commands.push({ name: "undian", description: "Tarik undian keberuntungan 🎟️", category: "Game", handler: oneShot(async (e) => { const tk = String(rint(0, 9999)).padStart(4, "0"); const wn = String(rint(0, 9999)).padStart(4, "0"); _fmt.reply(e, wrap(`🎟️ Tiket kamu: <b>${tk}</b>\n🏆 Nomor menang: <b>${wn}</b>\n\n${tk === wn ? "🎉 JACKPOT GILA!" : tk.slice(0, 2) === wn.slice(0, 2) ? "😮 Nyaris! dapet hadiah hiburan." : "😅 Belum hoki, coba lagi."}`)); }) });
commands.push({ name: "kocokdadu", description: "Kocok 5 dadu sekaligus", category: "Game", handler: oneShot(async (e) => { const r = [0, 0, 0, 0, 0].map(() => rint(1, 6)); const sum = r.reduce((a, b) => a + b, 0); const faces = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]; _fmt.reply(e, wrap(`🎲 ${r.map(x => faces[x - 1]).join(" ")}\nTotal: <b>${sum}</b>`)); }) });
commands.push({ name: "rolet", description: "Russian roulette iseng (1/6)", category: "Game", handler: oneShot(async (e) => { const dor = rint(1, 6) === 1; _fmt.reply(e, wrap(dor ? `🔫💥 <b>DOR!</b> Kamu kalah 😵` : `🔫 ...klik. <b>Selamat, kamu aman!</b> 😮‍💨`)); }) });
commands.push({ name: "balapan", description: "Balapan emoji acak 🏁", category: "Game", handler: oneShot(async (e) => { const racers = ["🐎", "🐢", "🐇", "🐌"]; const win = pick(racers); _fmt.reply(e, wrap(`🏁 <b>BALAPAN!</b>\n${racers.map(r => r + " " + (r === win ? "════🏆" : "──")).join("\n")}\n\nPemenang: <b>${win}</b>`)); }) });
commands.push({ name: "tebakkartu", description: "Hi-Lo: kartu kamu vs bot", category: "Game", handler: oneShot(async (e) => { const v = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]; const s = ["♠️", "♥️", "♦️", "♣️"]; const a = rint(0, 12), b = rint(0, 12); const r = a === b ? "SERI 🤝" : a > b ? "KAMU MENANG 🎉" : "KAMU KALAH 😅"; _fmt.reply(e, wrap(`🃏 Kamu: <b>${v[a]}${pick(s)}</b>\n🤖 Bot: <b>${v[b]}${pick(s)}</b>\n\n<b>${r}</b>`)); }) });

// ════════════════ GAME INDIVIDU (STATEFUL) ════════════════
function soloKeyOf(ctx, msg) { return ctx.ownerId + ":" + chatIdOf(msg); }

// generator soal sederhana → {prompt, check(ans)->bool, answer}
function makeQA(prompt, accepts) {
  const list = (Array.isArray(accepts) ? accepts : [accepts]).map(norm);
  return { prompt, answers: list, answer: (Array.isArray(accepts) ? accepts[0] : accepts) };
}
function genMath() { const a = rint(2, 20), b = rint(2, 20), op = pick(["+", "-", "×"]); let r = op === "+" ? a + b : op === "-" ? a - b : a * b; return makeQA(`Berapa <b>${a} ${op} ${b}</b>?`, String(r)); }
function genBank(bank, fmt) { const it = pick(bank); return fmt(it); }

const SOLO_DEF = {
  matematika: { label: "🧮 Matematika", gen: genMath },
  hitungcepat: { label: "⚡ Hitung Cepat", gen: genMath },
  kuis: { label: "❓ Kuis Umum", gen: () => { const x = pick(KUIS); return makeQA(x[0], x[1]); } },
  sains: { label: "🔬 Kuis Sains", gen: () => { const x = pick(SAINS); return makeQA(x[0], x[1]); } },
  sejarah: { label: "📜 Kuis Sejarah", gen: () => { const x = pick(SEJARAH); return makeQA(x[0], x[1]); } },
  geografi: { label: "🌍 Kuis Geografi", gen: () => { const x = pick(GEOGRAFI); return makeQA(x[0], x[1]); } },
  tebakbendera: { label: "🚩 Tebak Bendera", gen: () => { const x = pick(BENDERA); return makeQA(`Bendera negara apa? ${x[0]}`, x[1]); } },
  tebakibukota: { label: "🏛️ Tebak Ibukota", gen: () => { const x = pick(IBUKOTA); return makeQA(`Ibukota <b>${x[0]}</b>?`, x[1]); } },
  tebakemoji: { label: "🧩 Tebak Emoji", gen: () => { const x = pick(EMOJI); return makeQA(`Tebak dari emoji: ${x[0]}`, x[1]); } },
  tebakhewan: { label: "🐾 Tebak Hewan", gen: () => { const x = pick(HEWAN); return makeQA(`Hewan apa? ${x[0]}`, x[1]); } },
  tebakbuah: { label: "🍉 Tebak Buah", gen: () => { const x = pick(BUAH); return makeQA(`Buah apa? ${x[0]}`, x[1]); } },
  tebakwarna: { label: "🎨 Tebak Warna", gen: () => { const x = pick(WARNA); return makeQA(`Warna apa? ${x[0]}`, x[1]); } },
  tekateki: { label: "🤔 Teka-teki", gen: () => { const x = pick(TEKATEKI); return makeQA(x[0], x[1]); } },
  peribahasa: { label: "📖 Lengkapi Peribahasa", gen: () => { const x = pick(PERIBAHASA); return makeQA(`"${x[0]} ___" — lanjutkan!`, x[1]); } },
  tebaksinonim: { label: "🔤 Sinonim", gen: () => { const x = pick(SINONIM); return makeQA(`Sinonim dari <b>${x[0]}</b>?`, x[1]); } },
  tebaklawankata: { label: "↔️ Lawan Kata", gen: () => { const x = pick(LAWANKATA); return makeQA(`Lawan kata <b>${x[0]}</b>?`, x[1]); } },
  tebakprofesi: { label: "💼 Tebak Profesi", gen: () => { const x = pick(PROFESI); return makeQA(x[0] + "?", x[1]); } },
  tebakkota: { label: "🏙️ Tebak Kota", gen: () => { const x = pick(KOTA); return makeQA(`Kota apa: "${x[0]}"?`, x[1]); } },
  acakkata: { label: "🔀 Acak Kata", gen: () => { const w = pick(SCRAMBLE_WORDS); return makeQA(`Susun jadi kata: <b>${scramble(w).toUpperCase()}</b>`, w); } },
  ketikcepat: { label: "⌨️ Ketik Cepat", gen: () => { const p = pick(KETIK_PHRASES); return makeQA(`Ketik ulang persis:\n<b>${p}</b>`, p); } },
  sandi: { label: "🔐 Pecahkan Sandi", gen: () => { const w = pick(SCRAMBLE_WORDS); const k = rint(1, 5); const enc = w.replace(/[a-z]/g, c => String.fromCharCode((c.charCodeAt(0) - 97 + k) % 26 + 97)); return makeQA(`Sandi geser ${k}: <b>${enc.toUpperCase()}</b>\n(pecahkan jadi kata asli)`, w); } },
};

function startSolo(type) {
  const def = SOLO_DEF[type];
  return async (event, args, ctx) => {
    const msg = event.message;
    const key = soloKeyOf(ctx, msg);
    const qa = def.gen();
    soloGames.set(key, { type, qa, tries: 0, ts: Date.now() });
    await gsend(ctx.client, msg.peerId, wrap(`${def.label}\n\n${qa.prompt}\n\n<i>Jawab langsung (tanpa ${ctx.prefix}). Ketik nyerah buat skip.</i>`));
  };
}
for (const t of Object.keys(SOLO_DEF)) {
  commands.push({ name: t, description: SOLO_DEF[t].label.replace(/^[^ ]+ /, "") + " (game)", category: "Game", handler: startSolo(t) });
}

// tebakangka (khusus: higher/lower)
commands.push({
  name: "tebakangka", description: "Tebak angka 1-100 (game)", category: "Game",
  handler: async (event, args, ctx) => {
    const msg = event.message; const key = soloKeyOf(ctx, msg);
    soloGames.set(key, { type: "tebakangka", target: rint(1, 100), tries: 0, ts: Date.now() });
    await gsend(ctx.client, msg.peerId, wrap(`🔢 <b>Tebak Angka</b>\n\nAku mikirin angka <b>1–100</b>. Tebak (ketik angka langsung)!\nKetik nyerah buat nyerah.`));
  },
});
// tebakkata (hangman)
commands.push({
  name: "tebakkata", description: "Tebak kata (hangman) (game)", category: "Game",
  handler: async (event, args, ctx) => {
    const msg = event.message; const key = soloKeyOf(ctx, msg);
    const w = pick(SCRAMBLE_WORDS);
    soloGames.set(key, { type: "tebakkata", word: w, revealed: new Set(), wrong: new Set(), lives: 6, ts: Date.now() });
    const shown = w.split("").map(() => "_").join(" ");
    await gsend(ctx.client, msg.peerId, wrap(`🔡 <b>Tebak Kata</b>\n\n<code>${shown}</code>\n(${w.length} huruf)\n\nTebak <b>huruf</b> atau langsung kata utuh. Nyawa: ❤️×6\nKetik nyerah buat nyerah.`));
  },
});

// proses jawaban game individu
async function soloEnd(c, type, html) {
  soloGames.delete(c.soloKey);
  lastGame.set(c.soloKey, { kind: "solo", type });
  const p = prefOf(c.ownerId);
  await gsend(c.client, c.peer, wrap(`${html}\n\n🔁 Main lagi? ketik <b>${p}lagi</b> — atau <b>${p}stop</b> buat berhenti.`));
}
async function handleSoloMessage(sg, c) {
  const ans = norm(c.text);
  if (ans === "nyerah" || ans === "menyerah") {
    let jwb = sg.qa ? sg.qa.answer : (sg.word || sg.target);
    await soloEnd(c, sg.type, `🏳️ Nyerah! Jawabannya: <b>${esc(String(jwb))}</b>`);
    return true;
  }
  if (sg.type === "tebakangka") {
    const g = parseInt(c.text); if (isNaN(g)) return false;
    sg.tries++;
    if (g === sg.target) await soloEnd(c, sg.type, `🎉 <b>BENAR!</b> Angkanya <b>${sg.target}</b>. Tebakan ke-${sg.tries}.`);
    else await gsend(c.client, c.peer, wrap(g < sg.target ? `📈 Lebih <b>BESAR</b> dari ${g}` : `📉 Lebih <b>KECIL</b> dari ${g}`));
    return true;
  }
  if (sg.type === "tebakkata") {
    const t = ans.replace(/\s/g, "");
    if (t.length > 1) { // tebak kata utuh
      if (t === sg.word) await soloEnd(c, sg.type, `🎉 <b>BENAR!</b> Katanya <b>${sg.word}</b>`);
      else { sg.lives--; if (sg.lives <= 0) await soloEnd(c, sg.type, `💀 Habis nyawa! Katanya <b>${sg.word}</b>`); else await gsend(c.client, c.peer, wrap(`❌ Salah. Nyawa: ❤️×${sg.lives}`)); }
      return true;
    }
    if (t.length === 1) { // tebak huruf
      if (sg.word.includes(t)) { sg.revealed.add(t); }
      else { sg.wrong.add(t); sg.lives--; }
      const shown = sg.word.split("").map(ch => sg.revealed.has(ch) ? ch : "_").join(" ");
      if (!shown.includes("_")) await soloEnd(c, sg.type, `🎉 <b>BENAR!</b> <code>${shown}</code>`);
      else if (sg.lives <= 0) await soloEnd(c, sg.type, `💀 Habis nyawa! Katanya <b>${sg.word}</b>`);
      else await gsend(c.client, c.peer, wrap(`<code>${shown}</code>\nNyawa: ❤️×${sg.lives} | Salah: ${[...sg.wrong].join(",") || "-"}`));
      return true;
    }
    return false;
  }
  // tipe QA biasa
  if (sg.qa) {
    if (sg.qa.answers.includes(ans)) await soloEnd(c, sg.type, `✅ <b>BENAR!</b> 🎉`);
    else { sg.tries++; if (sg.tries >= 3) await soloEnd(c, sg.type, `❌ Yah, 3x salah. Jawabannya: <b>${esc(sg.qa.answer)}</b>`); else await gsend(c.client, c.peer, wrap(`❌ Salah, coba lagi (${3 - sg.tries} kesempatan).`)); }
    return true;
  }
  return false;
}

// ════════════════ GAME PARTY (LOBBY) ════════════════
const PARTY_DEF = {
  sambungkata: { label: "🔗 Sambung Kata", min: 2 },
  family100: { label: "💯 Family 100", min: 1 },
  cepatketik: { label: "⌨️ Ketik Tercepat", min: 2 },
  kuisrame: { label: "❓ Kuis Rame", min: 2 },
  cerdascermat: { label: "🧠 Cerdas Cermat", min: 2 },
  tebakangkarame: { label: "🔢 Tebak Angka Rame", min: 2 },
  suitrame: { label: "✊ Suit Rame", min: 1 },
  tod: { label: "🎭 Truth or Dare", min: 2 },
  tebakgambarrame: { label: "🧩 Tebak Emoji Rame", min: 2 },
  acakkatarame: { label: "🔀 Acak Kata Rame", min: 2 },
};

function startParty(type) {
  const def = PARTY_DEF[type];
  return async (event, args, ctx) => {
    const msg = event.message; const peer = msg.peerId;
    const chatKey = ctx.ownerId + ":" + chatIdOf(msg);
    const exist = lobbies.get(chatKey);
    if (exist) return _fmt.reply(event, `⚠️ Masih ada game <b>${esc(exist.label)}</b> di sini. Ketik <code>${ctx.prefix}batal</code> dulu buat gajadi.`);
    const lobby = { type, label: def.label, min: def.min, prefix: ctx.prefix, host: ctx.ownerId, players: new Map(), status: "lobby", data: {}, peer, client: ctx.client, chatKey, botTimer: null, hasBot: false, roundToken: 0 };
    // Host otomatis jadi pemain #1
    let hostName = "Host";
    try { const me = await ctx.client.getMe(); hostName = [me.firstName, me.lastName].filter(Boolean).join(" ") || "Host"; } catch {}
    lobby.players.set(ctx.ownerId, { name: hostName, score: 0, isHost: true });
    lobbies.set(chatKey, lobby);
    lobby.timer = setTimeout(() => { if (lobbies.get(chatKey) === lobby && lobby.status === "lobby") { lobbies.delete(chatKey); gsend(ctx.client, peer, wrap(`⌛ Lobby <b>${esc(def.label)}</b> dibatalin otomatis (ga ada yang ${ctx.prefix}mulai).`)); } }, 120000);
    await gsend(ctx.client, peer, wrap(
      `🎮 <b>${esc(def.label)}</b> dibuka oleh <b>${esc(hostName)}</b>!\n\n` +
      `Yang mau ikut ketik <b>Bergabung</b> 👇\n` +
      `Minimal <b>${def.min}</b> pemain. Kalau kurang, <b>🤖 Bot</b> bakal ikut biar tetep seru.\n\n` +
      `Host ketik <code>${ctx.prefix}mulai</code> kalau udah siap, atau <code>${ctx.prefix}batal</code> buat gajadi.`));
  };
}
for (const t of Object.keys(PARTY_DEF)) {
  commands.push({ name: t, description: PARTY_DEF[t].label.replace(/^[^ ]+ /, "") + " (party)", category: "Game", handler: startParty(t) });
}

function scoreboard(lobby) {
  const arr = [...lobby.players.values()].sort((a, b) => b.score - a.score);
  return arr.map((p, i) => `${["🥇", "🥈", "🥉"][i] || "▫️"} ${esc(p.name)} — <b>${p.score}</b>`).join("\n");
}
async function finishParty(lobby, chatKey, title) {
  if (lobby.timer) clearTimeout(lobby.timer);
  clearBotTimer(lobby);
  lobbies.delete(chatKey);
  lastGame.set(chatKey, { kind: "party", type: lobby.type });
  const p = lobby.prefix || ".";
  await gsend(lobby.client, lobby.peer, wrap(
    `🏁 <b>${title || lobby.label + " selesai"}</b>\n\n${scoreboard(lobby) || "—"}\n\n` +
    `🔁 Main lagi? ketik <b>${p}lagi</b> (peserta join ulang ketik <b>Bergabung</b>) — atau <b>${p}stop</b> buat berhenti.`));
}

// init tiap game saat .mulai
async function partyInit(lobby, chatKey) {
  lobby.status = "playing";
  if (lobby.timer) clearTimeout(lobby.timer);
  // Isi bot kalau pemain manusia kurang dari minimal
  const humans = [...lobby.players.values()].filter(p => !p.isBot).length;
  if (humans < lobby.min) {
    const need = lobby.min - humans;
    for (let i = 1; i <= need; i++) lobby.players.set("bot" + i, { name: need > 1 ? "🤖 Bot " + i : "🤖 Bot", score: 0, isBot: true });
    lobby.hasBot = true;
    await gsend(lobby.client, lobby.peer, wrap(`🤖 Pemain kurang, <b>Bot</b> ikutan main biar tetep seru!`));
  }
  const d = lobby.data;
  if (["kuisrame", "cerdascermat", "tebakgambarrame", "acakkatarame", "cepatketik"].includes(lobby.type)) {
    d.round = 0; d.max = 5; d.current = null;
    return nextRace(lobby, chatKey);
  }
  if (lobby.type === "sambungkata") {
    d.last = null; d.used = new Set();
    await gsend(lobby.client, lobby.peer, wrap(`🔗 <b>Sambung Kata mulai!</b>\nSebut kata bebas (min 3 huruf). Pemain lain lanjut pakai huruf terakhir. Skor +1 tiap kata valid.\nKetik <code>${lobby.prefix}stopgame</code> buat selesai.`));
    if (lobby.hasBot) scheduleBot(lobby, chatKey);
    return;
  }
  if (lobby.type === "family100") {
    const x = pick(FAMILY); d.q = x[0]; d.remain = new Set(x[1].map(norm)); d.total = x[1].length;
    await gsend(lobby.client, lobby.peer, wrap(`💯 <b>${esc(d.q)}</b>\nAda <b>${d.total}</b> jawaban. Sebutin! (+1 tiap jawaban benar)\n<code>${lobby.prefix}stopgame</code> buat selesai.`));
    if (lobby.hasBot) scheduleBot(lobby, chatKey);
    return;
  }
  if (lobby.type === "tebakangkarame") {
    d.target = rint(1, 100); d.botLo = 1; d.botHi = 100;
    await gsend(lobby.client, lobby.peer, wrap(`🔢 <b>Tebak Angka Rame!</b>\nAku mikirin <b>1–100</b>. Siapa cepat tebak tepat, menang!`));
    if (lobby.hasBot) scheduleBot(lobby, chatKey);
    return;
  }
  if (lobby.type === "suitrame") { return gsend(lobby.client, lobby.peer, wrap(`✊ <b>Suit Rame!</b>\nKetik <b>batu</b>/<b>gunting</b>/<b>kertas</b>. Tiap kali ngalahin bot = +1.\n<code>${lobby.prefix}stopgame</code> buat selesai (liat skor).`)); }
  if (lobby.type === "tod") { return todNext(lobby, chatKey); }
}
function nextRace(lobby, chatKey) {
  const d = lobby.data; clearBotTimer(lobby); d.round++; lobby.roundToken++;
  if (d.round > d.max) return finishParty(lobby, chatKey, lobby.label + " selesai!");
  if (lobby.type === "kuisrame") { const x = pick(KUIS); d.current = makeQA(x[0], x[1]); }
  else if (lobby.type === "cerdascermat") { const bank = pick([KUIS, SAINS, SEJARAH, GEOGRAFI]); const x = pick(bank); d.current = makeQA(x[0], x[1]); }
  else if (lobby.type === "tebakgambarrame") { const x = pick(EMOJI); d.current = makeQA(`Tebak: ${x[0]}`, x[1]); }
  else if (lobby.type === "acakkatarame") { const w = pick(SCRAMBLE_WORDS); d.current = makeQA(`Susun: <b>${scramble(w).toUpperCase()}</b>`, w); }
  else if (lobby.type === "cepatketik") { const p = pick(KETIK_PHRASES); d.current = makeQA(`Ketik persis: <b>${p}</b>`, p); }
  const out = gsend(lobby.client, lobby.peer, wrap(`Soal <b>${d.round}/${d.max}</b>\n${d.current.prompt}`));
  if (lobby.hasBot) scheduleBot(lobby, chatKey);
  return out;
}
function todNext(lobby, chatKey) {
  clearBotTimer(lobby);
  const ids = [...lobby.players.keys()]; const id = pick(ids); lobby.data.cur = id;
  const p = lobby.players.get(id);
  const truths = ["Apa hal paling memalukan yang pernah kamu alami?", "Siapa orang yang diam-diam kamu kagumi?", "Apa kebiasaan burukmu?"];
  const dares = ["Kirim stiker paling lucu di hp kamu.", "Ketik 'aku paling ganteng/cantik sedunia'.", "Voice note nyanyi 1 bait lagu."];
  const isT = Math.random() < 0.5;
  const out = gsend(lobby.client, lobby.peer, wrap(`🎭 Giliran <b>${esc(p.name)}</b>!\n<b>${isT ? "TRUTH" : "DARE"}:</b> ${isT ? pick(truths) : pick(dares)}\n\n<i>Jawab/lakuin, terus kirim apa aja buat lanjut ke pemain berikutnya. (<code>${lobby.prefix}stopgame</code> buat selesai)</i>`));
  // Kalau yang kena giliran si Bot → auto lanjut setelah beberapa detik
  if (p.isBot) {
    lobby.botTimer = setTimeout(async () => {
      try { if (lobbies.get(chatKey) === lobby && lobby.status === "playing") { await gsend(lobby.client, lobby.peer, wrap(`<b>${esc(p.name)}</b> udah ngelakuin tantangannya 😎`)); await todNext(lobby, chatKey); } } catch {}
    }, rint(5, 8) * 1000);
  }
  return out;
}

// ── MESIN BOT (lawan kalau pemain kurang) ──
const WORD_BANK = ["api", "ayam", "angin", "apel", "batu", "buku", "bola", "cinta", "coklat", "duku", "durian", "emas", "elang", "gula", "gajah", "hari", "hujan", "ikan", "istana", "jeruk", "jendela", "kaki", "kuda", "kucing", "lampu", "lemari", "meja", "mawar", "nasi", "naga", "obat", "ombak", "pintu", "pisang", "roti", "rumah", "sapu", "singa", "tas", "tikus", "ubi", "ungu", "vas", "warna", "wortel", "yoyo", "zebra", ...SCRAMBLE_WORDS];
function botWordFor(letter, used) { const cand = WORD_BANK.filter(w => w[0] === letter && !used.has(w)); return cand.length ? pick(cand) : null; }
function clearBotTimer(lobby) { if (lobby && lobby.botTimer) { clearTimeout(lobby.botTimer); lobby.botTimer = null; } }
function getBots(lobby) { return [...lobby.players.values()].filter(p => p.isBot); }
function scheduleBot(lobby, chatKey) {
  if (!lobby.hasBot) return;
  clearBotTimer(lobby);
  const token = lobby.roundToken;
  lobby.botTimer = setTimeout(async () => { try { await botAct(lobby, chatKey, token); } catch (e) {} }, rint(6, 12) * 1000);
}
async function botAct(lobby, chatKey, token) {
  if (lobbies.get(chatKey) !== lobby || lobby.status !== "playing" || token !== lobby.roundToken) return;
  const bots = getBots(lobby); if (!bots.length) return;
  const bot = pick(bots); const d = lobby.data;
  if (["kuisrame", "cerdascermat", "tebakgambarrame", "acakkatarame", "cepatketik"].includes(lobby.type)) {
    if (!d.current) return;
    bot.score++;
    await gsend(lobby.client, lobby.peer, wrap(`<b>${esc(bot.name)}</b> jawab duluan: <b>${esc(d.current.answer)}</b> (+1) → skor ${bot.score}`));
    d.current = null;
    return nextRace(lobby, chatKey);
  }
  if (lobby.type === "sambungkata") {
    const w = botWordFor(d.last || pick("abcdeghiklmprstu".split("")), d.used);
    if (!w) { await gsend(lobby.client, lobby.peer, wrap(`${esc(bot.name)} bingung cari kata, giliranmu lagi 😅`)); lobby.roundToken++; return scheduleBot(lobby, chatKey); }
    d.used.add(w); d.last = w[w.length - 1]; bot.score++;
    await gsend(lobby.client, lobby.peer, wrap(`<b>${esc(bot.name)}</b>: <b>${w}</b> (+1)\nLanjut huruf: <b>${d.last.toUpperCase()}</b>`));
    lobby.roundToken++; return scheduleBot(lobby, chatKey);
  }
  if (lobby.type === "family100") {
    if (!d.remain || d.remain.size === 0) return;
    const a = pick([...d.remain]); d.remain.delete(a); bot.score++;
    await gsend(lobby.client, lobby.peer, wrap(`<b>${esc(bot.name)}</b> jawab: <b>${a}</b> (+1). Sisa <b>${d.remain.size}</b>.`));
    if (d.remain.size === 0) return finishParty(lobby, chatKey, "Family 100 — semua kejawab!");
    lobby.roundToken++; return scheduleBot(lobby, chatKey);
  }
  if (lobby.type === "tebakangkarame") {
    if (d.botLo == null) { d.botLo = 1; d.botHi = 100; }
    const g = Math.floor((d.botLo + d.botHi) / 2);
    if (g === d.target) { bot.score++; return finishParty(lobby, chatKey, `🤖 ${bot.name} nebak ${d.target}! Bot menang 😎`); }
    if (g < d.target) d.botLo = g + 1; else d.botHi = g - 1;
    await gsend(lobby.client, lobby.peer, wrap(`<b>${esc(bot.name)}</b> nebak <b>${g}</b>... ${g < d.target ? "katanya kurang gede" : "katanya kurang kecil"}`));
    lobby.roundToken++; return scheduleBot(lobby, chatKey);
  }
  // suitrame & tod: bot ga perlu aksi di sini
}

// proses pesan saat lobby ada
async function handlePartyMessage(lobby, c, chatKey) {
  const joinWords = ["bergabung", "gabung", "join", "ikut"];
  if (lobby.status === "lobby") {
    if (joinWords.includes(norm(c.text))) {
      if (!lobby.players.has(c.senderId)) {
        const nm = await nameOf(c.client, c.senderId, c.msg);
        lobby.players.set(c.senderId, { name: nm, score: 0 });
        await gsend(c.client, c.peer, wrap(`✅ <b>${esc(nm)}</b> bergabung! (${lobby.players.size} pemain)`));
      }
      return true;
    }
    return false;
  }
  // PLAYING
  const d = lobby.data; const ans = norm(c.text);
  const player = lobby.players.get(c.senderId);

  if (["kuisrame", "cerdascermat", "tebakgambarrame", "acakkatarame", "cepatketik"].includes(lobby.type)) {
    if (!d.current || !player) return false;
    if (d.current.answers.includes(ans)) {
      player.score++;
      await gsend(c.client, c.peer, wrap(`✅ <b>${esc(player.name)}</b> benar! (+1) → skor ${player.score}\nJawaban: <b>${esc(d.current.answer)}</b>`));
      d.current = null;
      await nextRace(lobby, chatKey);
      return true;
    }
    return false;
  }
  if (lobby.type === "sambungkata") {
    if (!player) return false;
    const w = ans.replace(/\s/g, "");
    if (w.length < 3) return false;
    if (d.last && w[0] !== d.last) { await gsend(c.client, c.peer, wrap(`❌ Harus mulai huruf <b>${d.last.toUpperCase()}</b>`)); return true; }
    if (d.used.has(w)) { await gsend(c.client, c.peer, wrap(`❌ <b>${w}</b> udah dipakai!`)); return true; }
    d.used.add(w); d.last = w[w.length - 1]; player.score++;
    await gsend(c.client, c.peer, wrap(`✅ <b>${esc(player.name)}</b> +1 (skor ${player.score})\nKata berikutnya mulai huruf: <b>${d.last.toUpperCase()}</b>`));
    if (lobby.hasBot) { lobby.roundToken++; scheduleBot(lobby, chatKey); }
    return true;
  }
  if (lobby.type === "family100") {
    if (!player) return false;
    if (d.remain.has(ans)) {
      d.remain.delete(ans); player.score++;
      const sisa = d.remain.size;
      await gsend(c.client, c.peer, wrap(`✅ <b>${esc(player.name)}</b> +1! "${esc(c.text.trim())}" benar. Sisa <b>${sisa}</b> jawaban.`));
      if (sisa === 0) { await finishParty(lobby, chatKey, "Family 100 — semua jawaban ketemu!"); return true; }
      if (lobby.hasBot) { lobby.roundToken++; scheduleBot(lobby, chatKey); }
      return true;
    }
    return false;
  }
  if (lobby.type === "tebakangkarame") {
    if (!player) return false;
    const g = parseInt(c.text); if (isNaN(g)) return false;
    if (g === d.target) { player.score++; await finishParty(lobby, chatKey, `🎯 ${player.name} menebak ${d.target}! Menang!`); return true; }
    await gsend(c.client, c.peer, wrap(g < d.target ? `📈 ${esc(player.name)}: lebih besar dari ${g}` : `📉 ${esc(player.name)}: lebih kecil dari ${g}`));
    if (lobby.hasBot) { lobby.roundToken++; scheduleBot(lobby, chatKey); }
    return true;
  }
  if (lobby.type === "suitrame") {
    if (!player) return false;
    const opt = ["batu", "gunting", "kertas"]; if (!opt.includes(ans)) return false;
    const bot = pick(opt); const win = { batu: "gunting", gunting: "kertas", kertas: "batu" };
    let r; if (ans === bot) r = "seri"; else if (win[ans] === bot) { r = "menang"; player.score++; } else r = "kalah";
    await gsend(c.client, c.peer, wrap(`✊ <b>${esc(player.name)}</b>: ${ans} vs bot ${bot} → <b>${r}</b> (skor ${player.score})`));
    return true;
  }
  if (lobby.type === "tod") {
    if (c.senderId !== d.cur) return false;
    await todNext(lobby, chatKey);
    return true;
  }
  return false;
}

// ── KONTROL LOBBY (commands) ──
function lobbyOf(ctx, msg) { return lobbies.get(ctx.ownerId + ":" + chatIdOf(msg)); }
function keyOf(ctx, msg) { return ctx.ownerId + ":" + chatIdOf(msg); }

commands.push({
  name: "mulai", description: "Mulai game party yang dibuka (host)", category: "Game",
  handler: async (event, args, ctx) => {
    const msg = event.message; const lobby = lobbyOf(ctx, msg); const chatKey = keyOf(ctx, msg);
    if (!lobby) return _fmt.reply(event, `❌ Belum ada game dibuka. Mulai dgn salah satu game party (mis. <code>${ctx.prefix}kuisrame</code>).`);
    if (lobby.status === "playing") return _fmt.reply(event, "⚠️ Game udah jalan.");
    // Ga ada blok minimal: kalau pemain kurang, Bot otomatis ikut (dihandle partyInit).
    await partyInit(lobby, chatKey);
  },
});
commands.push({
  name: "batal", description: "Batalin game party (gajadi)", category: "Game",
  handler: async (event, args, ctx) => {
    const msg = event.message; const lobby = lobbyOf(ctx, msg); const chatKey = keyOf(ctx, msg);
    if (!lobby) return _fmt.reply(event, "❌ Ga ada game yang lagi dibuka.");
    if (lobby.timer) clearTimeout(lobby.timer);
    lobbies.delete(chatKey);
    await _fmt.reply(event, wrap(`🚫 Game <b>${esc(lobby.label)}</b> dibatalin.`));
  },
});
commands.push({
  name: "pemain", description: "Lihat peserta game party", category: "Game",
  handler: async (event, args, ctx) => {
    const lobby = lobbyOf(ctx, event.message);
    if (!lobby) return _fmt.reply(event, "❌ Ga ada game aktif.");
    const list = [...lobby.players.values()].map((p, i) => `${i + 1}. ${esc(p.name)}`).join("\n") || "(belum ada, ketik Bergabung)";
    await _fmt.reply(event, wrap(`👥 <b>Peserta ${esc(lobby.label)}</b> (${lobby.players.size})\n\n${list}`));
  },
});
commands.push({
  name: "skor", description: "Lihat skor sementara", category: "Game",
  handler: async (event, args, ctx) => {
    const lobby = lobbyOf(ctx, event.message);
    if (!lobby || lobby.status !== "playing") return _fmt.reply(event, "❌ Ga ada game yang lagi jalan.");
    await _fmt.reply(event, wrap(`📊 <b>Skor ${esc(lobby.label)}</b>\n\n${scoreboard(lobby) || "—"}`));
  },
});
commands.push({
  name: "stopgame", description: "Hentikan game party & tampilkan skor", category: "Game",
  handler: async (event, args, ctx) => {
    const msg = event.message; const lobby = lobbyOf(ctx, msg); const chatKey = keyOf(ctx, msg);
    if (!lobby) return _fmt.reply(event, "❌ Ga ada game aktif.");
    await finishParty(lobby, chatKey, lobby.label + " dihentikan");
  },
});
commands.push({
  name: "gamemenu", description: "Daftar semua game", category: "Game",
  handler: async (event, args, ctx) => {
    const p = ctx.prefix;
    const solo1 = "dadu, dadukembar, koin, suit, bola8, kartu, ramal, pilihin, gombal, faktaunik, motivasi, undian, kocokdadu, rolet, balapan, tebakkartu";
    const solo2 = "tebakangka, tebakkata, matematika, hitungcepat, kuis, sains, sejarah, geografi, tebakbendera, tebakibukota, tebakemoji, tebakhewan, tebakbuah, tebakwarna, tekateki, peribahasa, tebaksinonim, tebaklawankata, tebakprofesi, tebakkota, acakkata, ketikcepat, sandi";
    const party = Object.keys(PARTY_DEF).join(", ");
    await _fmt.reply(event, wrap(
      `🎮 <b>MENU GAME</b>\n\n` +
      `🎲 <b>Iseng (instan):</b>\n${solo1}\n\n` +
      `🧠 <b>Tebak/Kuis (sendiri):</b>\n${solo2}\n\n` +
      `👥 <b>Party (grup, join "Bergabung"):</b>\n${party}\n\n` +
      `Kontrol: <code>${p}mulai</code> <code>${p}batal</code> <code>${p}pemain</code> <code>${p}skor</code> <code>${p}stopgame</code> <code>${p}lagi</code> <code>${p}stop</code>`
    ));
  },
});
// Main lagi game terakhir (solo = ulang, party = buka lobby baru, join ulang)
commands.push({
  name: "lagi", description: "Main lagi game terakhir di chat ini", category: "Game",
  handler: async (event, args, ctx) => {
    const key = keyOf(ctx, event.message);
    const lg = lastGame.get(key);
    if (!lg) return _fmt.reply(event, `❌ Belum ada game yang dimainin di sini. Ketik <code>${ctx.prefix}gamemenu</code> buat liat daftar game.`);
    const cmd = commands.find(c => c.name === lg.type);
    if (!cmd) return _fmt.reply(event, "❌ Game-nya ga ketemu.");
    lastGame.delete(key);
    return cmd.handler(event, [], ctx);
  },
});
// Stop / tutup game di chat ini
commands.push({
  name: "stop", description: "Tutup game di chat ini", category: "Game",
  handler: async (event, args, ctx) => {
    const key = keyOf(ctx, event.message);
    const lobby = lobbies.get(key);
    if (lobby) { if (lobby.timer) clearTimeout(lobby.timer); clearBotTimer(lobby); lobbies.delete(key); }
    soloGames.delete(key);
    lastGame.delete(key);
    await _fmt.reply(event, wrap(`🛑 Oke, game ditutup. Sampai jumpa! 👋`));
  },
});

// ════════════════ INTERCEPTOR (dipanggil ubotManager) ════════════════
async function interceptGameMessage(event, ctx) {
  try {
    const msg = event.message;
    if (!msg || !msg.text) return false;
    const cid = chatIdOf(msg);
    if (botMsgIds.has(cid + ":" + msg.id)) return false; // output bot sendiri → abaikan
    const text = msg.text.trim();
    if (!text) return false;
    // skip command (berprefix) — biar command flow yang handle
    let prefix = ".";
    try { prefix = require("./prefixStore").getPrefix(ctx.ownerId); } catch {}
    if (text.startsWith(prefix)) return false;

    const chatKey = ctx.ownerId + ":" + cid;
    const peer = msg.peerId;

    // 1) Party lobby
    const lobby = lobbies.get(chatKey);
    if (lobby) {
      return await handlePartyMessage(lobby, { event, msg, text, senderId: ctx.senderId, peer, client: ctx.client }, chatKey);
    }
    // 2) Game individu (cuma owner)
    if (ctx.isMe) {
      const sg = soloGames.get(chatKey);
      if (sg) return await handleSoloMessage(sg, { event, msg, text, peer, client: ctx.client, soloKey: chatKey });
    }
    return false;
  } catch (e) { return false; }
}

// Tag tiap command game: "individu" atau "party" (buat menu help bertingkat)
const PARTY_NAMES = new Set([...Object.keys(PARTY_DEF), "mulai", "batal", "pemain", "skor", "stopgame", "gamemenu", "lagi", "stop"]);
for (const c of commands) { if (c.category === "Game") c.game = PARTY_NAMES.has(c.name) ? "party" : "individu"; }

module.exports = { commands, interceptGameMessage };
