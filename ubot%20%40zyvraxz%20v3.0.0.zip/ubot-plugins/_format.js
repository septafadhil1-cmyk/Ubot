// ─────────────────────────────────────────
//  Shared formatter — small caps + bold + blockquote
//  Dipakai semua plugin biar gaya konsisten
// ─────────────────────────────────────────

// Mapping huruf normal → small caps unicode (ᴜsᴇʀʙᴏᴛ style)
const SMALLCAPS = {
  a:"ᴀ", b:"ʙ", c:"ᴄ", d:"ᴅ", e:"ᴇ", f:"ꜰ", g:"ɢ", h:"ʜ", i:"ɪ",
  j:"ᴊ", k:"ᴋ", l:"ʟ", m:"ᴍ", n:"ɴ", o:"ᴏ", p:"ᴘ", q:"q", r:"ʀ",
  s:"s", t:"ᴛ", u:"ᴜ", v:"ᴠ", w:"ᴡ", x:"x", y:"ʏ", z:"ᴢ",
};

// Konversi teks ke small caps (cuma huruf a-z; angka/simbol/emoji lewat apa adanya)
function toSmallCaps(str) {
  let out = "";
  for (const ch of str) {
    const lower = ch.toLowerCase();
    out += SMALLCAPS[lower] || ch;
  }
  return out;
}

// Konversi small caps TAPI lewati bagian dalam tag HTML & isi <code>...</code>
// Supaya: teks biasa jadi small caps, tapi nama command (mono) & tag tetap utuh
function styleHtmlWith(html, conv) {
  // Sama seperti styleHtml tapi converter-nya bebas (buat font tema).
  let result = "";
  let i = 0;
  while (i < html.length) {
    if (html.startsWith("<code>", i)) {
      const end = html.indexOf("</code>", i);
      if (end === -1) { result += html.slice(i); break; }
      result += html.slice(i, end + 7);
      i = end + 7;
    } else if (html[i] === "<") {
      const end = html.indexOf(">", i);
      if (end === -1) { result += html.slice(i); break; }
      result += html.slice(i, end + 1);
      i = end + 1;
    } else {
      let next = html.length;
      const lt = html.indexOf("<", i);
      if (lt !== -1) next = lt;
      result += conv(html.slice(i, next));
      i = next;
    }
  }
  return result;
}
function styleHtml(html) {
  return styleHtmlWith(html, toSmallCaps);
}

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// ── PREFIX INJECTION ──
// ubotManager set prefix aktif sebelum tiap handler dipanggil (sinkron, sebelum await).
// Lalu wrap() ganti contoh command "<code>.xxx</code>" jadi prefix yang dipakai user.
let currentPrefix = ".";
function setPrefix(p) { currentPrefix = (p === "" ? "" : (p || ".")); }

// Ganti ".command" jadi "<prefix>command" di dalam contoh <code>
// Hanya kena: <code>. yang diikuti huruf (= contoh command), bukan desimal/URL.
function injectPrefix(html) {
  if (currentPrefix === ".") return html; // default, ga perlu ganti
  // mode no-prefix: buang titik di contoh "<code>.cmd" → "<code>cmd"
  if (currentPrefix === "") return html.replace(/<code>\.([a-zA-Z])/g, `<code>$1`);
  // ganti "<code>." → "<code><prefix>" kalau setelah titik ada huruf
  return html.replace(/<code>\.([a-zA-Z])/g, `<code>${currentPrefix}$1`);
}

// Bungkus: small caps + bold + blockquote, mono tetap di dalam
function wrap(html) {
  return `<blockquote><b>${styleHtml(injectPrefix(html))}</b></blockquote>`;
}

// Reply standar — semua plugin pakai ini
async function reply(event, html) {
  try {
    await event.message.reply({ message: wrap(html), parseMode: "html" });
  } catch {
    await event.message.reply({ message: injectPrefix(html), parseMode: "html" });
  }
}

module.exports = { toSmallCaps, styleHtml, styleHtmlWith, esc, wrap, reply, setPrefix };
