// ─────────────────────────────────────────
//  Plugin: CFD (Chat Flooder / Promosi Massal)
//  .cfd        → FORWARD ke SEMUA kategori (grup + user + channel), ada label "diteruskan"
//  .cfdcopy    → COPY-PASTE ke SEMUA kategori (grup + user + channel), tanpa label
//  .cfdchannel → FORWARD ke CHANNEL siaran doang (tanpa versi copy)
//  .cfdgroup / .cfdcopygroup   → khusus GRUP
//  .cfdusers  / .cfduserscopy  → khusus user/kontak
//  Format: <jumlah> <delay>d <pesan>  (jumlah & delay opsional)
//  .stopcfd  → hentikan CFD
//  CFD HANYA kirim ke target yang TIDAK di-blacklist (.addbl)
// ─────────────────────────────────────────

const _fmt = require("./_format");
const esc = _fmt.esc;

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// State CFD per owner: ownerId → { running: bool }
const cfdState = new Map();
function getCfd(ownerId) {
  if (!cfdState.has(ownerId)) cfdState.set(ownerId, { running: false });
  return cfdState.get(ownerId);
}

// Normalisasi ID: buang prefix -100 (channel/supergroup) atau - (grup) biar konsisten
function normId(id) {
  let s = String(id);
  if (s.startsWith("-100")) return s.slice(4);
  if (s.startsWith("-")) return s.slice(1);
  return s;
}

// Ambil daftar blacklist dari plugin blacklist
function getBlacklist(ownerId) {
  try {
    const bl = require("./blacklist");
    return bl.getOwnerBL ? bl.getOwnerBL(ownerId) : {};
  } catch {
    return {};
  }
}

// Logika inti CFD — mode: "forward" atau "copy"
async function runCFD(event, args, ctx, mode, scope = "groups") {
  const msg = event.message;
  const client = ctx.client;
  const ownerId = ctx.ownerId;
  const state = getCfd(ownerId);

  const modeName = mode === "copy" ? "Copy-Paste 📋" : "Forward 📤";
  let cmdName;
  if (scope === "users") cmdName = mode === "copy" ? ".cfduserscopy" : ".cfdusers";
  else if (scope === "groups") cmdName = mode === "copy" ? ".cfdcopygroup" : ".cfdgroup";
  else if (scope === "channels") cmdName = ".cfdchannel";
  else cmdName = mode === "copy" ? ".cfdcopy" : ".cfd"; // "all" (grup+user+channel) / legacy "both"
  const targetLabel =
    scope === "users" ? "user/kontak" :
    scope === "channels" ? "channel" :
    scope === "all" ? "grup, user & channel" :
    scope === "both" ? "grup & user" : "grup";

  if (state.running) {
    return _fmt.reply(event, `⚠️ CFD sedang berjalan! Ketik <code>.stopcfd</code> dulu.`);
  }

  // Parse argumen: [jumlah] [delayd] [pesan] atau reply
  let count = 0; // 0 = unlimited
  let delayMs = 5000; // default 5 detik
  let rest = [...args];

  if (rest.length && /^\d+$/.test(rest[0])) {
    count = parseInt(rest[0]);
    rest = rest.slice(1);
  }
  if (rest.length && /^\d+(\.\d+)?d$/i.test(rest[0])) {
    delayMs = Math.max(parseFloat(rest[0]) * 1000, 1000);
    rest = rest.slice(1);
  }

  let promoText = rest.join(" ");
  let repliedMsg = null;
  if (!promoText && msg.replyTo) {
    repliedMsg = await msg.getReplyMessage();
  }

  if (!promoText && !repliedMsg) {
    return _fmt.reply(event,
      `❌ <b>Cara pakai ${cmdName} (${modeName}):</b>\n\n` +
      `• <code>${cmdName} Halo promo!</code> — unlimited (stop pakai .stopcfd)\n` +
      `• <code>${cmdName} 10 Halo promo!</code> — 10 putaran\n` +
      `• <code>${cmdName} 10 3d Halo!</code> — 10 putaran, delay 3 detik\n` +
      `• Reply pesan lalu <code>${cmdName}</code> — kirim pesan itu\n\n` +
      `<i>${mode === "copy" ? "Copy = kirim ulang isi pesan (tanpa label diteruskan)." : "Forward = teruskan pesan (ada label diteruskan)."}</i>\n` +
      `<i>Hanya kirim ke grup yang TIDAK di-blacklist (.addbl).</i>`
    );
  }

  // Forward butuh pesan yang di-reply (ga bisa forward teks ketikan)
  if (mode === "forward" && !repliedMsg && promoText) {
    return _fmt.reply(event,
      `⚠️ Mode <b>forward</b> harus <b>reply pesan</b> yang mau diteruskan.\n\n` +
      `Kalau mau kirim teks ketikan langsung, pakai <code>.cfdcopy ${esc(promoText)}</code>`
    );
  }

  // Ambil semua dialog
  let dialogs;
  try {
    dialogs = await client.getDialogs({ limit: 500 });
  } catch (e) {
    return _fmt.reply(event, `❌ Gagal ambil daftar chat: ${esc(e.message)}`);
  }

  // Filter grup non-blacklist
  const blacklist = getBlacklist(ownerId);
  const blSet = new Set(Object.keys(blacklist).map(normId));
  const targets = dialogs.filter(d => {
    // tipe target sesuai scope (grup / user-kontak / channel siaran / kombinasi)
    const ent = d.entity;
    const isUserChat = d.isUser && ent && !ent.bot && !ent.self && normId(d.id) !== "777000";
    const isBroadcast = !!(ent && ent.broadcast === true); // channel siaran murni (bukan megagroup)
    const isGroupChat = d.isGroup; // grup biasa + supergroup (megagroup)
    let typeOk;
    if (scope === "users") typeOk = isUserChat;
    else if (scope === "channels") typeOk = isBroadcast;
    else if (scope === "all") typeOk = isGroupChat || isUserChat || isBroadcast;
    else if (scope === "both") typeOk = isGroupChat || isUserChat; // legacy
    else typeOk = isGroupChat; // "groups"
    if (!typeOk) return false;
    const cands = [];
    if (d.id != null) cands.push(normId(d.id));
    if (d.entity?.id != null) cands.push(normId(d.entity.id));
    if (cands.some(c => blSet.has(c))) return false;
    return true;
  });

  console.log(`[CFD-${mode}] owner=${ownerId} bl=${blSet.size} dialogs=${dialogs.length} targets=${targets.length}`);

  if (!targets.length) {
    return _fmt.reply(event, `❌ Tidak ada ${targetLabel} target (semua di-blacklist / belum ada chat-nya).`);
  }

  // Siapkan isi pesan yang mau dikirim (dihitung sekali, bukan per-target)
  let repliedText = "";
  let repliedHasMedia = false;
  if (repliedMsg) {
    repliedText = repliedMsg.text || repliedMsg.message || "";
    // Media yang BENERAN bisa dikirim ulang (bukan preview link / kosong)
    const mt = repliedMsg.media && repliedMsg.media.className;
    repliedHasMedia = !!(repliedMsg.media && mt !== "MessageMediaWebPage" && mt !== "MessageMediaEmpty");
  }

  // Mode COPY tapi pesan yang di-reply ga ada teks & media yang bisa disalin → stop rapi (jangan spam error tiap target)
  if (mode === "copy" && repliedMsg && !repliedHasMedia && !repliedText) {
    return _fmt.reply(event, `❌ Pesan yang di-reply tidak punya teks/media yang bisa disalin (mis. polling/kontak). Coba pakai <code>.cfd</code> (forward) buat pesan seperti ini.`);
  }

  state.running = true;
  const modeInfo = count === 0 ? "Unlimited ♾️" : `${count} putaran`;
  await _fmt.reply(event,
    `🚀 <b>CFD Dimulai!</b>\n\n` +
    `<b>Metode:</b> ${modeName}\n` +
    `<b>Target:</b> ${targets.length} ${targetLabel}\n` +
    `<b>Mode:</b> ${modeInfo}\n` +
    `<b>Delay:</b> ${delayMs / 1000} detik\n` +
    `<b>Blacklist:</b> ${Object.keys(blacklist).length} chat (di-skip)\n\n` +
    ((scope === "users" || scope === "all" || scope === "both") ? `⚠️ <i>Target termasuk DM user/kontak — risiko limit/ban akun lebih tinggi. Pakai bijak.</i>\n\n` : ``) +
    `<i>Ketik <code>.stopcfd</code> untuk berhenti.</i>`
  );

  let round = 0, sentTotal = 0, floodWaits = 0, skippedTotal = 0, autoBlSkips = 0;
  const MAX_FLOOD = 220; // kalau flood minta nunggu lebih lama dari ini (detik) → stop biar aman
  let criticalError = null;
  try {
    while (state.running) {
      round++;
      for (const t of targets) {
        if (!state.running) break;
        let attempt = 0;
        while (state.running) {
          try {
            if (mode === "forward" && repliedMsg) {
              // FORWARD: teruskan pesan asli (ada label "diteruskan")
              await client.forwardMessages(t.id, { messages: [repliedMsg.id], fromPeer: msg.peerId });
            } else if (repliedMsg) {
              // COPY: kirim ulang isi pesan (tanpa label)
              if (repliedHasMedia) {
                try {
                  await client.sendFile(t.id, { file: repliedMsg.media, caption: repliedText || "" });
                } catch (mediaErr) {
                  // Media ga bisa dikirim ulang (tipe ga didukung) → fallback teks kalau ada,
                  // biar 1 media aneh ga bikin grup di-skip + salah auto-blacklist.
                  if (repliedText) await client.sendMessage(t.id, { message: repliedText });
                  else throw mediaErr;
                }
              } else if (repliedText) {
                await client.sendMessage(t.id, { message: repliedText });
              }
            } else {
              // Teks ketikan langsung (cuma mode copy)
              await client.sendMessage(t.id, { message: promoText });
            }
            sentTotal++;
            break; // sukses → lanjut target berikutnya
          } catch (e) {
            const em = (e.errorMessage || e.message || "").toUpperCase();

            // PEER_FLOOD = akun di-flag spam (tanpa hitungan detik) → stop, mesti istirahat
            if (em.includes("PEER_FLOOD")) {
              criticalError = "PEER_FLOOD (akun dianggap spam — istirahatin beberapa jam, atau pakai API sendiri)";
              break;
            }
            // FLOOD_WAIT (ada detiknya) → TUNGGU lalu coba lagi target yang sama (jangan mati)
            const isFlood = em.includes("FLOOD") || e.className === "FloodWaitError";
            if (isFlood) {
              let secs = e.seconds || 0;
              if (!secs) { const m = em.match(/FLOOD_WAIT_(\d+)/); if (m) secs = parseInt(m[1]); }
              if (!secs) { const m = em.match(/(\d+)\s*SECONDS?/); if (m) secs = parseInt(m[1]); }
              if (secs > 0 && secs <= MAX_FLOOD && attempt < 2) {
                attempt++; floodWaits++;
                await sleep((secs + 1) * 1000);
                continue;
              }
              criticalError = `FLOOD_WAIT${secs ? ` ${secs} detik` : ""} (API lagi limit berat)`;
              break;
            }
            // FATAL = masalah akun-wide (sesi mati / akun dinonaktifkan / dibekukan) → stop total
            const FATAL = ["AUTH_KEY", "USER_DEACTIVATED", "SESSION_REVOKED", "SESSION_EXPIRED", "FROZEN", "PHONE_NUMBER_BANNED", "ACCOUNT_BANNED", "USER_DEACTIVATED_BAN"];
            if (FATAL.some(k => em.includes(k))) {
              criticalError = `${em} (session/akun bermasalah)`;
              break;
            }
            // TRANSIEN = gangguan sesaat (jaringan putus, timeout, server sibuk, rpc error).
            // BUKAN salah grupnya → tunggu bentar & coba lagi target yang SAMA, JANGAN auto-blacklist.
            // Ini penyebab umum "error di tengah-tengah" cfd — sekarang di-retry, bukan di-skip.
            const TRANSIENT = ["TIMEOUT", "TIMED OUT", "NOT CONNECTED", "DISCONNECT", "CONNECTION", "ECONNRESET", "ETIMEDOUT", "NETWORK", "RPC_CALL_FAIL", "INTERNAL", "MSGID", "MSG_ID", "-500", "-503", "RPCERROR: 500", "RPCERROR: 503", "SERVER ERROR"];
            if (TRANSIENT.some(k => em.includes(k))) {
              if (attempt < 3) {
                attempt++;
                await sleep(2000 * attempt); // backoff: 2s, 4s, 6s
                continue;
              }
              // Udah 3x tetap gagal → skip target ini TANPA blacklist (bukan salah grupnya)
              skippedTotal++;
              break;
            }
            // Error PER-GRUP (cuma ga bisa kirim ke grup INI): di-ban di grup itu, dilarang nulis,
            // grup private, slow mode, dll → SKIP grup ini + auto-blacklist, LANJUT ke grup lain.
            skippedTotal++;
            const PERGROUP = ["USER_BANNED_IN_CHANNEL", "CHAT_WRITE_FORBIDDEN", "CHAT_SEND_", "CHANNEL_PRIVATE", "USER_IS_BLOCKED", "CHAT_ADMIN_REQUIRED", "TOPIC_CLOSED", "CHAT_RESTRICTED", "FORBIDDEN"];
            if (PERGROUP.some(k => em.includes(k))) {
              try {
                const bl = require("./blacklist");
                const tid = (t.id != null ? t.id : (t.entity && t.entity.id));
                if (bl.addById && bl.addById(ownerId, tid, t.name || t.title)) autoBlSkips++;
              } catch {}
            }
            break; // lewati target ini, lanjut broadcast
          }
        }
        if (criticalError) break;
        if (delayMs > 0) await sleep(delayMs);
      }
      if (criticalError) break;
      if (count !== 0 && round >= count) break;
    }
  } catch (e) {
    console.error("CFD error:", e.message);
    const em = (e.errorMessage || e.message || "").toUpperCase();
    if (em.includes("FLOOD")) criticalError = `FLOOD_WAIT (limit API)${e.seconds ? ` — tunggu ${e.seconds} detik` : ""}`;
  }

  const wasRunning = state.running;
  state.running = false;

  try {
    const errBlock = criticalError
      ? `\n\n🔴 <b>BERHENTI KARENA ERROR API:</b>\n<code>${_fmt.esc(criticalError)}</code>\n\n` +
        `<i>Ini tanda API kena limit/ban. Kalau kamu pakai API bawaan (mode Cepat), CFD user lain juga bisa kena. Saran: tunggu beberapa jam, atau reconnect pakai API sendiri (/connect → 🔧 Manual).</i>`
      : "";
    await client.sendMessage(msg.peerId, {
      message: _fmt.wrap(
        `${criticalError ? "🔴 CFD Terhenti (Error)" : wasRunning ? "✅ CFD Selesai" : "🛑 CFD Dihentikan"}\n\n` +
        `<b>Metode:</b> ${modeName}\n` +
        `<b>Total putaran:</b> ${round}\n` +
        `<b>Total terkirim:</b> ${sentTotal} pesan` +
        (floodWaits ? `\n<b>Auto-tunggu flood:</b> ${floodWaits}x (lanjut otomatis)` : ``) +
        (skippedTotal ? `\n<b>Grup di-skip:</b> ${skippedTotal}${autoBlSkips ? ` (${autoBlSkips} auto-blacklist)` : ``}` : ``) +
        errBlock
      ),
      parseMode: "html",
    });
  } catch {}
}

module.exports.commands = [
  {
    name: "cfd",
    description: "Promosi massal FORWARD ke SEMUA (grup + user + channel) — reply pesan + .cfd",
    category: "Promosi",
    handler: (event, args, ctx) => runCFD(event, args, ctx, "forward", "all"),
  },
  {
    name: "cfdcopy",
    description: "Promosi massal COPY-PASTE ke SEMUA (grup + user + channel) — .cfdcopy <pesan> / reply",
    category: "Promosi",
    handler: (event, args, ctx) => runCFD(event, args, ctx, "copy", "all"),
  },
  {
    name: "cfdchannel",
    description: "Promosi massal FORWARD ke CHANNEL doang (reply pesan + .cfdchannel)",
    category: "Promosi",
    handler: (event, args, ctx) => runCFD(event, args, ctx, "forward", "channels"),
  },
  {
    name: "cfdusers",
    description: "Promosi massal FORWARD ke user/kontak doang (reply pesan + .cfdusers)",
    category: "Promosi",
    handler: (event, args, ctx) => runCFD(event, args, ctx, "forward", "users"),
  },
  {
    name: "cfdgroup",
    description: "Promosi massal FORWARD ke GRUP doang (reply pesan + .cfdgroup)",
    category: "Promosi",
    handler: (event, args, ctx) => runCFD(event, args, ctx, "forward", "groups"),
  },
  {
    name: "cfdcopygroup",
    description: "Promosi massal COPY-PASTE ke GRUP doang (.cfdcopygroup <pesan> / reply)",
    category: "Promosi",
    handler: (event, args, ctx) => runCFD(event, args, ctx, "copy", "groups"),
  },
  {
    name: "cfduserscopy",
    description: "Promosi massal COPY-PASTE ke user/kontak (.cfduserscopy <pesan> / reply)",
    category: "Promosi",
    handler: (event, args, ctx) => runCFD(event, args, ctx, "copy", "users"),
  },
  {
    name: "stopcfd",
    description: "Hentikan CFD yang sedang berjalan",
    category: "Promosi",
    handler: async (event, args, ctx) => {
      const state = getCfd(ctx.ownerId);
      if (!state.running) {
        return _fmt.reply(event, `ℹ️ Tidak ada CFD yang sedang berjalan.`);
      }
      state.running = false;
      return _fmt.reply(event, `🛑 <b>CFD dihentikan!</b>`);
    },
  },
];
