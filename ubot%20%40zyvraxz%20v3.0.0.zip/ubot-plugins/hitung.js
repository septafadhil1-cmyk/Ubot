// ─────────────────────────────────────────
//  Plugin: Counter (penghitung bernama) — tersimpan permanen per ubot
//  Buat ngitung apa aja: setoran, absen, stok cepat, dll.
//  .counterset <nama> [angka]  → bikin/atur counter (default 0)
//  .counterplus <nama> [n]     → tambah (default +1)
//  .counterminus <nama> [n]    → kurang (default -1)
//  .counters                   → daftar semua counter + nilainya
//  .delcounter <nama>          → hapus counter
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");
const esc = _fmt.esc;

let cache = null; // ownerId(str) → { counters: { name: number } }

async function initHitung() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("hitung");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { counters: d.counters || {} };
      }
      console.log(`✅ [db] load hitung: ${docs.length} user`);
    } catch (e) { console.error("init hitung:", e.message); }
  }
}
function get(ownerId) { const id = String(ownerId); if (!cache) cache = {}; if (!cache[id]) cache[id] = { counters: {} }; return cache[id]; }
function save(ownerId) { store.upsert("hitung", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

function makeStep(sign) {
  return async (event, args, ctx) => {
    const name = (args[0] || "").toLowerCase();
    if (!name) return _fmt.reply(event, `❌ Format: <code>.counter${sign > 0 ? "plus" : "minus"} &lt;nama&gt; [n]</code>`);
    const step = args[1] ? parseInt(args[1]) : 1;
    if (isNaN(step)) return _fmt.reply(event, `❌ Angka tidak valid.`);
    const c = get(ctx.ownerId);
    c.counters[name] = (c.counters[name] || 0) + sign * step;
    save(ctx.ownerId);
    return _fmt.reply(event, `${sign > 0 ? "➕" : "➖"} <b>${esc(name)}</b> = <b>${c.counters[name]}</b>`);
  };
}

module.exports.initHitung = initHitung;
module.exports.commands = [
  {
    name: "counterset", description: "Bikin/atur counter: .counterset <nama> [angka]", category: "Counter",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      if (!name) return _fmt.reply(event, `❌ Format: <code>.counterset &lt;nama&gt; [angka]</code>`);
      const val = args[1] != null ? parseInt(args[1]) : 0;
      if (isNaN(val)) return _fmt.reply(event, `❌ Angka tidak valid.`);
      const c = get(ctx.ownerId);
      c.counters[name] = val;
      save(ctx.ownerId);
      return _fmt.reply(event, `🔢 Counter "<b>${esc(name)}</b>" diset ke <b>${val}</b>.`);
    },
  },
  { name: "counterplus", description: "Tambah counter: .counterplus <nama> [n]", category: "Counter", handler: makeStep(1) },
  { name: "counterminus", description: "Kurang counter: .counterminus <nama> [n]", category: "Counter", handler: makeStep(-1) },
  {
    name: "counters", description: "Daftar semua counter", category: "Counter",
    handler: async (event, args, ctx) => {
      const c = get(ctx.ownerId);
      const keys = Object.keys(c.counters);
      if (!keys.length) return _fmt.reply(event, `🔢 Belum ada counter. Bikin pakai <code>.counterset</code>.`);
      const lines = [`🔢 <b>Counters</b> (${keys.length})`, `⏣────────────────⏣\n`];
      for (const k of keys.sort()) lines.push(`• <b>${esc(k)}</b> = ${c.counters[k]}`);
      return _fmt.reply(event, lines.join("\n"));
    },
  },
  {
    name: "delcounter", description: "Hapus counter: .delcounter <nama>", category: "Counter",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      const c = get(ctx.ownerId);
      if (!name || !(name in c.counters)) return _fmt.reply(event, `❌ Counter "${esc(name || "-")}" ga ada.`);
      delete c.counters[name];
      save(ctx.ownerId);
      return _fmt.reply(event, `🗑 Counter "<b>${esc(name)}</b>" dihapus.`);
    },
  },
];
