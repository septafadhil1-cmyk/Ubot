// ─────────────────────────────────────────
//  Plugin: Filter (auto-respon kata kunci di GRUP) — tersimpan permanen per ubot & per grup
//  .addfilter <kata kunci>, <balasan>  → pasang filter di grup ini
//     contoh: .addfilter promo, Cek pinned ya kak!
//  .filters       → lihat semua filter di grup ini
//  .delfilter <kata kunci>  → hapus 1 filter
//  .stopfilter    → hapus semua filter di grup ini
//
//  Kalau ada anggota grup nulis pesan yang mengandung kata kunci, ubot auto-balas.
//  (Ga nanggapi pesan diri sendiri biar ga looping.)
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");

const esc = _fmt.esc;

let cache = null; // ownerId(str) → { chats: { chatId: [{keyword, response}] } }

async function initFilter() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("filter");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { chats: d.chats || {} };
      }
      console.log(`✅ [db] load filter: ${docs.length} user`);
    } catch (e) { console.error("init filter:", e.message); }
  }
}

function getOwner(ownerId) {
  const id = String(ownerId);
  if (!cache) cache = {};
  if (!cache[id]) cache[id] = { chats: {} };
  return cache[id];
}
function save(ownerId) { store.upsert("filter", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

// Cooldown per (owner,chat,keyword) biar ga spam
const lastFire = new Map();
const MIN_GAP = 2000;

// Cek keyword ada di teks: kalau keyword 1 kata → cocok per-kata; kalau ada spasi → substring
function matches(text, keyword) {
  const t = text.toLowerCase();
  const k = keyword.toLowerCase();
  if (k.includes(" ")) return t.includes(k);
  return t.split(/\s+/).includes(k);
}

// Dipanggil ubotManager buat tiap pesan grup dari orang lain
async function handleGroup(event, { client, ownerId, me, senderId }) {
  try {
    if (event.isPrivate) return; // cuma grup/supergroup
    const msg = event.message;
    if (!msg || !msg.text) return;
    if (!senderId || senderId === me.id.toString()) return; // jangan tanggapi diri sendiri (anti-loop)

    const owner = cache && cache[String(ownerId)];
    if (!owner) return;
    const chatId = String(msg.chatId || "");
    const list = owner.chats[chatId];
    if (!list || !list.length) return;

    const text = msg.text.trim();
    for (const f of list) {
      if (!matches(text, f.keyword)) continue;
      const key = `${ownerId}:${chatId}:${f.keyword.toLowerCase()}`;
      const now = Date.now();
      if (now - (lastFire.get(key) || 0) < MIN_GAP) return;
      lastFire.set(key, now);
      try { await client.sendMessage(msg.peerId, { message: f.response, replyTo: msg.id }); } catch {}
      return; // satu balasan per pesan
    }
  } catch (e) {
    console.error("filter handleGroup:", e.message);
  }
}

module.exports.initFilter = initFilter;
module.exports.handleGroup = handleGroup;

module.exports.commands = [
  {
    name: "addfilter",
    description: "Pasang auto-respon di grup: .addfilter <kata kunci>, <balasan>",
    category: "Filter",
    handler: async (event, args, ctx) => {
      if (event.isPrivate) return _fmt.reply(event, `❌ Filter cuma bisa dipasang di dalam grup.`);
      const raw = args.join(" ").trim();
      const ci = raw.indexOf(",");
      if (ci === -1) {
        return _fmt.reply(event, `❌ Format: <code>.addfilter &lt;kata kunci&gt;, &lt;balasan&gt;</code>\nContoh: <code>.addfilter promo, Cek pinned ya kak!</code>`);
      }
      const keyword = raw.slice(0, ci).trim();
      const response = raw.slice(ci + 1).trim();
      if (!keyword || !response) return _fmt.reply(event, `❌ Kata kunci & balasan tidak boleh kosong.`);
      const owner = getOwner(ctx.ownerId);
      const chatId = String(event.message.chatId || "");
      if (!owner.chats[chatId]) owner.chats[chatId] = [];
      const existing = owner.chats[chatId].find((f) => f.keyword.toLowerCase() === keyword.toLowerCase());
      if (existing) existing.response = response;
      else owner.chats[chatId].push({ keyword, response });
      save(ctx.ownerId);
      return _fmt.reply(event,
        `✅ <b>Filter dipasang</b> di grup ini!\n\n` +
        `kata kunci: <b>${esc(keyword)}</b>\n` +
        `balasan: ${esc(response)}\n\n` +
        `<i>Anggota nulis "${esc(keyword)}" → ubot auto-balas.</i>`);
    },
  },
  {
    name: "filters",
    description: "Lihat semua filter di grup ini",
    category: "Filter",
    handler: async (event, args, ctx) => {
      if (event.isPrivate) return _fmt.reply(event, `❌ Perintah ini untuk di dalam grup.`);
      const owner = getOwner(ctx.ownerId);
      const chatId = String(event.message.chatId || "");
      const list = owner.chats[chatId] || [];
      if (!list.length) return _fmt.reply(event, `📁 Belum ada filter di grup ini. Pasang pakai <code>.addfilter</code>.`);
      const lines = [`📁 <b>Filter grup ini</b> (${list.length})`, `⏣────────────────⏣\n`];
      for (const f of list) lines.push(`• <b>${esc(f.keyword)}</b> → ${esc(f.response)}`);
      return _fmt.reply(event, lines.join("\n"));
    },
  },
  {
    name: "delfilter",
    description: "Hapus 1 filter: .delfilter <kata kunci>",
    category: "Filter",
    handler: async (event, args, ctx) => {
      if (event.isPrivate) return _fmt.reply(event, `❌ Perintah ini untuk di dalam grup.`);
      const keyword = args.join(" ").trim();
      if (!keyword) return _fmt.reply(event, `❌ Format: <code>.delfilter &lt;kata kunci&gt;</code>`);
      const owner = getOwner(ctx.ownerId);
      const chatId = String(event.message.chatId || "");
      const list = owner.chats[chatId] || [];
      const before = list.length;
      owner.chats[chatId] = list.filter((f) => f.keyword.toLowerCase() !== keyword.toLowerCase());
      if (owner.chats[chatId].length === before) return _fmt.reply(event, `❌ Filter "${esc(keyword)}" tidak ditemukan di grup ini.`);
      save(ctx.ownerId);
      return _fmt.reply(event, `🗑 Filter "<b>${esc(keyword)}</b>" dihapus.`);
    },
  },
  {
    name: "stopfilter",
    description: "Hapus SEMUA filter di grup ini",
    category: "Filter",
    handler: async (event, args, ctx) => {
      if (event.isPrivate) return _fmt.reply(event, `❌ Perintah ini untuk di dalam grup.`);
      const owner = getOwner(ctx.ownerId);
      const chatId = String(event.message.chatId || "");
      const n = (owner.chats[chatId] || []).length;
      owner.chats[chatId] = [];
      save(ctx.ownerId);
      return _fmt.reply(event, `🧹 <b>${n} filter dihapus</b> dari grup ini.`);
    },
  },
];
