// ─────────────────────────────────────────
//  Plugin: Brat — bikin stiker gaya "brat" (Charli XCX) dari teks
//   • .brat <pesan>        → stiker brat dari teks
//   • .brat (reply pesan)  → ambil teks dari pesan yang di-reply
//
//  Estetika: background hijau lime (#8ACE00), teks hitam lowercase,
//  sedikit blur, auto-wrap & auto-size biar muat di 512x512.
// ─────────────────────────────────────────
const _fmt = require("./_format");

const { Api } = require("telegram");
const { createCanvas } = require("@napi-rs/canvas");
const fs = require("fs");
const path = require("path");
const os = require("os");

const SIZE = 512;
const BG = "#8ACE00";     // hijau lime khas brat
const FG = "#000000";     // teks hitam
const PAD = 40;           // padding pinggir

// Pecah teks jadi baris yang muat di lebar maxWidth pada font tertentu
function wrapText(ctx, text, maxWidth) {
  const words = String(text).split(/\s+/).filter(Boolean);
  const lines = [];
  let line = "";
  for (const w of words) {
    const test = line ? line + " " + w : w;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = w;
      // kalau 1 kata aja udah kepanjangan, paksa potong per-karakter
      while (ctx.measureText(line).width > maxWidth && line.length > 1) {
        let cut = line.length - 1;
        while (cut > 1 && ctx.measureText(line.slice(0, cut)).width > maxWidth) cut--;
        lines.push(line.slice(0, cut));
        line = line.slice(cut);
      }
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines;
}

// Render teks brat → buffer webp 512x512
function renderBrat(text) {
  const canvas = createCanvas(SIZE, SIZE);
  const ctx = canvas.getContext("2d");

  // Background
  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, SIZE, SIZE);

  const msg = String(text).toLowerCase().trim();
  const maxWidth = SIZE - PAD * 2;
  const maxHeight = SIZE - PAD * 2;

  // Auto-size: turunin font sampai semua baris muat tinggi
  let fontSize = 150;
  let lines = [];
  let lineHeight = 0;
  const fontFamily = "Arial, 'Helvetica Neue', sans-serif";
  for (; fontSize >= 18; fontSize -= 2) {
    ctx.font = `normal ${fontSize}px ${fontFamily}`;
    lines = wrapText(ctx, msg, maxWidth);
    lineHeight = fontSize * 1.08;
    if (lines.length * lineHeight <= maxHeight) break;
  }

  // Gambar teks: rata kiri, vertikal center — sedikit blur biar mirip cover brat
  ctx.fillStyle = FG;
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.filter = "blur(1.2px)";

  const totalH = lines.length * lineHeight;
  let y = (SIZE - totalH) / 2;
  for (const ln of lines) {
    ctx.fillText(ln, PAD, y);
    y += lineHeight;
  }
  ctx.filter = "none";

  return canvas.toBuffer("image/webp");
}

// Ambil teks dari args atau pesan yang di-reply
async function getText(event, args) {
  let t = args.join(" ").trim();
  if (!t && event.message.replyTo) {
    try {
      const r = await event.message.getReplyMessage();
      t = (r?.text || r?.message || "").trim();
    } catch {}
  }
  return t;
}

module.exports.commands = [
  {
    name: "brat",
    description: "Bikin stiker gaya brat dari teks. .brat <pesan> atau reply pesan lalu .brat",
    usage: ".brat <pesan> / reply pesan",
    category: "Fun",
    handler: async (event, args) => {
      const msg = event.message;
      const client = msg.client;

      const text = await getText(event, args);
      if (!text) {
        return msg.reply({
          message: `<blockquote><b>❌ Kasih teks atau reply pesan.\nContoh: <code>.brat apa aja boleh</code></b></blockquote>`,
          parseMode: "html",
        });
      }
      if (text.length > 250) {
        return msg.reply({
          message: `<blockquote><b>❌ Teks kepanjangan (maks 250 karakter).</b></blockquote>`,
          parseMode: "html",
        });
      }

      let tmpPath;
      try {
        const buf = renderBrat(text);
        tmpPath = path.join(os.tmpdir(), `brat_${Date.now()}.webp`);
        fs.writeFileSync(tmpPath, buf);

        await client.sendFile(msg.peerId, {
          file: tmpPath,
          replyTo: msg.replyTo ? msg.replyTo.replyToMsgId : msg.id,
          forceDocument: false,
          attributes: [
            new Api.DocumentAttributeSticker({
              alt: "brat",
              stickerset: new Api.InputStickerSetEmpty(),
            }),
          ],
        });
      } catch (e) {
        console.error("brat error:", e.message);
        return msg.reply({
          message: `<blockquote><b>❌ Gagal: ${_fmt.esc(e.message)}</b></blockquote>`,
          parseMode: "html",
        });
      } finally {
        if (tmpPath) { try { fs.unlinkSync(tmpPath); } catch {} }
      }
    },
  },
];
