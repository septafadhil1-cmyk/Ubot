// ─────────────────────────────────────────
//  Plugin: Spam
//  .spam <jumlah> <pesan>
//  .spam <jumlah> <delay>d <pesan>   → delay dalam detik, contoh: 1d
//  .spam <jumlah>                    → + reply pesan = spam reply
//  .spam <jumlah> <delay>d           → + reply pesan + delay
//  .stopspam                         → hentikan spam
// ─────────────────────────────────────────

const _fmt = require("./_format");
const esc = _fmt.esc;

// Pakai formatter bersama (mono tetap rapi di dalam kutip)
async function reply(event, html) {
  return _fmt.reply(event, html);
}

function sleep(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

// State spam aktif — bisa dihentikan via .stopspam
let spamRunning = false;

module.exports.commands = [
  {
    name: "spam",
    description: "Spam pesan berkali-kali ke chat",
    usage: ".spam <jumlah> [<delay>d] <pesan> | reply pesan lalu .spam <jumlah>",
    category: "Fun",
    handler: async (event, args) => {
      if (!args.length) {
        return reply(event,
          `❌ <b>Cara pakai:</b>\n\n` +
          `• <code>.spam 10 halo!</code> — spam 10x\n` +
          `• <code>.spam 10 2d halo!</code> — spam 10x delay 2 detik\n` +
          `• Reply pesan lalu <code>.spam 10</code> — spam reply 10x\n` +
          `• Reply pesan lalu <code>.spam 10 1d</code> — spam reply 10x delay 1 detik\n` +
          `• <code>.stopspam</code> — hentikan spam`
        );
      }

      // Parse jumlah
      const count = parseInt(args[0]);
      if (isNaN(count) || count < 1) {
        return reply(event, `❌ Jumlah harus angka lebih dari 0. Contoh: <code>.spam 10 halo!</code>`);
      }
      if (count > 200) {
        return reply(event, `❌ Maksimal 200x spam.`);
      }

      // Parse delay (opsional) — format: angkaD, contoh: 1d, 0.5d, 2d
      let delayMs = 0;
      let remainingArgs = args.slice(1);

      if (remainingArgs.length > 0 && /^\d+(\.\d+)?d$/i.test(remainingArgs[0])) {
        const delaySec = parseFloat(remainingArgs[0]);
        delayMs = Math.min(delaySec * 1000, 60000); // max 60 detik
        remainingArgs = remainingArgs.slice(1);
      }

      // Ambil teks pesan atau dari reply
      const spamText = remainingArgs.join(" ");
      const repliedMsg = await event.message.getReplyMessage();

      if (!spamText && !repliedMsg) {
        return reply(event,
          `❌ Tidak ada pesan. Tulis pesan setelah jumlah atau reply ke sebuah pesan.\n` +
          `Contoh: <code>.spam 10 halo!</code>`
        );
      }

      // Mulai spam
      if (spamRunning) {
        return reply(event, `⚠️ Spam sedang berjalan! Ketik <code>.stopspam</code> dulu.`);
      }

      spamRunning = true;

      const delayInfo = delayMs > 0 ? ` | Delay: ${delayMs / 1000}d` : " | No delay";
      const modeInfo = repliedMsg ? "Reply spam" : "Text spam";
      await reply(event,
        `🚀 <b>Spam Dimulai!</b>\n\n` +
        `<b>Jumlah:</b> ${count}x\n` +
        `<b>Mode:</b> ${modeInfo}${delayInfo}\n\n` +
        `<i>Ketik <code>.stopspam</code> untuk menghentikan.</i>`
      );

      let sent = 0;
      try {
        for (let i = 0; i < count; i++) {
          if (!spamRunning) break;

          if (repliedMsg) {
            // Spam dengan reply ke pesan yang di-reply user
            await repliedMsg.reply({ message: spamText || repliedMsg.text || "👁️" });
          } else {
            // Spam pesan biasa ke chat yang sama
            await event.message.respond({ message: spamText });
          }

          sent++;
          if (delayMs > 0) await sleep(delayMs);
        }
      } catch (e) {
        console.error("Spam error:", e.message);
      }

      spamRunning = false;

      // Kirim info selesai
      try {
        const status = sent < count ? `⚠️ Dihentikan di pesan ke-${sent}` : `✅ Selesai`;
        await event.message.respond({
          message: `<blockquote><b>${status} — Total terkirim: <b>${sent}/${count}</b></b></blockquote>`,
          parseMode: "html",
        });
      } catch {}
    },
  },

  {
    name: "stopspam",
    description: "Hentikan spam yang sedang berjalan",
    usage: ".stopspam",
    category: "Fun",
    handler: async (event) => {
      if (!spamRunning) {
        return reply(event, `ℹ️ Tidak ada spam yang sedang berjalan.`);
      }
      spamRunning = false;
      return reply(event, `🛑 <b>Spam dihentikan!</b>`);
    },
  },
];
