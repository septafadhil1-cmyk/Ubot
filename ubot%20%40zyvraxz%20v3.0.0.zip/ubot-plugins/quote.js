// ─────────────────────────────────────────
//  Plugin: Quote Sticker
//  .q   → reply ke pesan, jadiin stiker quote (mirip @QuotLyBot)
// ─────────────────────────────────────────
const _fmt = require("./_format");

const { Api } = require("telegram");
const { createCanvas, loadImage } = require("@napi-rs/canvas");
const fs = require("fs");
const path = require("path");
const os = require("os");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function nameToColor(name) {
  const colors = ["#E17076","#7BC862","#65AADD","#A695E7","#EE7AAE","#6EC9CB","#FAA774","#F0941E"];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

function getInitials(name) {
  return name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
}

function wrapText(ctx, text, maxWidth) {
  // Hormati newline yang sudah ada
  const paragraphs = text.split("\n");
  const lines = [];
  for (const para of paragraphs) {
    if (!para) { lines.push(""); continue; }
    const words = para.split(" ");
    let line = "";
    for (const word of words) {
      const test = line ? line + " " + word : word;
      if (ctx.measureText(test).width > maxWidth && line) {
        lines.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    if (line) lines.push(line);
  }
  return lines;
}

async function generateQuote({ senderName, text, avatarBuffer }) {
  const PADDING = 24;
  const AVATAR_SIZE = 56;
  const FONT_MSG = "26px sans-serif";
  const FONT_NAME = "bold 22px sans-serif";
  const MAX_TEXT_W = 460;
  const LINE_H = 34;
  const GAP = 16; // jarak avatar ke bubble

  const tmpCtx = createCanvas(100, 100).getContext("2d");
  tmpCtx.font = FONT_MSG;
  const lines = wrapText(tmpCtx, text, MAX_TEXT_W);

  tmpCtx.font = FONT_NAME;
  const nameW = tmpCtx.measureText(senderName).width;
  tmpCtx.font = FONT_MSG;
  const textW = Math.max(...lines.map(l => tmpCtx.measureText(l).width), nameW);

  const bubbleW = Math.min(textW + 36, MAX_TEXT_W + 36);
  const nameH = 30;
  const bubbleH = nameH + lines.length * LINE_H + 28;

  const W = PADDING + AVATAR_SIZE + GAP + bubbleW + PADDING;
  const H = Math.max(PADDING * 2 + bubbleH, PADDING * 2 + AVATAR_SIZE);

  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  // Background transparan (biar jadi stiker)
  ctx.clearRect(0, 0, W, H);

  const avatarColor = nameToColor(senderName);
  const initials = getInitials(senderName);
  const avatarX = PADDING;
  const avatarY = H - PADDING - AVATAR_SIZE; // avatar di bawah (kaya Telegram)

  // Avatar lingkaran
  ctx.save();
  ctx.beginPath();
  ctx.arc(avatarX + AVATAR_SIZE / 2, avatarY + AVATAR_SIZE / 2, AVATAR_SIZE / 2, 0, Math.PI * 2);
  ctx.clip();
  if (avatarBuffer) {
    try {
      const img = await loadImage(avatarBuffer);
      ctx.drawImage(img, avatarX, avatarY, AVATAR_SIZE, AVATAR_SIZE);
    } catch {
      ctx.fillStyle = avatarColor;
      ctx.fillRect(avatarX, avatarY, AVATAR_SIZE, AVATAR_SIZE);
    }
  } else {
    ctx.fillStyle = avatarColor;
    ctx.fillRect(avatarX, avatarY, AVATAR_SIZE, AVATAR_SIZE);
  }
  ctx.restore();

  if (!avatarBuffer) {
    ctx.fillStyle = "#fff";
    ctx.font = "bold 22px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(initials, avatarX + AVATAR_SIZE / 2, avatarY + AVATAR_SIZE / 2);
  }

  // Bubble abu gelap (dark mode style)
  const bubbleX = avatarX + AVATAR_SIZE + GAP;
  const bubbleY = PADDING;
  const R = 20;

  ctx.fillStyle = "#182533";
  ctx.beginPath();
  ctx.moveTo(bubbleX + R, bubbleY);
  ctx.lineTo(bubbleX + bubbleW - R, bubbleY);
  ctx.quadraticCurveTo(bubbleX + bubbleW, bubbleY, bubbleX + bubbleW, bubbleY + R);
  ctx.lineTo(bubbleX + bubbleW, bubbleY + bubbleH - R);
  ctx.quadraticCurveTo(bubbleX + bubbleW, bubbleY + bubbleH, bubbleX + bubbleW - R, bubbleY + bubbleH);
  ctx.lineTo(bubbleX + R, bubbleY + bubbleH);
  ctx.quadraticCurveTo(bubbleX, bubbleY + bubbleH, bubbleX, bubbleY + bubbleH - R);
  // Ekor bubble di kiri bawah (nunjuk ke avatar)
  ctx.lineTo(bubbleX, bubbleY + 24);
  ctx.quadraticCurveTo(bubbleX, bubbleY, bubbleX + R, bubbleY);
  ctx.closePath();
  ctx.fill();

  // Ekor segitiga kecil
  ctx.fillStyle = "#182533";
  ctx.beginPath();
  ctx.moveTo(bubbleX, bubbleY + bubbleH - 18);
  ctx.lineTo(bubbleX - 10, bubbleY + bubbleH - 4);
  ctx.lineTo(bubbleX, bubbleY + bubbleH - 4);
  ctx.closePath();
  ctx.fill();

  // Nama pengirim (warna)
  let textY = bubbleY + 16;
  ctx.fillStyle = avatarColor;
  ctx.font = FONT_NAME;
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.fillText(senderName, bubbleX + 18, textY);
  textY += nameH;

  // Teks pesan (putih)
  ctx.fillStyle = "#ffffff";
  ctx.font = FONT_MSG;
  for (const line of lines) {
    ctx.fillText(line, bubbleX + 18, textY);
    textY += LINE_H;
  }

  return canvas.toBuffer("image/webp");
}


async function reply(event, html) {
  return _fmt.reply(event, html);
}

module.exports.commands = [
  {
    name: "q",
    description: "Jadiin pesan yang di-reply menjadi stiker quote",
    usage: ".q (reply ke sebuah pesan)",
    category: "Fun",
    handler: async (event, args) => {
      const msg = event.message;
      const client = msg.client;

      if (!msg.replyTo) {
        return msg.reply({
          message: `<blockquote><b>❌ Reply ke sebuah pesan dulu, lalu ketik <code>.q</code></b></blockquote>`,
          parseMode: "html",
        });
      }

      try {
        const replied = await msg.getReplyMessage();
        if (!replied?.text) {
          return msg.reply({
            message: `<blockquote><b>❌ Pesan yang di-reply tidak punya teks.</b></blockquote>`,
            parseMode: "html",
          });
        }

        const sender = await replied.getSender();
        const senderName = sender?.firstName
          ? `${sender.firstName}${sender.lastName ? " " + sender.lastName : ""}`
          : (sender?.title || "Unknown");

        // Avatar pengirim
        let avatarBuffer = null;
        try {
          avatarBuffer = await client.downloadProfilePhoto(sender, { isBig: false });
          if (avatarBuffer && avatarBuffer.length === 0) avatarBuffer = null;
        } catch {}

        const imgBuffer = await generateQuote({ senderName, text: replied.text, avatarBuffer });

        // Kirim sebagai stiker (.webp)
        const tmpPath = path.join(os.tmpdir(), `quote_${Date.now()}.webp`);
        fs.writeFileSync(tmpPath, imgBuffer);

        await client.sendFile(msg.peerId, {
          file: tmpPath,
          replyTo: replied.id,
          forceDocument: false,
          attributes: [
            new Api.DocumentAttributeSticker({
              alt: "💬",
              stickerset: new Api.InputStickerSetEmpty(),
            }),
          ],
        });

        fs.unlinkSync(tmpPath);
      } catch (e) {
        console.error("quote error:", e.message);
        return msg.reply({
          message: `<blockquote><b>❌ Gagal: ${esc(e.message)}</b></blockquote>`,
          parseMode: "html",
        });
      }
    },
  },
];
