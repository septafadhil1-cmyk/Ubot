// ─────────────────────────────────────────
//  Plugin: Carbon
//  .carbon <kode>   → jadiin kode jadi gambar estetik
//  .carbon          + reply pesan = carbon dari pesan itu
// ─────────────────────────────────────────
const _fmt = require("./_format");

const { createCanvas } = require("@napi-rs/canvas");
const fs = require("fs");
const path = require("path");
const os = require("os");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Syntax highlighting sederhana (token → warna)
const COLORS = {
  keyword: "#c678dd",   // const, let, function, if, return, dll
  string: "#98c379",    // "teks"
  number: "#d19a66",    // 123
  comment: "#5c6370",   // // komentar
  function: "#61afef",  // namaFungsi(
  operator: "#56b6c2",  // + - = > <
  default: "#abb2bf",   // teks biasa
};

const KEYWORDS = new Set([
  "const","let","var","function","return","if","else","for","while","do",
  "class","extends","new","this","async","await","try","catch","finally",
  "import","export","from","default","throw","typeof","instanceof","in","of",
  "true","false","null","undefined","void","yield","switch","case","break","continue",
  "def","print","import","as","with","lambda","None","True","False","elif","pass",
  "public","private","static","int","string","bool","float","double","char","return",
]);

// Tokenize satu baris jadi array {text, color}
function tokenizeLine(line) {
  const tokens = [];
  let i = 0;

  // Komentar
  const commentMatch = line.match(/(\/\/.*$|#.*$)/);
  let codePart = line;
  let commentPart = "";
  if (commentMatch) {
    codePart = line.slice(0, commentMatch.index);
    commentPart = line.slice(commentMatch.index);
  }

  // Regex token: string, number, word, operator, whitespace, lainnya
  const regex = /("([^"\\]|\\.)*"|'([^'\\]|\\.)*'|`([^`\\]|\\.)*`)|(\d+\.?\d*)|([a-zA-Z_$][\w$]*)|(\s+)|([+\-*/%=<>!&|^~?:;,.(){}\[\]])/g;
  let m;
  while ((m = regex.exec(codePart)) !== null) {
    const t = m[0];
    if (m[1]) {
      tokens.push({ text: t, color: COLORS.string });
    } else if (m[5]) {
      tokens.push({ text: t, color: COLORS.number });
    } else if (m[6]) {
      // word — cek keyword atau function call
      const after = codePart.slice(regex.lastIndex).trimStart();
      if (KEYWORDS.has(t)) {
        tokens.push({ text: t, color: COLORS.keyword });
      } else if (after.startsWith("(")) {
        tokens.push({ text: t, color: COLORS.function });
      } else {
        tokens.push({ text: t, color: COLORS.default });
      }
    } else if (m[7]) {
      tokens.push({ text: t, color: COLORS.default });
    } else if (m[8]) {
      tokens.push({ text: t, color: COLORS.operator });
    } else {
      tokens.push({ text: t, color: COLORS.default });
    }
  }

  if (commentPart) tokens.push({ text: commentPart, color: COLORS.comment });
  return tokens;
}

function generateCarbon(code) {
  const lines = code.split("\n");
  const FONT = "18px monospace";
  const LINE_H = 26;
  const PAD = 28;
  const WINDOW_PAD = 24;
  const HEADER_H = 40;
  const LINE_NUM_W = 44;

  const tmpCtx = createCanvas(100, 100).getContext("2d");
  tmpCtx.font = FONT;

  const maxLineW = Math.max(...lines.map(l => tmpCtx.measureText(l).width), 200);
  const codeW = maxLineW + 30;

  const innerW = LINE_NUM_W + codeW + PAD;
  const innerH = HEADER_H + lines.length * LINE_H + PAD;
  const W = innerW + WINDOW_PAD * 2;
  const H = innerH + WINDOW_PAD * 2;

  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  // Background gradient ungu-biru estetik
  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, "#5b247a");
  bg.addColorStop(1, "#1bcedf");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // Window editor (rounded, gelap)
  const winX = WINDOW_PAD, winY = WINDOW_PAD;
  const winW = innerW, winH = innerH;
  const R = 12;
  ctx.shadowColor = "rgba(0,0,0,0.4)";
  ctx.shadowBlur = 30;
  ctx.shadowOffsetY = 12;
  ctx.fillStyle = "#282c34";
  ctx.beginPath();
  ctx.moveTo(winX + R, winY);
  ctx.lineTo(winX + winW - R, winY);
  ctx.quadraticCurveTo(winX + winW, winY, winX + winW, winY + R);
  ctx.lineTo(winX + winW, winY + winH - R);
  ctx.quadraticCurveTo(winX + winW, winY + winH, winX + winW - R, winY + winH);
  ctx.lineTo(winX + R, winY + winH);
  ctx.quadraticCurveTo(winX, winY + winH, winX, winY + winH - R);
  ctx.lineTo(winX, winY + R);
  ctx.quadraticCurveTo(winX, winY, winX + R, winY);
  ctx.closePath();
  ctx.fill();
  ctx.shadowColor = "transparent";
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;

  // Traffic lights (merah kuning hijau)
  const dotY = winY + 20;
  const dots = ["#ff5f56", "#ffbd2e", "#27c93f"];
  dots.forEach((c, i) => {
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.arc(winX + 22 + i * 22, dotY, 7, 0, Math.PI * 2);
    ctx.fill();
  });

  // Render kode dengan highlighting
  ctx.font = FONT;
  ctx.textBaseline = "top";
  let y = winY + HEADER_H + 4;

  for (let i = 0; i < lines.length; i++) {
    // Nomor baris
    ctx.fillStyle = "#4b5263";
    ctx.textAlign = "right";
    ctx.fillText(String(i + 1), winX + LINE_NUM_W - 12, y);

    // Token kode
    ctx.textAlign = "left";
    let x = winX + LINE_NUM_W + 8;
    const tokens = tokenizeLine(lines[i]);
    for (const tok of tokens) {
      ctx.fillStyle = tok.color;
      ctx.fillText(tok.text, x, y);
      x += ctx.measureText(tok.text).width;
    }
    y += LINE_H;
  }

  return canvas.toBuffer("image/png");
}


async function reply(event, html) {
  return _fmt.reply(event, html);
}

module.exports.commands = [
  {
    name: "carbon",
    description: "Jadiin kode jadi gambar estetik",
    usage: ".carbon <kode> | reply pesan lalu .carbon",
    category: "Fun",
    handler: async (event, args) => {
      const msg = event.message;
      const client = msg.client;

      let code = args.join(" ");

      // Kalau ga ada kode, ambil dari reply
      if (!code && msg.replyTo) {
        const replied = await msg.getReplyMessage();
        code = replied?.text || "";
      }

      if (!code) {
        return msg.reply({
          message:
            `<blockquote><b>❌ <b>Cara pakai:</b>\n\n` +
            `• <code>.carbon const x = 10;</code>\n` +
            `• Reply pesan berisi kode lalu <code>.carbon</code></b></blockquote>`,
          parseMode: "html",
        });
      }

      try {
        const imgBuffer = generateCarbon(code);
        const tmpPath = path.join(os.tmpdir(), `carbon_${Date.now()}.png`);
        fs.writeFileSync(tmpPath, imgBuffer);
        await client.sendFile(msg.peerId, {
          file: tmpPath,
          replyTo: msg.id,
          forceDocument: false,
        });
        fs.unlinkSync(tmpPath);
      } catch (e) {
        console.error("carbon error:", e.message);
        return msg.reply({
          message: `<blockquote><b>❌ Gagal: ${esc(e.message)}</b></blockquote>`,
          parseMode: "html",
        });
      }
    },
  },
];
