// .withdraw <nominal> <KODE_BANK> <nomor_rekening> <nama_pemilik>
// .withdrawstatus <ID>
const _fmt = require('./_format');
const payout = require('../lib/xenditPayout');
const esc = _fmt.esc;
function rp(n) { return 'Rp' + Number(n || 0).toLocaleString('id-ID'); }
function parseAmount(raw) { const n = Number(String(raw || '').replace(/[.,]/g, '')); return Number.isSafeInteger(n) && n > 0 ? n : null; }
module.exports.commands = [
 { name: 'withdraw', description: 'Tarik saldo wallet otomatis melalui Xendit Payouts', category: 'Keuangan', handler: async (event,args,ctx) => {
   const amount = parseAmount(args[0]); const bank = String(args[1] || '').toUpperCase(); const account = String(args[2] || ''); const holder = args.slice(3).join(' ');
   if (!amount || !bank || !account || !holder) return _fmt.reply(event, `🏦 <b>WITHDRAW OTOMATIS</b>\n\nFormat: <code>${ctx.prefix || '.'}withdraw 50000 BCA 1234567890 NAMA PEMILIK</code>\nMinimal Rp10.000. Gunakan kode channel bank yang didukung akun Xendit. Pastikan data rekening benar.`);
   try { const w = await payout.payout({ userId: ctx.ownerId, amount, bankCode: bank, accountNumber: account, accountHolder: holder });
     return _fmt.reply(event, `🏦 <b>PENGAJUAN PAYOUT TERKIRIM</b>\n━━━━━━━━━━━━━━━━━━\nID: <code>${esc(w.id)}</code>\nNominal: <b>${rp(w.amount)}</b>\nBank: <b>${esc(w.bankCode)}</b>\nStatus: <b>${esc(String(w.status).toUpperCase())}</b>\n\nSaldo sudah ditahan agar tidak dapat ditarik dua kali. Status provider: <code>${ctx.prefix || '.'}withdrawstatus ${esc(w.id)}</code>`);
   } catch(e) { return _fmt.reply(event, `❌ <b>Withdraw gagal / status belum pasti</b>\n${esc(e.message || 'Error')}`); }
 }},
 { name: 'withdrawstatus', description: 'Cek status payout', category: 'Keuangan', handler: async (event,args,ctx) => {
   if (!args[0]) return _fmt.reply(event, `Format: <code>${ctx.prefix || '.'}withdrawstatus ID_PENARIKAN</code>`);
   try { const w = await payout.statusForUser(args[0], ctx.ownerId); if (!w) return _fmt.reply(event, '❌ ID penarikan tidak ditemukan untuk wallet ini.');
     return _fmt.reply(event, `🏦 <b>STATUS WITHDRAW</b>\nID: <code>${esc(w.id)}</code>\nNominal: <b>${rp(w.amount)}</b>\nBank: <b>${esc(w.bankCode)}</b>\nStatus: <b>${esc(String(w.status).toUpperCase())}</b>\nDibuat: <code>${esc(new Date(w.createdAt).toISOString())}</code>${w.error ? `\nCatatan: ${esc(w.error)}` : ''}`);
   } catch(e) { return _fmt.reply(event, `❌ ${esc(e.message)}`); }
 }}
];
