// ─────────────────────────────────────────
//  Plugin: Keuangan (buku kas pribadi) — tersimpan permanen per ubot
//  .masuk <jumlah> <ket>   → catat pemasukan (mis. .masuk 50rb gaji)
//  .keluar <jumlah> <ket>  → catat pengeluaran
//  .saldo                  → lihat saldo + total masuk/keluar
//  .mutasi                 → riwayat transaksi (dengan nomor)
//  .hapuskas <no>          → hapus 1 transaksi by nomor
//  .resetkas               → hapus semua (mulai dari nol)
//  Mendukung sufiks: 10rb/10k = 10.000, 1.5jt/1juta = 1.500.000
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");

const esc = _fmt.esc;

let cache = null; // ownerId(str) → { entries: [{ts,type,amount,note}] }

async function initKeuangan() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("keuangan");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { entries: Array.isArray(d.entries) ? d.entries : [] };
      }
      console.log(`✅ [db] load keuangan: ${docs.length} user`);
    } catch (e) { console.error("init keuangan:", e.message); }
  }
}

function getBook(ownerId) {
  const id = String(ownerId);
  if (!cache) cache = {};
  if (!cache[id]) cache[id] = { entries: [] };
  return cache[id];
}
function save(ownerId) { store.upsert("keuangan", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

// "50rb" → 50000, "1.5jt"/"1,5jt" → 1500000, "50.000"/"50000" → 50000
// Aturan: kalau ADA sufiks (rb/jt/dll) → "."/"," = desimal (1.5jt = 1,5jt = 1.5jt).
//         kalau TANPA sufiks → "."/"," = pemisah ribuan → dibuang (50.000 = 50000).
function parseAmount(s) {
  if (s == null) return null;
  const str = String(s).toLowerCase().replace(/\s+/g, "");
  const m = str.match(/^([\d.,]+)(rb|ribu|k|jt|juta|m)?$/);
  if (!m) return null;
  const suf = m[2];
  let n;
  if (suf) {
    n = parseFloat(m[1].replace(",", ".")); // desimal
  } else {
    n = parseFloat(m[1].replace(/[.,]/g, "")); // buang pemisah ribuan
  }
  if (!isFinite(n)) return null;
  if (suf === "rb" || suf === "ribu" || suf === "k") n *= 1000;
  else if (suf === "jt" || suf === "juta" || suf === "m") n *= 1000000;
  n = Math.round(n);
  return n > 0 ? n : null;
}
function rp(n) { return "Rp" + Number(n).toLocaleString("id-ID"); }
function tgl(ts) {
  return new Date(ts).toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta" });
}
function totals(book) {
  let masuk = 0, keluar = 0;
  for (const e of book.entries) { if (e.type === "in") masuk += e.amount; else keluar += e.amount; }
  return { masuk, keluar, saldo: masuk - keluar };
}

function makeAdd(type) {
  return async (event, args, ctx) => {
    const amount = parseAmount(args[0]);
    if (!amount) {
      return _fmt.reply(event, `❌ Format: <code>.${type === "in" ? "masuk" : "keluar"} &lt;jumlah&gt; &lt;keterangan&gt;</code>\nContoh: <code>.${type === "in" ? "masuk" : "keluar"} 50rb ${type === "in" ? "gaji" : "makan"}</code>`);
    }
    const note = args.slice(1).join(" ").trim() || "-";
    const book = getBook(ctx.ownerId);
    book.entries.push({ ts: Date.now(), type, amount, note });
    save(ctx.ownerId);
    const t = totals(book);
    return _fmt.reply(event,
      `${type === "in" ? "🟢 <b>Pemasukan</b>" : "🔴 <b>Pengeluaran</b>"} dicatat!\n\n` +
      `jumlah: <b>${rp(amount)}</b>\n` +
      `ket: ${esc(note)}\n\n` +
      `💰 saldo sekarang: <b>${rp(t.saldo)}</b>`);
  };
}

module.exports.initKeuangan = initKeuangan;

module.exports.commands = [
  {
    name: "masuk",
    description: "Catat pemasukan: .masuk <jumlah> <ket> (mis. .masuk 50rb gaji)",
    category: "Keuangan",
    handler: makeAdd("in"),
  },
  {
    name: "keluar",
    description: "Catat pengeluaran: .keluar <jumlah> <ket>",
    category: "Keuangan",
    handler: makeAdd("out"),
  },
  {
    name: "saldo",
    description: "Lihat saldo + total pemasukan & pengeluaran",
    category: "Keuangan",
    handler: async (event, args, ctx) => {
      const book = getBook(ctx.ownerId);
      const t = totals(book);
      return _fmt.reply(event,
        `💰 <b>Saldo Kas</b>\n⏣────────────────⏣\n\n` +
        `🟢 total masuk: <b>${rp(t.masuk)}</b>\n` +
        `🔴 total keluar: <b>${rp(t.keluar)}</b>\n` +
        `💵 <b>saldo: ${rp(t.saldo)}</b>\n\n` +
        `<i>${book.entries.length} transaksi tercatat. Lihat <code>.mutasi</code>.</i>`);
    },
  },
  {
    name: "mutasi",
    description: "Riwayat transaksi kas (dengan nomor buat .hapuskas)",
    category: "Keuangan",
    handler: async (event, args, ctx) => {
      const book = getBook(ctx.ownerId);
      if (!book.entries.length) return _fmt.reply(event, `📒 Belum ada transaksi. Catat pakai <code>.masuk</code> / <code>.keluar</code>.`);
      // tampilkan 20 terakhir
      const start = Math.max(0, book.entries.length - 20);
      const lines = [`📒 <b>Mutasi Kas</b> (${book.entries.length} transaksi)`, `⏣────────────────⏣\n`];
      for (let i = start; i < book.entries.length; i++) {
        const e = book.entries[i];
        lines.push(`<b>#${i + 1}</b> ${e.type === "in" ? "🟢" : "🔴"} ${rp(e.amount)} — ${esc(e.note)}\n     <i>${tgl(e.ts)}</i>`);
      }
      const t = totals(book);
      lines.push(`\n💰 saldo: <b>${rp(t.saldo)}</b>`);
      return _fmt.reply(event, lines.join("\n"));
    },
  },
  {
    name: "hapuskas",
    description: "Hapus 1 transaksi by nomor: .hapuskas <no>",
    category: "Keuangan",
    handler: async (event, args, ctx) => {
      const no = parseInt(args[0]);
      const book = getBook(ctx.ownerId);
      if (isNaN(no) || no < 1 || no > book.entries.length) {
        return _fmt.reply(event, `❌ Nomor tidak valid. Lihat nomor di <code>.mutasi</code>.`);
      }
      const removed = book.entries.splice(no - 1, 1)[0];
      save(ctx.ownerId);
      const t = totals(book);
      return _fmt.reply(event, `🗑 Transaksi #${no} (${removed.type === "in" ? "🟢" : "🔴"} ${rp(removed.amount)} — ${esc(removed.note)}) dihapus.\n\n💰 saldo: <b>${rp(t.saldo)}</b>`);
    },
  },
  {
    name: "resetkas",
    description: "Hapus SEMUA transaksi kas (mulai dari nol)",
    category: "Keuangan",
    handler: async (event, args, ctx) => {
      const book = getBook(ctx.ownerId);
      const n = book.entries.length;
      book.entries = [];
      save(ctx.ownerId);
      return _fmt.reply(event, `🧹 <b>Kas direset.</b> ${n} transaksi dihapus. Saldo kembali ke <b>Rp0</b>.`);
    },
  },
];
