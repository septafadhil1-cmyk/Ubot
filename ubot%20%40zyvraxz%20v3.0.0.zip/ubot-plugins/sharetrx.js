// ─────────────────────────────────────────
//  Plugin: Share TRX ke Channel Testimoni
//  .addtesti <@channel | -100id | link>  → set channel tujuan
//  .sharetrx <nomor>                      → forward struk TRX nomor itu ke channel
//  .sharetrx  (sambil reply pesan)        → forward pesan yang di-reply ke channel
// ─────────────────────────────────────────
const _fmt = require("./_format");
const trxStore = require("../lib/trxStore");

const esc = _fmt.esc;

// Bersihin input channel → bentuk yang bisa di-resolve getEntity
function parseChannelInput(raw) {
  let s = String(raw).trim();
  // dari link t.me/xxx atau https://t.me/xxx
  const m = s.match(/(?:t\.me\/|telegram\.me\/)(@?[\w+]+)/i);
  if (m) s = m[1];
  if (s.startsWith("@")) return s;            // username
  if (/^-?\d+$/.test(s)) return s;            // id numerik
  return "@" + s.replace(/^@/, "");           // anggap username tanpa @
}

const commands = [
  {
    name: "addtesti",
    description: "Set channel tujuan untuk .sharetrx",
    category: "Transaksi",
    handler: async (event, args, ctx) => {
      const client = ctx.client;
      const p = ctx.prefix || ".";
      if (!args[0]) {
        return _fmt.reply(event,
          `❌ Format: <code>${p}addtesti &lt;channel&gt;</code>\n\n` +
          `Contoh:\n` +
          `• <code>${p}addtesti @channeltesti</code>\n` +
          `• <code>${p}addtesti -1001234567890</code>\n` +
          `• <code>${p}addtesti https://t.me/channeltesti</code>\n\n` +
          `<i>Catatan: akun kamu harus jadi anggota/admin channel itu.</i>`);
      }
      const ref = parseChannelInput(args[0]);
      try {
        const ent = await client.getEntity(ref);
        const title = ent.title || ent.username || ref;
        // simpan @username kalau ada (paling stabil), kalau ga simpan id -100
        let store = ref;
        if (ent.username) store = "@" + ent.username;
        else if (ent.id) store = ent.className === "Channel" || ent.className === "Chat"
          ? "-100" + ent.id.toString().replace(/^-100/, "")
          : ent.id.toString();
        trxStore.setTestiChannel(ctx.ownerId, store);
        return _fmt.reply(event,
          `✅ <b>Channel testimoni diset!</b>\n\n` +
          `channel: <b>${esc(title)}</b>\n` +
          `tujuan: <code>${esc(store)}</code>\n\n` +
          `Sekarang kamu bisa pakai <code>${p}sharetrx &lt;nomor&gt;</code> atau reply pesan lalu <code>${p}sharetrx</code>.`);
      } catch (e) {
        return _fmt.reply(event,
          `❌ Gagal nemu channel <code>${esc(ref)}</code>.\n\n` +
          `Pastikan:\n` +
          `• Akun kamu udah <b>join/admin</b> di channel itu\n` +
          `• Username/ID/link-nya bener\n\n` +
          `<i>(${esc(e.message)})</i>`);
      }
    },
  },
  {
    name: "sharetrx",
    description: "Forward struk TRX / pesan yang di-reply ke channel testi",
    category: "Transaksi",
    handler: async (event, args, ctx) => {
      const client = ctx.client;
      const msg = event.message;
      const p = ctx.prefix || ".";

      // 1. Cek channel testi udah diset belum
      const chRef = trxStore.getTestiChannel(ctx.ownerId);
      if (!chRef) {
        return _fmt.reply(event,
          `⚠️ <b>Channel testimoni belum diatur.</b>\n\n` +
          `Set dulu pakai:\n<code>${p}addtesti &lt;@channel / id / link&gt;</code>\n\n` +
          `Contoh: <code>${p}addtesti @channeltesti</code>`);
      }

      // Resolve channel tujuan
      let target;
      try { target = await client.getEntity(chRef); }
      catch {
        return _fmt.reply(event,
          `❌ Channel testi (<code>${esc(chRef)}</code>) ga bisa diakses.\n` +
          `Set ulang pakai <code>${p}addtesti</code> (pastikan akun masih join).`);
      }

      // 2. MODE REPLY — forward pesan yang di-reply
      const replyId = msg.replyTo?.replyToMsgId;
      if (replyId) {
        try {
          await client.forwardMessages(target, { messages: [replyId], fromPeer: msg.peerId });
          return _fmt.reply(event, `✅ Pesan diforward ke channel testimoni.`);
        } catch (e) {
          return _fmt.reply(event, `❌ Gagal forward: ${esc(e.message)}`);
        }
      }

      // 3. MODE NOMOR — forward struk TRX nomor tertentu
      const num = parseInt(args[0]);
      if (isNaN(num)) {
        return _fmt.reply(event,
          `❌ Format: <code>${p}sharetrx &lt;nomor&gt;</code>\n` +
          `atau reply ke sebuah pesan terus ketik <code>${p}sharetrx</code>.`);
      }
      const rec = trxStore.getReceipt(ctx.ownerId, num);
      if (!rec) {
        return _fmt.reply(event, `❌ TRX-${num} ga ketemu. Cek lagi nomornya.`);
      }
      // Coba forward pesan struk aslinya (kalau lokasinya kesimpen)
      if (rec.chatId && rec.msgId) {
        try {
          await client.forwardMessages(target, { messages: [rec.msgId], fromPeer: rec.chatId });
          return _fmt.reply(event, `✅ Struk TRX-${num} diforward ke channel testimoni.`);
        } catch (e) {
          // lanjut ke fallback teks
        }
      }
      // Fallback: kirim ulang teks struk ke channel
      try {
        await client.sendMessage(target, { message: _fmt.wrap(rec.text), parseMode: "html" });
        return _fmt.reply(event, `✅ Struk TRX-${num} dikirim ke channel testimoni.`);
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal kirim ke channel: ${esc(e.message)}`);
      }
    },
  },
];

module.exports = { commands };
