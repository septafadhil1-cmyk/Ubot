// ─────────────────────────────────────────
//  Plugin: Pengingat Ulang Tahun — tersimpan permanen per ubot
//  .setultah <nama> <DD-MM>  → simpan tanggal ultah (mis. .setultah rafael 17-08)
//  .cekultah <nama>          → berapa hari lagi ultahnya
//  .daftarultah              → semua ultah + hitung mundur, diurut terdekat
//  .hapusultah <nama>        → hapus
//  .nextultah                → ultah terdekat yang bakal datang
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");
const esc = _fmt.esc;

let cache = null; // ownerId(str) → { list: { name: "DD-MM" } }

async function initUltah() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("ultah");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { list: d.list || {} };
      }
      console.log(`✅ [db] load ultah: ${docs.length} user`);
    } catch (e) { console.error("init ultah:", e.message); }
  }
}
function get(ownerId) { const id = String(ownerId); if (!cache) cache = {}; if (!cache[id]) cache[id] = { list: {} }; return cache[id]; }
function save(ownerId) { store.upsert("ultah", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

const BULAN = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
// Parse "17-08" / "17/8" → {d, m} (1-based), null kalau invalid
function parseDM(s) {
  const m = String(s || "").match(/^(\d{1,2})[-/](\d{1,2})$/);
  if (!m) return null;
  const d = parseInt(m[1]), mo = parseInt(m[2]);
  if (d < 1 || d > 31 || mo < 1 || mo > 12) return null;
  return { d, m: mo };
}
// Hari menuju ultah berikutnya (0 = hari ini) — pakai zona WIB
function daysUntil(dm) {
  const now = new Date(Date.now() + 7 * 3600 * 1000); // geser ke WIB
  const y = now.getUTCFullYear();
  let next = Date.UTC(y, dm.m - 1, dm.d);
  const today = Date.UTC(y, now.getUTCMonth(), now.getUTCDate());
  if (next < today) next = Date.UTC(y + 1, dm.m - 1, dm.d);
  return Math.round((next - today) / 86400000);
}
function fmtDM(dm) { return `${dm.d} ${BULAN[dm.m - 1]}`; }
function label(days) { return days === 0 ? "🎉 HARI INI!" : `${days} hari lagi`; }

module.exports.initUltah = initUltah;
module.exports.commands = [
  {
    name: "setultah", description: "Simpan ultah: .setultah <nama> <DD-MM>", category: "Ultah",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      const dm = parseDM(args[1]);
      if (!name || !dm) return _fmt.reply(event, `❌ Format: <code>.setultah &lt;nama&gt; &lt;DD-MM&gt;</code>\nContoh: <code>.setultah rafael 17-08</code>`);
      const u = get(ctx.ownerId);
      u.list[name] = `${dm.d}-${dm.m}`;
      save(ctx.ownerId);
      return _fmt.reply(event, `🎂 Ultah <b>${esc(name)}</b> diset: <b>${fmtDM(dm)}</b> (${label(daysUntil(dm))}).`);
    },
  },
  {
    name: "cekultah", description: "Cek ultah 1 orang: .cekultah <nama>", category: "Ultah",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      const u = get(ctx.ownerId);
      if (!name || !u.list[name]) return _fmt.reply(event, `❌ Ultah "${esc(name || "-")}" ga ada.`);
      const dm = parseDM(u.list[name]);
      return _fmt.reply(event, `🎂 <b>${esc(name)}</b> — ${fmtDM(dm)}\n<b>${label(daysUntil(dm))}</b>`);
    },
  },
  {
    name: "daftarultah", description: "Semua ultah (diurut terdekat)", category: "Ultah",
    handler: async (event, args, ctx) => {
      const u = get(ctx.ownerId);
      const arr = Object.entries(u.list).map(([n, s]) => ({ n, dm: parseDM(s) })).filter((x) => x.dm);
      if (!arr.length) return _fmt.reply(event, `🎂 Belum ada ultah. Simpan pakai <code>.setultah</code>.`);
      arr.sort((a, b) => daysUntil(a.dm) - daysUntil(b.dm));
      const lines = [`🎂 <b>Daftar Ultah</b> (${arr.length})`, `⏣────────────────⏣\n`];
      for (const x of arr) lines.push(`• <b>${esc(x.n)}</b> — ${fmtDM(x.dm)} (${label(daysUntil(x.dm))})`);
      return _fmt.reply(event, lines.join("\n"));
    },
  },
  {
    name: "hapusultah", description: "Hapus ultah: .hapusultah <nama>", category: "Ultah",
    handler: async (event, args, ctx) => {
      const name = (args[0] || "").toLowerCase();
      const u = get(ctx.ownerId);
      if (!name || !u.list[name]) return _fmt.reply(event, `❌ Ultah "${esc(name || "-")}" ga ada.`);
      delete u.list[name];
      save(ctx.ownerId);
      return _fmt.reply(event, `🗑 Ultah "<b>${esc(name)}</b>" dihapus.`);
    },
  },
  {
    name: "nextultah", description: "Ultah terdekat yang akan datang", category: "Ultah",
    handler: async (event, args, ctx) => {
      const u = get(ctx.ownerId);
      const arr = Object.entries(u.list).map(([n, s]) => ({ n, dm: parseDM(s) })).filter((x) => x.dm);
      if (!arr.length) return _fmt.reply(event, `🎂 Belum ada ultah tersimpan.`);
      arr.sort((a, b) => daysUntil(a.dm) - daysUntil(b.dm));
      const x = arr[0];
      return _fmt.reply(event, `⏭ <b>Ultah terdekat:</b>\n\n<b>${esc(x.n)}</b> — ${fmtDM(x.dm)}\n<b>${label(daysUntil(x.dm))}</b>`);
    },
  },
];
