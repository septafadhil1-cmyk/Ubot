// Kasera Pay wallet top-up
// .pay <nominal> [qris|va]  → create invoice
// .wallet                  → view wallet balance
// .paystatus [order_id]    → view payment status / recent transactions
const _fmt = require('./_format');
const payment = require('../lib/kaseraWallet');
const QRCode = require('qrcode');
const fs = require('fs');
const os = require('os');
const path = require('path');

const esc = _fmt.esc;
function rp(n) { return 'Rp' + Number(n || 0).toLocaleString('id-ID'); }
function parseAmount(raw) {
  if (!raw) return null;
  const s = String(raw).toLowerCase().replace(/\s+/g, '');
  const m = s.match(/^([\d.,]+)(rb|ribu|k|jt|juta|m)?$/);
  if (!m) return null;
  let n = m[2] ? Number(m[1].replace(',', '.')) : Number(m[1].replace(/[.,]/g, ''));
  if (!Number.isFinite(n)) return null;
  if (['rb', 'ribu', 'k'].includes(m[2])) n *= 1000;
  if (['jt', 'juta', 'm'].includes(m[2])) n *= 1000000;
  n = Math.round(n);
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}

module.exports.commands = [
  {
    name: 'pay',
    description: 'Top up saldo otomatis via Kasera Pay: .pay 50000 [qris|va]',
    category: 'Keuangan',
    handler: async (event, args, ctx) => {
      const p = ctx.prefix || '.';
      const amount = parseAmount(args[0]);
      const method = String(args[1] || 'qris').toLowerCase();
      if (!amount || !['qris', 'va'].includes(method)) {
        return _fmt.reply(event, `💳 <b>Top Up Saldo</b>\n\nFormat: <code>${p}pay &lt;nominal&gt; [qris|va]</code>\nContoh: <code>${p}pay 50000</code> atau <code>${p}pay 50k va</code>`);
      }
      try {
        const order = await payment.createInvoice({ userId: ctx.ownerId, amount, method });
        const caption =
          `💳 <b>INVOICE TOP UP SALDO</b>\n` +
          `━━━━━━━━━━━━━━━━━━\n` +
          `Order: <code>${esc(order.id)}</code>\n` +
          `Nominal: <b>${rp(order.amount)}</b>\n` +
          `Metode: <b>${method === 'va' ? 'Virtual Account' : 'QRIS'}</b>\n` +
          `Status: <b>MENUNGGU PEMBAYARAN</b>\n` +
          (order.expiresAt ? `Kedaluwarsa: <code>${esc(String(order.expiresAt))}</code>\n` : '') + '\n';
        if (order.qrString && method === 'qris') {
          const file = path.join(os.tmpdir(), `${order.id}.png`);
          await QRCode.toFile(file, order.qrString, { width: 520, margin: 2 });
          try {
            await ctx.client.sendFile(event.message.peerId, {
              file,
              caption: caption + `Scan QRIS di atas untuk membayar.\nSetelah bayar, saldo bertambah otomatis setelah webhook terverifikasi.\n\nCek status: <code>${p}paystatus ${esc(order.id)}</code>`,
              parseMode: 'html',
              replyTo: event.message.id,
            });
          } finally { try { fs.unlinkSync(file); } catch {} }
        } else {
          const lines = [caption];
          if (order.vaNumber) lines.push(`Nomor VA: <code>${esc(order.vaNumber)}</code>\n`);
          if (order.paymentUrl) lines.push(`Link pembayaran: ${esc(order.paymentUrl)}\n`);
          lines.push(`Buka link pembayaran untuk menyelesaikan transaksi.\nCek status: <code>${p}paystatus ${esc(order.id)}</code>`);
          return _fmt.reply(event, lines.join('\n'));
        }
      } catch (e) {
        return _fmt.reply(event, `❌ <b>Gagal membuat invoice</b>\n${esc(e.message || 'Kesalahan tidak diketahui')}\n\nPastikan KASERA_API_KEY, KASERA_WEBHOOK_SECRET, dan URL webhook sudah dikonfigurasi.`);
      }
    },
  },
  {
    name: 'wallet',
    description: 'Lihat saldo wallet dari pembayaran otomatis',
    category: 'Keuangan',
    handler: async (event, args, ctx) => {
      try {
        const wallet = await payment.getWallet(ctx.ownerId);
        const paid = (wallet.transactions || []).filter(t => t.status === 'paid');
        const total = paid.reduce((sum, t) => sum + Number(t.amount || 0), 0);
        return _fmt.reply(event,
          `👛 <b>WALLET SALDO</b>\n━━━━━━━━━━━━━━━━━━\n` +
          `Saldo: <b>${rp(wallet.balance)}</b>\n` +
          `Total top up terverifikasi: <b>${rp(total)}</b>\n` +
          `Transaksi sukses: <b>${paid.length}</b>\n\n` +
          `Top up: <code>${ctx.prefix || '.'}pay 50000</code>`);
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal mengambil saldo: ${esc(e.message)}`);
      }
    },
  },
  {
    name: 'paystatus',
    description: 'Cek status invoice: .paystatus [order_id]',
    category: 'Keuangan',
    handler: async (event, args, ctx) => {
      try {
        if (args[0]) {
          const order = await payment.statusForUser(args[0], ctx.ownerId);
          if (!order) return _fmt.reply(event, '❌ Invoice tidak ditemukan atau bukan milik wallet ini.');
          return _fmt.reply(event,
            `🧾 <b>STATUS PEMBAYARAN</b>\n━━━━━━━━━━━━━━━━━━\n` +
            `Order: <code>${esc(order.id)}</code>\n` +
            `Nominal: <b>${rp(order.amount)}</b>\n` +
            `Metode: <b>${esc(String(order.method || '-').toUpperCase())}</b>\n` +
            `Status: <b>${esc(String(order.status || 'unknown').toUpperCase())}</b>\n` +
            (order.status === 'paid' ? 'Saldo sudah ditambahkan.' : order.paymentUrl ? `\nLink pembayaran: ${esc(order.paymentUrl)}` : ''));
        }
        const wallet = await payment.getWallet(ctx.ownerId);
        const txs = (wallet.transactions || []).slice(-5).reverse();
        if (!txs.length) return _fmt.reply(event, `Belum ada transaksi wallet. Mulai dengan <code>${ctx.prefix || '.'}pay 50000</code>.`);
        const lines = txs.map(t => `• <code>${esc(t.orderId)}</code> — ${rp(t.amount)} — <b>${esc(String(t.status || 'unknown').toUpperCase())}</b>`);
        return _fmt.reply(event, `🧾 <b>5 TRANSAKSI TERAKHIR</b>\n━━━━━━━━━━━━━━━━━━\n${lines.join('\n')}\n\nCek detail: <code>${ctx.prefix || '.'}paystatus &lt;order_id&gt;</code>`);
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal cek status: ${esc(e.message)}`);
      }
    },
  },
];
