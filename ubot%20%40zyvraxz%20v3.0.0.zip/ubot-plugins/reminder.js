// ─────────────────────────────────────────
//  Plugin: Pengingat (reminder terjadwal) — tersimpan permanen & tahan restart
//  .remind <durasi> <pesan>  → mis. .remind 10m minum obat / .remind 2jam meeting
//     unit: s/detik, m/menit, h/j/jam, d/hari
//  .reminders                → daftar pengingat yang masih nunggu
//  .delremind <no>           → batalkan 1 pengingat
//  .clearremind              → batalkan semua
//  .snooze <durasi>          → ingatkan lagi pengingat terakhir setelah <durasi>
//  Pengingat dikirim ke Pesan Tersimpan (Saved Messages) pas waktunya tiba.
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");
const esc = _fmt.esc;

let cache = null; // ownerId(str) → { items: [{id, fireAt, text}] }
const timers = new Map();       // id → setTimeout handle
const clientByOwner = new Map(); // ownerId → client (buat kirim pas fire)
const lastFired = new Map();     // ownerId → text terakhir (buat .snooze)

async function initReminder() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("reminder");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { items: Array.isArray(d.items) ? d.items : [] };
      }
      console.log(`✅ [db] load reminder: ${docs.length} user`);
    } catch (e) { console.error("init reminder:", e.message); }
  }
}
function get(ownerId) { const id = String(ownerId); if (!cache) cache = {}; if (!cache[id]) cache[id] = { items: [] }; return cache[id]; }
function save(ownerId) { store.upsert("reminder", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

function parseDur(s) {
  const m = String(s || "").toLowerCase().match(/^(\d+)\s*(detik|menit|jam|hari|s|m|h|j|d)$/);
  if (!m) return null;
  const n = parseInt(m[1]), u = m[2];
  if (u === "s" || u === "detik") return n * 1000;
  if (u === "m" || u === "menit") return n * 60000;
  if (u === "h" || u === "j" || u === "jam") return n * 3600000;
  if (u === "d" || u === "hari") return n * 86400000;
  return null;
}
function fmtLeft(ms) {
  if (ms < 0) ms = 0;
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s} detik`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m} menit`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} jam`;
  return `${Math.round(h / 24)} hari`;
}

// Kirim pengingat pas waktunya (ke Saved Messages)
async function fire(ownerId, item) {
  const client = clientByOwner.get(String(ownerId));
  // Hapus dari store dulu (biar ga dobel pas restart)
  const box = get(ownerId);
  box.items = box.items.filter((x) => x.id !== item.id);
  save(ownerId);
  timers.delete(item.id);
  lastFired.set(String(ownerId), item.text);
  if (!client) return;
  try {
    await client.sendMessage("me", { message: `⏰ <b>PENGINGAT</b>\n\n${esc(item.text)}`, parseMode: "html" });
  } catch (e) { console.error("reminder fire:", e.message); }
}

function scheduleOne(ownerId, item) {
  if (timers.has(item.id)) return;
  const delay = Math.max(0, item.fireAt - Date.now());
  // setTimeout max ~24.8 hari; batasi biar aman, reschedule ntar via reschedule saat boot
  const t = setTimeout(() => fire(ownerId, item), Math.min(delay, 2 ** 31 - 1));
  timers.set(item.id, t);
}

// Dipanggil ubotManager pas ubot start: simpan client + jadwalin ulang pengingat tersimpan
function rescheduleForOwner(client, ownerId) {
  clientByOwner.set(String(ownerId), client);
  const box = get(ownerId);
  for (const item of box.items) scheduleOne(ownerId, item);
}

module.exports.initReminder = initReminder;
module.exports.rescheduleForOwner = rescheduleForOwner;
module.exports.commands = [
  {
    name: "remind", description: "Pengingat terjadwal: .remind <durasi> <pesan> (mis. .remind 10m minum obat)", category: "Pengingat",
    handler: async (event, args, ctx) => {
      clientByOwner.set(String(ctx.ownerId), ctx.client);
      const ms = parseDur(args[0]);
      const text = args.slice(1).join(" ").trim();
      if (!ms || !text) return _fmt.reply(event, `❌ Format: <code>.remind &lt;durasi&gt; &lt;pesan&gt;</code>\nContoh: <code>.remind 10m minum obat</code> (unit: s/m/h/d)`);
      const item = { id: Date.now().toString(36) + Math.floor(Math.random() * 1000).toString(36), fireAt: Date.now() + ms, text };
      const box = get(ctx.ownerId);
      box.items.push(item);
      save(ctx.ownerId);
      scheduleOne(ctx.ownerId, item);
      return _fmt.reply(event, `⏰ Oke! Diingetin <b>${fmtLeft(ms)}</b> lagi:\n<i>${esc(text)}</i>\n\n<i>Pengingat masuk ke Pesan Tersimpan.</i>`);
    },
  },
  {
    name: "reminders", description: "Daftar pengingat yang masih nunggu", category: "Pengingat",
    handler: async (event, args, ctx) => {
      const box = get(ctx.ownerId);
      const now = Date.now();
      const pending = box.items.filter((x) => x.fireAt > now).sort((a, b) => a.fireAt - b.fireAt);
      if (!pending.length) return _fmt.reply(event, `⏰ Ga ada pengingat aktif. Bikin pakai <code>.remind</code>.`);
      const lines = [`⏰ <b>Pengingat Aktif</b> (${pending.length})`, `⏣────────────────⏣\n`];
      pending.forEach((x, i) => lines.push(`<b>#${i + 1}</b> (${fmtLeft(x.fireAt - now)} lagi) — ${esc(x.text)}`));
      return _fmt.reply(event, lines.join("\n"));
    },
  },
  {
    name: "delremind", description: "Batalkan 1 pengingat: .delremind <no>", category: "Pengingat",
    handler: async (event, args, ctx) => {
      const no = parseInt(args[0]);
      const box = get(ctx.ownerId);
      const now = Date.now();
      const pending = box.items.filter((x) => x.fireAt > now).sort((a, b) => a.fireAt - b.fireAt);
      if (isNaN(no) || no < 1 || no > pending.length) return _fmt.reply(event, `❌ Nomor tidak valid. Lihat <code>.reminders</code>.`);
      const target = pending[no - 1];
      box.items = box.items.filter((x) => x.id !== target.id);
      save(ctx.ownerId);
      if (timers.has(target.id)) { clearTimeout(timers.get(target.id)); timers.delete(target.id); }
      return _fmt.reply(event, `🗑 Pengingat #${no} (${esc(target.text)}) dibatalkan.`);
    },
  },
  {
    name: "clearremind", description: "Batalkan semua pengingat", category: "Pengingat",
    handler: async (event, args, ctx) => {
      const box = get(ctx.ownerId);
      const n = box.items.length;
      for (const x of box.items) { if (timers.has(x.id)) { clearTimeout(timers.get(x.id)); timers.delete(x.id); } }
      box.items = [];
      save(ctx.ownerId);
      return _fmt.reply(event, `🧹 <b>${n} pengingat dibatalkan.</b>`);
    },
  },
  {
    name: "snooze", description: "Ingatkan lagi pengingat terakhir: .snooze <durasi>", category: "Pengingat",
    handler: async (event, args, ctx) => {
      clientByOwner.set(String(ctx.ownerId), ctx.client);
      const ms = parseDur(args[0]);
      if (!ms) return _fmt.reply(event, `❌ Format: <code>.snooze &lt;durasi&gt;</code> (mis. <code>.snooze 5m</code>)`);
      const text = lastFired.get(String(ctx.ownerId));
      if (!text) return _fmt.reply(event, `❌ Belum ada pengingat yang berbunyi buat di-snooze.`);
      const item = { id: Date.now().toString(36) + Math.floor(Math.random() * 1000).toString(36), fireAt: Date.now() + ms, text };
      const box = get(ctx.ownerId);
      box.items.push(item);
      save(ctx.ownerId);
      scheduleOne(ctx.ownerId, item);
      return _fmt.reply(event, `😴 Oke, diingetin lagi <b>${fmtLeft(ms)}</b> lagi:\n<i>${esc(text)}</i>`);
    },
  },
];
