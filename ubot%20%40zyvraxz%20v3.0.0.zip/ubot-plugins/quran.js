// ─────────────────────────────────────────
//  Plugin: Al Quran (API equran.id — gratis, tanpa key)
// ─────────────────────────────────────────

const _fmt = require("./_format");

// Helper fetch JSON dengan timeout
async function fetchJson(url, timeout = 15000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { "User-Agent": "UBotManager/1.0" } });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return await res.json();
  } finally { clearTimeout(t); }
}

const commands = [
  {
    name: "alquran",
    description: "Baca ayat Al-Quran (.alquran <surah> [ayat]) cth: .alquran 1 2",
    category: "Islami",
    handler: async (event, args) => {
      const surah = parseInt(args[0]);
      const ayat = args[1] ? parseInt(args[1]) : null;
      if (isNaN(surah) || surah < 1 || surah > 114) {
        return _fmt.reply(event, `❌ Format: <code>.alquran 1 2</code>\n(surah 1-114, ayat opsional)`);
      }
      try {
        const data = await fetchJson(`https://equran.id/api/v2/surat/${surah}`);
        const d = data.data;
        if (!d) return _fmt.reply(event, `❌ Surah tidak ditemukan.`);

        if (ayat) {
          const a = d.ayat.find(x => x.nomorAyat === ayat);
          if (!a) return _fmt.reply(event, `❌ Ayat ${ayat} tidak ada di surah ${d.namaLatin} (max ${d.jumlahAyat}).`);
          return _fmt.reply(event,
            `📖 <b>${d.namaLatin} : ${ayat}</b> (${d.arti})\n\n` +
            `${a.teksArab}\n\n` +
            `<i>${_fmt.esc(a.teksLatin)}</i>\n\n` +
            `🇮🇩 ${_fmt.esc(a.teksIndonesia)}`
          );
        }
        // Info surah saja
        return _fmt.reply(event,
          `📖 <b>Surah ${d.nomor}: ${d.namaLatin}</b>\n` +
          `${d.nama} — ${d.arti}\n\n` +
          `<b>Jumlah ayat:</b> ${d.jumlahAyat}\n` +
          `<b>Tempat turun:</b> ${d.tempatTurun}\n\n` +
          `<i>Baca ayat: <code>.alquran ${d.nomor} 1</code></i>`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal ambil data Quran: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "tafsir",
    description: "Tafsir ayat Al-Quran (.tafsir <surah> <ayat>)",
    category: "Islami",
    handler: async (event, args) => {
      const surah = parseInt(args[0]);
      const ayat = parseInt(args[1]);
      if (isNaN(surah) || isNaN(ayat)) {
        return _fmt.reply(event, `❌ Format: <code>.tafsir 1 1</code>`);
      }
      try {
        const data = await fetchJson(`https://equran.id/api/v2/tafsir/${surah}`);
        const t = data.data?.tafsir?.find(x => x.ayat === ayat);
        if (!t) return _fmt.reply(event, `❌ Tafsir tidak ditemukan.`);
        let teks = t.teks;
        if (teks.length > 3000) teks = teks.slice(0, 3000) + "...";
        return _fmt.reply(event,
          `📚 <b>Tafsir ${data.data.namaLatin} : ${ayat}</b>\n\n${_fmt.esc(teks)}`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal ambil tafsir: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "surah",
    description: "Info surah Al-Quran (.surah <nomor>)",
    category: "Islami",
    handler: async (event, args) => {
      const surah = parseInt(args[0]);
      if (isNaN(surah) || surah < 1 || surah > 114) {
        return _fmt.reply(event, `❌ Format: <code>.surah 2</code> (1-114)`);
      }
      try {
        const data = await fetchJson(`https://equran.id/api/v2/surat/${surah}`);
        const d = data.data;
        return _fmt.reply(event,
          `📖 <b>Surah ${d.nomor}: ${d.namaLatin}</b>\n` +
          `${d.nama}\n\n` +
          `<b>Arti:</b> ${d.arti}\n` +
          `<b>Jumlah ayat:</b> ${d.jumlahAyat}\n` +
          `<b>Tempat turun:</b> ${d.tempatTurun}\n` +
          `<b>Urutan turun:</b> ${d.deskripsi ? "" : ""}${d.nomor}`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "sholat",
    description: "Jadwal sholat kota (.sholat <kota>) cth: .sholat Jakarta",
    category: "Islami",
    handler: async (event, args) => {
      const kota = args.join(" ") || "Jakarta";
      try {
        const data = await fetchJson(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(kota)}&country=Indonesia&method=11`);
        const t = data.data?.timings;
        if (!t) return _fmt.reply(event, `❌ Kota tidak ditemukan.`);
        const tgl = data.data.date?.readable || "";
        return _fmt.reply(event,
          `🕌 <b>Jadwal Sholat ${_fmt.esc(kota)}</b>\n` +
          `${tgl}\n\n` +
          `<b>Subuh:</b> ${t.Fajr}\n` +
          `<b>Terbit:</b> ${t.Sunrise}\n` +
          `<b>Dzuhur:</b> ${t.Dhuhr}\n` +
          `<b>Ashar:</b> ${t.Asr}\n` +
          `<b>Maghrib:</b> ${t.Maghrib}\n` +
          `<b>Isya:</b> ${t.Isha}`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal ambil jadwal: ${_fmt.esc(e.message)}`);
      }
    },
  },
];

module.exports.commands = commands;
