// ─────────────────────────────────────────
//  Plugin: Profile Photo
//  .pp              — foto profil diri sendiri
//  .pp @username    — foto profil orang lain
//  .pp              + reply ke pesan = foto profil pengirim pesan itu
// ─────────────────────────────────────────
const _fmt = require("./_format");

const { Api } = require("telegram");
const fs = require("fs");
const path = require("path");
const os = require("os");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}


async function reply(event, html) {
  return _fmt.reply(event, html);
}

module.exports.commands = [
  {
    name: "pp",
    description: "Ambil foto profil seseorang",
    usage: ".pp [@username] | reply pesan → foto profil pengirimnya",
    category: "Utilitas",
    handler: async (event, args) => {
      const msg = event.message;
      const client = msg.client;
      let target = null;
      let targetName = "";

      try {
        if (args[0]) {
          const username = args[0].replace("@", "");
          target = await client.getEntity(username);
          targetName = target.firstName || target.title || username;
        } else if (msg.replyTo) {
          const replied = await msg.getReplyMessage();
          const sender = await replied.getSender();
          target = sender;
          targetName = sender?.firstName || sender?.title || "Unknown";
        } else {
          target = await client.getMe();
          targetName = target.firstName || "Kamu";
        }

        if (!target) throw new Error("Target tidak ditemukan");

        // Download foto profil ke buffer
        const buffer = await client.downloadProfilePhoto(target, { isBig: true });

        if (!buffer || buffer.length === 0) {
          return msg.reply({
            message: `<blockquote><b>😶 <b>${esc(targetName)}</b> tidak punya foto profil.</b></blockquote>`,
            parseMode: "html",
          });
        }

        // Simpan buffer ke file .jpg sementara biar GramJS tau ini gambar
        const tmpPath = path.join(os.tmpdir(), `pp_${target.id}_${Date.now()}.jpg`);
        fs.writeFileSync(tmpPath, buffer);

        const caption =
          `<blockquote><b>🖼️ <b>Foto Profil</b>\n\n` +
          `Nama: <b>${esc(targetName)}</b>\n` +
          `ID: <code>${target.id}</code>` +
          `${target.username ? `\nUsername: @${esc(target.username)}` : ""}</b></blockquote>`;

        await client.sendFile(msg.peerId, {
          file: tmpPath,
          caption,
          parseMode: "html",
          replyTo: msg.id,
          forceDocument: false,
        });

        // Hapus file temp
        fs.unlinkSync(tmpPath);

      } catch (e) {
        console.error("PP error:", e.message);
        return msg.reply({
          message: `<blockquote><b>❌ Gagal: ${esc(e.message)}</b></blockquote>`,
          parseMode: "html",
        });
      }
    },
  },
];
