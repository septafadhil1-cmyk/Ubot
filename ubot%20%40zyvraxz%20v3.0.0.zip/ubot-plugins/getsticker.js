// ─────────────────────────────────────────
//  Plugin: Get Sticker
//  .getsticker / .stiker   → reply gambar, ubah jadi stiker
//  Reply foto/gambar lalu ketik command
// ─────────────────────────────────────────
const _fmt = require("./_format");

const { Api } = require("telegram");
const { createCanvas, loadImage } = require("@napi-rs/canvas");
const fs = require("fs");
const path = require("path");
const os = require("os");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Resize gambar ke 512x512 (rasio dijaga, transparan di sisanya)
async function toSticker(imageBuffer) {
  const img = await loadImage(imageBuffer);
  const SIZE = 512;

  const canvas = createCanvas(SIZE, SIZE);
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, SIZE, SIZE);

  // Hitung scale biar muat dalam 512x512 tanpa distorsi
  const scale = Math.min(SIZE / img.width, SIZE / img.height);
  const w = img.width * scale;
  const h = img.height * scale;
  const x = (SIZE - w) / 2;
  const y = (SIZE - h) / 2;

  ctx.drawImage(img, x, y, w, h);
  return canvas.toBuffer("image/webp");
}


async function reply(event, html) {
  return _fmt.reply(event, html);
}

module.exports.commands = [
  {
    name: "getsticker",
    description: "Ubah gambar yang di-reply jadi stiker",
    usage: ".getsticker (reply ke gambar)",
    category: "Fun",
    handler: async (event) => {
      const msg = event.message;
      const client = msg.client;

      if (!msg.replyTo) {
        return msg.reply({
          message: `<blockquote><b>❌ Reply ke sebuah gambar/foto dulu, lalu ketik <code>.getsticker</code></b></blockquote>`,
          parseMode: "html",
        });
      }

      try {
        const replied = await msg.getReplyMessage();

        // Cek apakah ada media gambar
        const hasPhoto = replied?.photo;
        const hasImageDoc = replied?.document?.mimeType?.startsWith("image/");

        if (!hasPhoto && !hasImageDoc) {
          return msg.reply({
            message: `<blockquote><b>❌ Pesan yang di-reply bukan gambar.</b></blockquote>`,
            parseMode: "html",
          });
        }

        // Download gambar
        const imageBuffer = await client.downloadMedia(replied, {});
        if (!imageBuffer || imageBuffer.length === 0) {
          return msg.reply({
            message: `<blockquote><b>❌ Gagal download gambar.</b></blockquote>`,
            parseMode: "html",
          });
        }

        // Convert ke sticker webp 512x512
        const stickerBuffer = await toSticker(imageBuffer);
        const tmpPath = path.join(os.tmpdir(), `sticker_${Date.now()}.webp`);
        fs.writeFileSync(tmpPath, stickerBuffer);

        await client.sendFile(msg.peerId, {
          file: tmpPath,
          replyTo: replied.id,
          forceDocument: false,
          attributes: [
            new Api.DocumentAttributeSticker({
              alt: "🖼️",
              stickerset: new Api.InputStickerSetEmpty(),
            }),
          ],
        });

        fs.unlinkSync(tmpPath);
      } catch (e) {
        console.error("getsticker error:", e.message);
        return msg.reply({
          message: `<blockquote><b>❌ Gagal: ${esc(e.message)}</b></blockquote>`,
          parseMode: "html",
        });
      }
    },
  },
];
