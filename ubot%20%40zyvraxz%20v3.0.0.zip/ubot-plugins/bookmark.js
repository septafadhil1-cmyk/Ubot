// ─────────────────────────────────────────
//  Plugin: Bookmark pesan — simpan pesan penting + link buat balik lagi
//  .bookmark <catatan>   → simpan (reply pesan buat nyimpen link ke pesan itu)
//  .bookmarks            → daftar bookmark (dengan link kalau ada)
//  .delbookmark <no>     → hapus 1 bookmark
//  .clearbookmark        → hapus semua bookmark
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");
const esc = _fmt.esc;

let cache = null; // ownerId(str) → { items: [{note, link, snippet, ts}] }

async function initBookmark() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("bookmark");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { items: Array.isArray(d.items) ? d.items : [] };
      }
      console.log(`✅ [db] load bookmark: ${docs.length} user`);
    } catch (e) { console.error("init bookmark:", e.message); }
  }
}
function get(ownerId) { const id = String(ownerId); if (!cache) cache = {}; if (!cache[id]) cache[id] = { items: [] }; return cache[id]; }
function save(ownerId) { store.upsert("bookmark", String(ownerId), cache[String(ownerId)]).catch(() => {}); }
function tgl(ts) { return new Date(ts).toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta" }); }

// Coba bangun link t.me ke pesan yang di-reply
async function buildLink(event) {
  try {
    const msg = event.message;
    if (!msg.replyTo) return { link: "", snippet: "" };
    const r = await msg.getReplyMessage();
    if (!r) return { link: "", snippet: "" };
    const snippet = (r.text || r.message || "").slice(0, 60);
    let link = "";
    try {
      const chat = await r.getChat();
      if (chat && chat.username) link = `https://t.me/${chat.username}/${r.id}`;
      else if (chat && (chat.className === "Channel")) link = `https://t.me/c/${String(chat.id).replace(/^-100/, "")}/${r.id}`;
    } catch {}
    return { link, snippet };
  } catch { return { link: "", snippet: "" }; }
}

module.exports.initBookmark = initBookmark;
module.exports.commands = [
  {
    name: "bookmark", description: "Simpan bookmark: .bookmark <catatan> (reply pesan buat link)", category: "Bookmark",
    handler: async (event, args, ctx) => {
      const note = args.join(" ").trim();
      const { link, snippet } = await buildLink(event);
      if (!note && !snippet) return _fmt.reply(event, `❌ Kasih catatan atau reply pesan yang mau di-bookmark.`);
      const b = get(ctx.ownerId);
      b.items.push({ note: note || "(tanpa catatan)", link, snippet, ts: Date.now() });
      save(ctx.ownerId);
      return _fmt.reply(event, `🔖 Bookmark #${b.items.length} tersimpan.${link ? `\n🔗 ${esc(link)}` : ""}`);
    },
  },
  {
    name: "bookmarks", description: "Daftar semua bookmark", category: "Bookmark",
    handler: async (event, args, ctx) => {
      const b = get(ctx.ownerId);
      if (!b.items.length) return _fmt.reply(event, `🔖 Belum ada bookmark. Simpan pakai <code>.bookmark</code>.`);
      const lines = [`🔖 <b>Bookmark</b> (${b.items.length})`, `⏣────────────────⏣\n`];
      b.items.forEach((it, i) => {
        lines.push(`<b>#${i + 1}</b> ${esc(it.note)}${it.snippet ? `\n     <i>“${esc(it.snippet)}”</i>` : ""}${it.link ? `\n     🔗 ${esc(it.link)}` : ""}\n     <i>${tgl(it.ts)}</i>`);
      });
      return _fmt.reply(event, lines.join("\n"));
    },
  },
  {
    name: "delbookmark", description: "Hapus 1 bookmark: .delbookmark <no>", category: "Bookmark",
    handler: async (event, args, ctx) => {
      const no = parseInt(args[0]);
      const b = get(ctx.ownerId);
      if (isNaN(no) || no < 1 || no > b.items.length) return _fmt.reply(event, `❌ Nomor tidak valid. Lihat <code>.bookmarks</code>.`);
      const rm = b.items.splice(no - 1, 1)[0];
      save(ctx.ownerId);
      return _fmt.reply(event, `🗑 Bookmark #${no} (${esc(rm.note)}) dihapus.`);
    },
  },
  {
    name: "clearbookmark", description: "Hapus semua bookmark", category: "Bookmark",
    handler: async (event, args, ctx) => {
      const b = get(ctx.ownerId);
      const n = b.items.length;
      b.items = [];
      save(ctx.ownerId);
      return _fmt.reply(event, `🧹 <b>${n} bookmark dihapus.</b>`);
    },
  },
];
