// ─────────────────────────────────────────
//  Plugin: QR Code
//  .qr <teks/link>   → generate QR code
//  .qr               + reply pesan = QR dari pesan itu
// ─────────────────────────────────────────
const _fmt = require("./_format");

const QRCode = require("qrcode");
const fs = require("fs");
const path = require("path");
const os = require("os");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}


async function reply(event, html) {
  return _fmt.reply(event, html);
}

module.exports.commands = [
  {
    name: "qr",
    description: "Generate QR code dari teks atau link",
    usage: ".qr <teks/link> | reply pesan lalu .qr",
    category: "Utilitas",
    handler: async (event, args) => {
      const msg = event.message;
      const client = msg.client;

      let text = args.join(" ");

      // Kalau kosong, ambil dari reply
      if (!text && msg.replyTo) {
        const replied = await msg.getReplyMessage();
        text = replied?.text || "";
      }

      if (!text) {
        return msg.reply({
          message:
            `<blockquote><b>❌ <b>Cara pakai:</b>\n\n` +
            `• <code>.qr https://google.com</code>\n` +
            `• <code>.qr Halo dunia!</code>\n` +
            `• Reply pesan lalu <code>.qr</code></b></blockquote>`,
          parseMode: "html",
        });
      }

      if (text.length > 1000) {
        return msg.reply({
          message: `<blockquote><b>❌ Teks terlalu panjang (max 1000 karakter).</b></blockquote>`,
          parseMode: "html",
        });
      }

      try {
        const tmpPath = path.join(os.tmpdir(), `qr_${Date.now()}.png`);

        // Generate QR dengan margin & warna custom
        await QRCode.toFile(tmpPath, text, {
          width: 512,
          margin: 2,
          color: {
            dark: "#000000",
            light: "#FFFFFF",
          },
          errorCorrectionLevel: "H",
        });

        await client.sendFile(msg.peerId, {
          file: tmpPath,
          caption: `<blockquote><b>📱 <b>QR Code</b>\n\n<b>Isi:</b> ${esc(text.slice(0, 100))}${text.length > 100 ? "..." : ""}</b></blockquote>`,
          parseMode: "html",
          replyTo: msg.id,
          forceDocument: false,
        });

        fs.unlinkSync(tmpPath);
      } catch (e) {
        console.error("qr error:", e.message);
        return msg.reply({
          message: `<blockquote><b>❌ Gagal generate QR: ${esc(e.message)}</b></blockquote>`,
          parseMode: "html",
        });
      }
    },
  },
];
