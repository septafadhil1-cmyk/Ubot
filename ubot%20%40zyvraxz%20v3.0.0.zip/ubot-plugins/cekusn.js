// ─────────────────────────────────────────
//  Plugin: Cek riwayat username (.cekusn <id>)
//  Data dari observasi pasif (lib/usnHistory.js) — FORWARD-LOOKING, bukan retroaktif.
//  Telegram ga punya API resmi buat narik riwayat username orang yang belum pernah
//  "ketemu" ubot kita (chat/grup bareng). Mulai dari fitur ini aktif, makin sering
//  ubot ketemu orangnya, makin lengkap datanya.
// ─────────────────────────────────────────
const usnHistory = require("../lib/usnHistory");
const _fmt = require("./_format");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

module.exports.commands = [
  {
    name: "cekusn",
    description: "Cek riwayat username yang pernah dipakai user (.cekusn <id>)",
    category: "Utilitas",
    handler: async (event, args, ctx) => {
      let id = (args[0] || "").trim();
      // Boleh juga reply ke pesan orangnya tanpa kasih ID
      if (!id && event.message?.replyTo?.replyToMsgId) {
        try {
          const replied = await event.message.getReplyMessage();
          if (replied?.senderId) id = replied.senderId.toString();
        } catch {}
      }
      id = id.replace(/[^0-9]/g, "");
      if (!id) {
        return _fmt.reply(event,
          `❌ Pakai: <code>.cekusn &lt;id&gt;</code> atau reply pesan orangnya + <code>.cekusn</code>\n` +
          `Contoh: <code>.cekusn 123456789</code>`
        );
      }

      const entries = usnHistory.getHistory(id);
      if (!entries.length) {
        return _fmt.reply(event,
          `📭 <b>Belum ada riwayat username</b> buat ID <code>${esc(id)}</code>.\n\n` +
          `<i>Catatan: ubot cuma nyatet username yang KETAHUAN pas ketemu orangnya (chat/grup bareng). ` +
          `Telegram ga punya cara buat narik riwayat username orang yang belum pernah ketemu ubot kita.</i>`
        );
      }

      const lines = entries.map((e, i) => {
        const d = new Date(e.first).toLocaleDateString("id-ID", { day: "2-digit", month: "2-digit", year: "numeric" });
        return `${i + 1}. @${esc(e.username)} <i>— ketahuan sejak ${d}</i>`;
      });

      return _fmt.reply(event,
        `🔎 <b>Riwayat Username</b> — ID <code>${esc(id)}</code>\n\n` +
        `${lines.join("\n")}\n\n` +
        `<i>Total ${entries.length} username tercatat (sejak fitur ini aktif & ubot pernah ketemu orangnya).</i>`
      );
    },
  },
];
