// ─────────────────────────────────────────
//  Plugin: Alias command — bikin singkatan perintah sendiri
//  .setalias <alias> <command...>  → mis. .setalias p ping  → .p = .ping
//  .aliases                        → daftar alias
//  .delalias <alias>               → hapus 1 alias
//  .clearalias                     → hapus semua alias
//  Alias di-expand ubotManager SEBELUM cari command (alias ga bisa nimpa command asli).
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");
const esc = _fmt.esc;

let cache = null; // ownerId(str) → { map: { alias: "target args" } }

async function initAlias() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("alias");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { map: d.map || {} };
      }
      console.log(`✅ [db] load alias: ${docs.length} user`);
    } catch (e) { console.error("init alias:", e.message); }
  }
}
function get(ownerId) { const id = String(ownerId); if (!cache) cache = {}; if (!cache[id]) cache[id] = { map: {} }; return cache[id]; }
function save(ownerId) { store.upsert("alias", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

// Dipanggil ubotManager: alias name → target string ("ping" / "cfd 10") atau null
function resolve(ownerId, name) {
  const c = cache && cache[String(ownerId)];
  if (!c || !c.map) return null;
  return c.map[String(name).toLowerCase()] || null;
}

module.exports.initAlias = initAlias;
module.exports.resolve = resolve;
module.exports.commands = [
  {
    name: "setalias", description: "Bikin alias: .setalias <alias> <command...>", category: "Alias",
    handler: async (event, args, ctx) => {
      const alias = (args[0] || "").toLowerCase();
      const target = args.slice(1).join(" ").trim();
      if (!alias || !target) return _fmt.reply(event, `❌ Format: <code>.setalias &lt;alias&gt; &lt;command&gt;</code>\nContoh: <code>.setalias p ping</code>`);
      if (ctx.ubotPlugins && ctx.ubotPlugins.has(alias)) {
        return _fmt.reply(event, `❌ "<b>${esc(alias)}</b>" itu nama command asli, ga bisa dipakai jadi alias.`);
      }
      const a = get(ctx.ownerId);
      a.map[alias] = target;
      save(ctx.ownerId);
      return _fmt.reply(event, `✅ Alias dibuat: <code>${ctx.prefix || "."}${esc(alias)}</code> → <code>${ctx.prefix || "."}${esc(target)}</code>`);
    },
  },
  {
    name: "aliases", description: "Daftar semua alias", category: "Alias",
    handler: async (event, args, ctx) => {
      const a = get(ctx.ownerId);
      const keys = Object.keys(a.map);
      if (!keys.length) return _fmt.reply(event, `🔗 Belum ada alias. Bikin pakai <code>.setalias</code>.`);
      const p = ctx.prefix || ".";
      return _fmt.reply(event, `🔗 <b>Alias</b> (${keys.length})\n\n` + keys.map((k) => `• <code>${p}${esc(k)}</code> → <code>${p}${esc(a.map[k])}</code>`).join("\n"));
    },
  },
  {
    name: "delalias", description: "Hapus alias: .delalias <alias>", category: "Alias",
    handler: async (event, args, ctx) => {
      const alias = (args[0] || "").toLowerCase();
      const a = get(ctx.ownerId);
      if (!alias || !(alias in a.map)) return _fmt.reply(event, `❌ Alias "${esc(alias || "-")}" ga ada.`);
      delete a.map[alias];
      save(ctx.ownerId);
      return _fmt.reply(event, `🗑 Alias "<b>${esc(alias)}</b>" dihapus.`);
    },
  },
  {
    name: "clearalias", description: "Hapus semua alias", category: "Alias",
    handler: async (event, args, ctx) => {
      const a = get(ctx.ownerId);
      const n = Object.keys(a.map).length;
      a.map = {};
      save(ctx.ownerId);
      return _fmt.reply(event, `🧹 <b>${n} alias dihapus.</b>`);
    },
  },
];
