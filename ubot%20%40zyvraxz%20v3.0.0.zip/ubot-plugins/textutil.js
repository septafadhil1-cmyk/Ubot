// ─────────────────────────────────────────
//  Plugin: Text Utilities (semua REAL, offline)
// ─────────────────────────────────────────

const _fmt = require("./_format");

async function getText(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) { try { const r = await event.message.getReplyMessage(); t = r?.text || r?.message || ""; } catch {} }
  return t;
}

const defs = [
  ["capitalize", "Huruf besar di awal kata", t => t.replace(/\b\w/g, c => c.toUpperCase())],
  ["titlecase", "Format Judul (Title Case)", t => t.toLowerCase().replace(/\b\w/g, c => c.toUpperCase())],
  ["sentencecase", "Format kalimat", t => t.charAt(0).toUpperCase() + t.slice(1).toLowerCase()],
  ["alternate", "HuRuF SeLaNg-sElInG", t => [...t].map((c,i)=>i%2?c.toLowerCase():c.toUpperCase()).join("")],
  ["removespace", "Hapus semua spasi", t => t.replace(/\s+/g, "")],
  ["removevowels", "Hapus huruf vokal", t => t.replace(/[aiueoAIUEO]/g, "")],
  ["countword", "Hitung jumlah kata", t => `${t.trim().split(/\s+/).filter(Boolean).length} kata`],
  ["countchar", "Hitung jumlah karakter", t => `${t.length} karakter (${t.replace(/\s/g,"").length} tanpa spasi)`],
  ["countline", "Hitung jumlah baris", t => `${t.split("\n").length} baris`],
  ["vowelcount", "Hitung huruf vokal", t => `${(t.match(/[aiueo]/gi)||[]).length} vokal`],
  ["snake", "ubah_jadi_snake_case", t => t.trim().toLowerCase().replace(/\s+/g, "_")],
  ["kebab", "ubah-jadi-kebab-case", t => t.trim().toLowerCase().replace(/\s+/g, "-")],
  ["camel", "ubahJadiCamelCase", t => t.trim().toLowerCase().replace(/\s+(.)/g, (_,c)=>c.toUpperCase())],
  ["dotcase", "ubah.jadi.dot.case", t => t.trim().toLowerCase().replace(/\s+/g, ".")],
  ["trim", "Hapus spasi berlebih", t => t.replace(/\s+/g, " ").trim()],
  ["wordsort", "Urutkan kata A-Z", t => t.trim().split(/\s+/).sort().join(" ")],
  ["wordrev", "Balik urutan kata", t => t.trim().split(/\s+/).reverse().join(" ")],
  ["charsort", "Urutkan huruf A-Z", t => [...t.replace(/\s/g,"")].sort().join("")],
  ["unique", "Hapus kata duplikat", t => [...new Set(t.trim().split(/\s+/))].join(" ")],
  ["len", "Panjang teks", t => `Panjang: ${t.length} karakter`],
];

const commands = defs.map(([name, desc, fn]) => ({
  name, description: desc, category: "Text",
  handler: async (event, args) => {
    const t = await getText(event, args);
    if (!t) return _fmt.reply(event, `❌ Tulis teks atau reply pesan.`);
    try { return _fmt.reply(event, `<b>Hasil:</b>\n${_fmt.esc(fn(t))}`); }
    catch (e) { return _fmt.reply(event, `❌ Error: ${_fmt.esc(e.message)}`); }
  },
}));

// Repeat dengan parameter
commands.push({
  name: "repeat", description: "Ulang teks (.repeat 3 halo)", category: "Text",
  handler: async (event, args) => {
    const n = Math.min(parseInt(args[0]) || 0, 50);
    if (!n) return _fmt.reply(event, `❌ Format: <code>.repeat 3 halo</code>`);
    const t = args.slice(1).join(" ");
    if (!t) return _fmt.reply(event, `❌ Tulis teks setelah jumlah.`);
    return _fmt.reply(event, `${(t + " ").repeat(n).trim()}`);
  },
});

module.exports.commands = commands;
