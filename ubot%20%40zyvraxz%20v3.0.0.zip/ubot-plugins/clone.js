// ─────────────────────────────────────────
//  Plugin: Clone — tiru nama & foto profil orang ke akun ubot
//  Reply pesan orang + .clone  → ubot ganti nama+foto jadi mirip dia
//  .resetclone                 → balikin (hapus foto, info disimpan saat clone)
// ─────────────────────────────────────────

const _fmt = require("./_format");
const { Api } = require("telegram");

// Simpan info asli sebelum clone (per ubot, di memori)
const originalInfo = new Map();

module.exports.commands = [
  {
    name: "clone",
    description: "Tiru nama & foto profil orang (reply pesan + .clone)",
    category: "Utilitas",
    handler: async (event, args, ctx) => {
      const client = ctx.client;
      const msg = event.message;

      if (!msg.replyTo) {
        return _fmt.reply(event, `❌ Reply pesan orang yang mau di-clone.`);
      }

      try {
        const replied = await msg.getReplyMessage();
        const sender = await replied.getSender();
        if (!sender) return _fmt.reply(event, `❌ Tidak bisa ambil data orang itu.`);

        // Simpan info asli ubot (sekali, biar bisa direset)
        const me = await client.getMe();
        if (!originalInfo.has(ctx.ownerId)) {
          originalInfo.set(ctx.ownerId, {
            firstName: me.firstName || "",
            lastName: me.lastName || "",
          });
        }

        // Ganti nama
        const firstName = sender.firstName || sender.title || "User";
        const lastName = sender.lastName || "";
        await client.invoke(new Api.account.UpdateProfile({
          firstName: firstName.slice(0, 64),
          lastName: lastName.slice(0, 64),
        }));

        // Ganti foto profil (kalau orang itu punya foto)
        let photoStatus = "tanpa foto (orang itu ga punya foto profil publik)";
        try {
          const photos = await client.invoke(new Api.photos.GetUserPhotos({
            userId: sender.id, offset: 0, maxId: 0, limit: 1,
          }));
          if (photos.photos && photos.photos.length > 0) {
            // Download foto orang itu lalu upload sebagai foto ubot
            const buf = await client.downloadProfilePhoto(sender, { isBig: true });
            if (buf) {
              const file = await client.uploadFile({
                file: new (require("telegram/client/uploads").CustomFile)(
                  "clone.jpg", buf.length, "", buf
                ),
                workers: 1,
              });
              await client.invoke(new Api.photos.UploadProfilePhoto({ file }));
              photoStatus = "✅ foto profil diganti";
            }
          }
        } catch (photoErr) {
          photoStatus = `foto gagal: ${photoErr.message}`;
        }

        return _fmt.reply(event,
          `🎭 <b>Clone Berhasil!</b>\n\n` +
          `<b>Nama:</b> ${_fmt.esc(firstName)} ${_fmt.esc(lastName)}\n` +
          `<b>Foto:</b> ${photoStatus}\n\n` +
          `<i>Reset pakai <code>.resetclone</code></i>`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal clone: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "resetclone",
    description: "Balikin nama & hapus foto setelah clone",
    category: "Utilitas",
    handler: async (event, args, ctx) => {
      const client = ctx.client;
      try {
        const orig = originalInfo.get(ctx.ownerId);
        // Balikin nama (kalau ada simpanan), kalau ga ada minimal kosongin lastName
        await client.invoke(new Api.account.UpdateProfile({
          firstName: (orig?.firstName || "User").slice(0, 64),
          lastName: (orig?.lastName || "").slice(0, 64),
        }));

        // Hapus foto profil terkini
        let photoMsg = "";
        try {
          const photos = await client.invoke(new Api.photos.GetUserPhotos({
            userId: (await client.getMe()).id, offset: 0, maxId: 0, limit: 1,
          }));
          if (photos.photos && photos.photos.length > 0) {
            await client.invoke(new Api.photos.DeletePhotos({
              id: [new Api.InputPhoto({
                id: photos.photos[0].id,
                accessHash: photos.photos[0].accessHash,
                fileReference: photos.photos[0].fileReference,
              })],
            }));
            photoMsg = "✅ foto dihapus";
          }
        } catch { photoMsg = "foto tidak diubah"; }

        originalInfo.delete(ctx.ownerId);
        return _fmt.reply(event,
          `↩️ <b>Reset Clone Berhasil!</b>\n\n` +
          `<b>Nama:</b> dikembalikan\n` +
          `<b>Foto:</b> ${photoMsg}`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal reset: ${_fmt.esc(e.message)}`);
      }
    },
  },
];
