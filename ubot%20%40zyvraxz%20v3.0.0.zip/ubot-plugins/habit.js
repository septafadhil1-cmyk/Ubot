// ─────────────────────────────────────────
//  Plugin: Habit Tracker (kebiasaan harian + streak) — tersimpan permanen per ubot
//  .sethabit <nama>       → bikin habit baru
//  .habits                → daftar habit + streak + status hari ini
//  .ceklishabit <nama>    → tandai selesai hari ini (naikin streak)
//  .resethabit <nama>     → reset streak ke 0
//  .delhabit <nama>       → hapus habit
// ─────────────────────────────────────────
const _fmt = require("./_format");
const store = require("../lib/store");
const esc = _fmt.esc;

let cache = null; // ownerId(str) → { habits: { name: { streak, lastDone: "YYYY-MM-DD"|null } } }

async function initHabit() {
  cache = {};
  if (store.isReady && store.isReady()) {
    try {
      const docs = await store.all("habit");
      for (const d of docs) {
        const id = (d._id || d.id || "").toString();
        if (id) cache[id] = { habits: d.habits || {} };
      }
      console.log(`✅ [db] load habit: ${docs.length} user`);
    } catch (e) { console.error("init habit:", e.message); }
  }
}
function get(ownerId) { const id = String(ownerId); if (!cache) cache = {}; if (!cache[id]) cache[id] = { habits: {} }; return cache[id]; }
function save(ownerId) { store.upsert("habit", String(ownerId), cache[String(ownerId)]).catch(() => {}); }

// Tanggal WIB "YYYY-MM-DD"
function todayStr(offsetDays = 0) {
  const d = new Date(Date.now() + 7 * 3600 * 1000 + offsetDays * 86400000);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
}

module.exports.initHabit = initHabit;
module.exports.commands = [
  {
    name: "sethabit", description: "Bikin habit baru: .sethabit <nama>", category: "Habit",
    handler: async (event, args, ctx) => {
      const name = args.join(" ").toLowerCase().trim();
      if (!name) return _fmt.reply(event, `❌ Format: <code>.sethabit &lt;nama&gt;</code>`);
      const h = get(ctx.ownerId);
      if (h.habits[name]) return _fmt.reply(event, `ℹ️ Habit "<b>${esc(name)}</b>" udah ada.`);
      h.habits[name] = { streak: 0, lastDone: null };
      save(ctx.ownerId);
      return _fmt.reply(event, `🌱 Habit "<b>${esc(name)}</b>" dibuat. Ceklis tiap hari pakai <code>.ceklishabit ${esc(name)}</code>.`);
    },
  },
  {
    name: "habits", description: "Daftar habit + streak + status hari ini", category: "Habit",
    handler: async (event, args, ctx) => {
      const h = get(ctx.ownerId);
      const keys = Object.keys(h.habits);
      if (!keys.length) return _fmt.reply(event, `🌱 Belum ada habit. Bikin pakai <code>.sethabit</code>.`);
      const today = todayStr();
      const lines = [`🔥 <b>Habit Tracker</b> (${keys.length})`, `⏣────────────────⏣\n`];
      for (const k of keys) {
        const hb = h.habits[k];
        const doneToday = hb.lastDone === today;
        lines.push(`${doneToday ? "✅" : "⬜"} <b>${esc(k)}</b> — 🔥 ${hb.streak} hari${doneToday ? "" : " <i>(belum hari ini)</i>"}`);
      }
      return _fmt.reply(event, lines.join("\n"));
    },
  },
  {
    name: "ceklishabit", description: "Tandai habit selesai hari ini: .ceklishabit <nama>", category: "Habit",
    handler: async (event, args, ctx) => {
      const name = args.join(" ").toLowerCase().trim();
      const h = get(ctx.ownerId);
      if (!name || !h.habits[name]) return _fmt.reply(event, `❌ Habit "${esc(name || "-")}" ga ada. Lihat <code>.habits</code>.`);
      const hb = h.habits[name];
      const today = todayStr(), yesterday = todayStr(-1);
      if (hb.lastDone === today) return _fmt.reply(event, `✅ Habit "<b>${esc(name)}</b>" udah diceklis hari ini. Streak: 🔥 ${hb.streak}.`);
      hb.streak = (hb.lastDone === yesterday) ? hb.streak + 1 : 1; // lanjut streak kalau kemarin, else mulai baru
      hb.lastDone = today;
      save(ctx.ownerId);
      return _fmt.reply(event, `🔥 Mantap! "<b>${esc(name)}</b>" streak jadi <b>${hb.streak} hari</b>.`);
    },
  },
  {
    name: "resethabit", description: "Reset streak habit: .resethabit <nama>", category: "Habit",
    handler: async (event, args, ctx) => {
      const name = args.join(" ").toLowerCase().trim();
      const h = get(ctx.ownerId);
      if (!name || !h.habits[name]) return _fmt.reply(event, `❌ Habit "${esc(name || "-")}" ga ada.`);
      h.habits[name] = { streak: 0, lastDone: null };
      save(ctx.ownerId);
      return _fmt.reply(event, `🔄 Streak "<b>${esc(name)}</b>" direset ke 0.`);
    },
  },
  {
    name: "delhabit", description: "Hapus habit: .delhabit <nama>", category: "Habit",
    handler: async (event, args, ctx) => {
      const name = args.join(" ").toLowerCase().trim();
      const h = get(ctx.ownerId);
      if (!name || !h.habits[name]) return _fmt.reply(event, `❌ Habit "${esc(name || "-")}" ga ada.`);
      delete h.habits[name];
      save(ctx.ownerId);
      return _fmt.reply(event, `🗑 Habit "<b>${esc(name)}</b>" dihapus.`);
    },
  },
];
