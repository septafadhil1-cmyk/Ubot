// ─────────────────────────────────────────
//  Plugin: AFK System (multi-user / per-ownerId)
//  .afk [alasan] — aktifkan AFK
//  .unafk        — matiin AFK
//  State dipisah per ownerId biar tiap ubot punya AFK sendiri
// ─────────────────────────────────────────
const _fmt = require("./_format");

const PREFIX = process.env.UBOT_PREFIX || ".";

// State AFK per owner: ownerId → { active, reason, since }
const afkStates = new Map();
// Cooldown per owner: ownerId → Map(key → timestamp)
const repliedToMap = new Map();
const COOLDOWN_MS = 60 * 1000;

function getAfkState(ownerId) {
  if (!afkStates.has(ownerId)) {
    afkStates.set(ownerId, { active: false, reason: "", since: null });
  }
  return afkStates.get(ownerId);
}

function getRepliedTo(ownerId) {
  if (!repliedToMap.has(ownerId)) repliedToMap.set(ownerId, new Map());
  return repliedToMap.get(ownerId);
}

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

async function reply(event, html) {
  return _fmt.reply(event, html);
}

function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h} jam ${m % 60} menit`;
  if (m > 0) return `${m} menit ${s % 60} detik`;
  return `${s} detik`;
}

module.exports = {
  afkStates,
  repliedToMap,
  getAfkState,
  getRepliedTo,
  COOLDOWN_MS,
  formatDuration,
  esc,

  commands: [
    {
      name: "afk",
      description: "Aktifkan mode AFK dengan alasan opsional",
      category: "Utilitas",
      handler: async (event, args, ctx) => {
        const state = getAfkState(ctx.ownerId);
        state.active = true;
        state.reason = args.join(" ") || "Tidak ada alasan";
        state.since = Date.now();
        getRepliedTo(ctx.ownerId).clear();
        return reply(event,
          `😴 <b>Mode AFK Aktif</b>\n\n` +
          `<b>Alasan:</b> ${esc(state.reason)}\n` +
          `<i>Auto-reply akan dikirim kalau ada yang mention kamu.</i>\n` +
          `<i>Ketik <code>${PREFIX}unafk</code> untuk menonaktifkan.</i>`
        );
      },
    },
    {
      name: "unafk",
      description: "Matikan mode AFK",
      category: "Utilitas",
      handler: async (event, args, ctx) => {
        const state = getAfkState(ctx.ownerId);
        if (!state.active) return reply(event, `ℹ️ Kamu tidak sedang AFK.`);
        const duration = formatDuration(Date.now() - state.since);
        state.active = false;
        state.reason = "";
        state.since = null;
        getRepliedTo(ctx.ownerId).clear();
        return reply(event,
          `✅ <b>Mode AFK Dinonaktifkan</b>\n\nKamu sudah AFK selama <b>${duration}</b>.`
        );
      },
    },
  ],
};
