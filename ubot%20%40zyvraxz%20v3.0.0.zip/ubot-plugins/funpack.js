// ─────────────────────────────────────────
//  Plugin: Fun Pack — command hiburan (konten lokal, no API)
// ─────────────────────────────────────────

const _fmt = require("./_format");

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const PICKUP = [
  "Apa kamu wifi? Soalnya aku ngerasa ada koneksi.",
  "Kamu pasti capek, soalnya seharian muter-muter di pikiranku.",
  "Namamu siapa? Biar aku tau mau nyimpen kontak siapa di hati.",
  "Aku bukan fotografer, tapi aku bisa bayangin kita bareng.",
  "Kalau senyummu dijual, aku rela bangkrut belinya.",
  "Apa kamu Google? Karena kamu semua yang aku cari.",
];
const ROAST = [
  "Kamu bukan jelek, cuma wajahmu lagi eksperimen aja.",
  "Otakmu unik, jarang kepake soalnya.",
  "Kamu kayak update software — ga ada yang nungguin.",
  "Tenang, ga semua orang bisa pinter. Kamu buktinya.",
  "Kamu spesial kok, kayak parkiran difabel.",
];
const COMPLIMENT = [
  "Kamu tuh kayak kopi pagi — bikin semangat.",
  "Senyummu bisa nyaingin matahari pagi.",
  "Dunia lebih cerah karena ada kamu.",
  "Kamu pinter, baik, dan keren sekaligus. Langka!",
  "Kalau baik hati ada juaranya, kamu pemenangnya.",
];
const TRUTH = [
  "Siapa orang terakhir yang kamu stalk di sosmed?",
  "Apa hal paling memalukan yang pernah kamu lakuin?",
  "Pernah suka sama sahabat sendiri?",
  "Apa rahasia yang belum pernah kamu kasih tau siapa pun?",
  "Siapa crush kamu sekarang?",
];
const DARE = [
  "Kirim pesan 'aku kangen' ke chat ke-3 dari atas.",
  "Ganti foto profil sesuai yang disuruh grup selama 1 jam.",
  "Voice note nyanyi 10 detik di grup.",
  "Telepon orang random di kontak, bilang 'halo sayang'.",
  "Tulis status alay selama 30 menit.",
];
const WYR = [
  "Lebih milih bisa terbang atau bisa ngilang?",
  "Lebih milih kaya tapi sendiri, atau biasa aja tapi bahagia?",
  "Lebih milih ga bisa main HP seminggu atau ga mandi 3 hari?",
  "Lebih milih bisa baca pikiran atau bisa liat masa depan?",
  "Lebih milih hidup tanpa musik atau tanpa film?",
];
const DADJOKE = [
  "Kenapa nasi goreng ga pernah sedih? Karena udah digoreng, bukan dibaperin.",
  "Apa bedanya kamu sama jam? Jam bisa muter, kamu cuma muterin dia.",
  "Hewan apa yang paling kaya? Be-ruang.",
  "Kenapa ikan ga bisa main piano? Karena takut kena tuts-nya basah.",
  "Buah apa yang bisa nemenin? Apel-anmu.",
];
const MOTIVATE = [
  "Mulai aja dulu, sempurna itu urusan nanti.",
  "Sekecil apa pun progres, tetap progres.",
  "Gagal itu bukti kamu nyoba. Lanjut!",
  "Hari ini berat, tapi kamu udah pernah lewatin yang lebih berat.",
  "Jangan bandingin bab 1 hidupmu sama bab 20 hidup orang lain.",
];
const FORTUNE = [
  "Rezeki tak terduga datang minggu ini. Siap-siap!",
  "Seseorang dari masa lalu bakal muncul lagi.",
  "Keputusan kecil hari ini ngubah banyak hal ke depan.",
  "Sabar kamu bakal kebayar sebentar lagi.",
  "Hindari overthinking malam ini, semua bakal baik-baik aja.",
];
const INSULT = [
  "Kamu tuh ibarat loading 99% — bikin gregetan.",
  "Level mikirmu masih versi demo ya?",
  "Kamu bukti kalau evolusi bisa istirahat sejenak.",
  "Kalau ada lomba lemot, kamu telat daftarnya.",
];

function mk(name, desc, arr) {
  return { name, description: desc, category: "Fun", handler: (event) => _fmt.reply(event, `${pick(arr)}`) };
}

module.exports.commands = [
  mk("pickup", "Gombalan random", PICKUP),
  mk("roast", "Roasting receh", ROAST),
  mk("compliment", "Pujian manis", COMPLIMENT),
  mk("truth", "Pertanyaan truth", TRUTH),
  mk("dare", "Tantangan dare", DARE),
  mk("wyr", "Would You Rather", WYR),
  mk("dadjoke", "Lelucon receh", DADJOKE),
  mk("motivate", "Kata motivasi", MOTIVATE),
  mk("fortune", "Ramalan iseng", FORTUNE),
  mk("insult", "Hinaan bercanda", INSULT),
];
