// ─────────────────────────────────────────
//  Plugin: World Time
//  .time <kota>   → jam di kota/zona tertentu
//  .time          → jam di beberapa kota populer
// ─────────────────────────────────────────
const _fmt = require("./_format");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

async function reply(event, html) {
  return _fmt.reply(event, html);
}

// Mapping kota → timezone IANA
const ZONES = {
  jakarta: "Asia/Jakarta", bogor: "Asia/Jakarta", bandung: "Asia/Jakarta",
  surabaya: "Asia/Jakarta", wib: "Asia/Jakarta",
  makassar: "Asia/Makassar", bali: "Asia/Makassar", wita: "Asia/Makassar",
  jayapura: "Asia/Jayapura", papua: "Asia/Jayapura", wit: "Asia/Jayapura",
  tokyo: "Asia/Tokyo", jepang: "Asia/Tokyo", japan: "Asia/Tokyo",
  seoul: "Asia/Seoul", korea: "Asia/Seoul",
  beijing: "Asia/Shanghai", china: "Asia/Shanghai", shanghai: "Asia/Shanghai",
  singapore: "Asia/Singapore", singapura: "Asia/Singapore",
  bangkok: "Asia/Bangkok", thailand: "Asia/Bangkok",
  dubai: "Asia/Dubai", uae: "Asia/Dubai",
  mekkah: "Asia/Riyadh", mecca: "Asia/Riyadh", saudi: "Asia/Riyadh", riyadh: "Asia/Riyadh",
  london: "Europe/London", inggris: "Europe/London", uk: "Europe/London",
  paris: "Europe/Paris", prancis: "Europe/Paris", france: "Europe/Paris",
  berlin: "Europe/Berlin", jerman: "Europe/Berlin", germany: "Europe/Berlin",
  moscow: "Europe/Moscow", rusia: "Europe/Moscow", russia: "Europe/Moscow",
  newyork: "America/New_York", ny: "America/New_York", usa: "America/New_York",
  losangeles: "America/Los_Angeles", la: "America/Los_Angeles", california: "America/Los_Angeles",
  sydney: "Australia/Sydney", australia: "Australia/Sydney",
};

function getTimeIn(tz) {
  const now = new Date();
  const time = now.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit", timeZone: tz });
  const date = now.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: tz });
  return { time, date };
}

module.exports.commands = [
  {
    name: "time",
    description: "Lihat jam di kota/negara tertentu",
    usage: ".time [kota]",
    category: "Utilitas",
    handler: async (event, args) => {
      if (!args.length) {
        // Tampilkan beberapa kota populer
        const cities = [
          ["🇮🇩 Jakarta (WIB)", "Asia/Jakarta"],
          ["🇮🇩 Makassar (WITA)", "Asia/Makassar"],
          ["🇮🇩 Jayapura (WIT)", "Asia/Jayapura"],
          ["🇸🇦 Mekkah", "Asia/Riyadh"],
          ["🇯🇵 Tokyo", "Asia/Tokyo"],
          ["🇬🇧 London", "Europe/London"],
          ["🇺🇸 New York", "America/New_York"],
        ];
        const lines = ["🌍 <b>Jam Dunia</b>\n"];
        for (const [label, tz] of cities) {
          const { time } = getTimeIn(tz);
          lines.push(`${label}: <code>${time}</code>`);
        }
        lines.push(`\n<i>Ketik <code>.time &lt;kota&gt;</code> untuk kota spesifik</i>`);
        return reply(event, lines.join("\n"));
      }

      const query = args.join("").toLowerCase().replace(/\s/g, "");
      const tz = ZONES[query];

      if (!tz) {
        const available = Object.keys(ZONES).filter((k, i, arr) =>
          arr.indexOf(k) === i
        ).slice(0, 20).join(", ");
        return reply(event,
          `❌ Kota <code>${esc(args.join(" "))}</code> tidak dikenal.\n\n` +
          `<b>Contoh kota:</b> jakarta, tokyo, london, mekkah, newyork, dubai, dll.`
        );
      }

      const { time, date } = getTimeIn(tz);
      const cityName = args.join(" ").replace(/\b\w/g, c => c.toUpperCase());
      return reply(event,
        `🕐 <b>Waktu di ${esc(cityName)}</b>\n\n` +
        `<b>Jam:</b> <code>${time}</code>\n` +
        `<b>Tanggal:</b> ${date}\n` +
        `<b>Zona:</b> ${esc(tz)}`
      );
    },
  },
];
