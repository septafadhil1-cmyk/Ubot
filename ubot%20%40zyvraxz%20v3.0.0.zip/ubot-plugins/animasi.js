// ─────────────────────────────────────────
//  Plugin: Animasi — animasi ASCII dari database (collection Animasi-ubot)
//   • .animasi                 → list animasi (default + punya kamu)
//   • .animasi <nama>          → mainkan animasi  (atau shortcut .<nama>)
//   • .canimasi <delay>,<desc>,<name>  → bikin animasi sendiri (multi-frame, interaktif)
//   • .delanimasi <nama>       → hapus animasi BUATAN kamu (default ga bisa)
//
//  Animasi buatan user = PRIVAT (cuma dia yang bisa pakai). 1 user ga boleh punya
//  2 animasi dengan nama sama. Karena ubot = userbot (bukan bot), pemilihan "Selesai/
//  Lanjut Frame" lewat KETIK balasan ("selesai"/"lanjut" atau "1"/"2"), bukan tombol klik.
// ─────────────────────────────────────────

const _fmt = require("./_format");
const animasi = require("../lib/animasiStore");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── Sesi pembuatan animasi per-owner (in-memory) ──
//   ownerId → { name, desc, delay, frames:[], stage:"await_frame"|"await_choice", frameNo, ts }
const sessions = new Map();
const SESSION_TTL = 10 * 60 * 1000; // 10 menit auto-expire

function getSession(ownerId) {
  const s = sessions.get(String(ownerId));
  if (!s) return null;
  if (Date.now() - s.ts > SESSION_TTL) { sessions.delete(String(ownerId)); return null; }
  return s;
}
function setSession(ownerId, s) { s.ts = Date.now(); sessions.set(String(ownerId), s); }
function clearSession(ownerId) { sessions.delete(String(ownerId)); }

// ── Tampilan ──
function frameView(text) {
  return `<blockquote><i><pre>${_fmt.esc(text)}</pre></i></blockquote>`;
}
function loadingView(dots) {
  return `<blockquote><i>Mengambil data dari database 📂${".".repeat(dots)}</i></blockquote>`;
}
function headerCreate(s) {
  return `<b>Create animasi</b>\n\n` +
    `Name: ${_fmt.esc(s.name)}\n` +
    `deskripsi: ${_fmt.esc(s.desc)}\n` +
    `Delay perframe: ${_fmt.esc(String(s.delay))}`;
}

async function safeEdit(msg, html) {
  try { await msg.edit({ text: html, parseMode: "html" }); return true; }
  catch { return false; }
}

// ── Main animasi ──
async function playAnimation(msg, anim) {
  const LOOPS = 2;
  for (let l = 0; l < LOOPS; l++) {
    for (let d = 5; d >= 0; d--) { await safeEdit(msg, loadingView(d)); await sleep(280); }
  }
  const frames = anim.frames && anim.frames.length ? anim.frames : [{ text: "(animasi kosong)", delay: 1 }];
  for (let i = 0; i < frames.length; i++) {
    const f = frames[i];
    await safeEdit(msg, frameView(f.text));
    const delayMs = Math.max(120, Math.round((Number(f.delay) > 0 ? Number(f.delay) : 0.6) * 1000));
    if (i < frames.length - 1) await sleep(delayMs);
  }
}

// Shortcut .<nama> (dipanggil ubotManager). userId = ownerId (biar animasi privat ikut kebaca).
async function runByName(event, nameOrKey, userId) {
  const anim = await animasi.get(nameOrKey, userId);
  if (!anim) return false;
  let msg;
  try { msg = await event.message.reply({ message: loadingView(5), parseMode: "html" }); }
  catch { return true; }
  try { await playAnimation(msg, anim); }
  catch (e) { await safeEdit(msg, `<blockquote><i>❌ Gagal main animasi: ${_fmt.esc(e.message)}</i></blockquote>`); }
  return true;
}

// ════════════════════════════════════════════
//  Interceptor: nangkep input flow .canimasi (KETIK balasan, tanpa prefix)
//  Dipanggil ubotManager untuk pesan dari OWNER. Return true kalau pesan "dimakan".
// ════════════════════════════════════════════
async function interceptCanimasiMessage(event, ctx) {
  const ownerId = ctx.ownerId;
  const s = getSession(ownerId);
  if (!s) return false; // ga ada sesi aktif → bukan urusan kita

  const msg = event.message;
  const raw = (msg.text || "").trim();
  const prefix = ctx.prefix || ".";

  // Biar user bisa BATAL & tetap bisa pakai command lain saat sesi jalan:
  // kalau dia ketik command (diawali prefix) selain kata kontrol → batalin sesi, lepas ke handler biasa.
  if (raw.startsWith(prefix)) {
    const low = raw.slice(prefix.length).trim().toLowerCase();
    if (low === "batal" || low === "cancel") {
      clearSession(ownerId);
      try { await msg.reply({ message: `<blockquote><b>❌ Pembuatan animasi dibatalkan.</b></blockquote>`, parseMode: "html" }); } catch {}
      return true;
    }
    // command lain → batalin sesi diam-diam, jangan makan pesannya
    clearSession(ownerId);
    return false;
  }

  // ── Stage: nunggu teks FRAME ──
  if (s.stage === "await_frame") {
    s.frames.push({ text: msg.text || "" }); // simpan teks frame apa adanya (bisa multi-baris)
    s.frameNo = s.frames.length;
    s.stage = "await_choice";
    setSession(ownerId, s);
    try {
      await msg.reply({
        message:
          `<blockquote><b>${headerCreate(s)}\n\n` +
          `Pilih menu apakah ingin lanjut Frame ${s.frameNo + 1}?\n\n` +
          `┃ Ketik <code>selesai</code> (atau <code>1</code>) → simpan animasi\n` +
          `┃ Ketik <code>lanjut</code> (atau <code>2</code>) → tambah Frame ${s.frameNo + 1}</b></blockquote>`,
        parseMode: "html",
      });
    } catch {}
    return true;
  }

  // ── Stage: nunggu pilihan SELESAI / LANJUT ──
  if (s.stage === "await_choice") {
    const c = raw.toLowerCase();
    const isDone = c === "selesai" || c === "1" || c === "done" || c === "simpan";
    const isNext = c === "lanjut" || c === "2" || c === "next" || c === "lanjut frame";
    if (!isDone && !isNext) {
      // input ga dikenali → ingatkan, tetap di stage ini
      try {
        await msg.reply({
          message: `<blockquote><b>❓ Ketik <code>selesai</code>/<code>1</code> untuk simpan, atau <code>lanjut</code>/<code>2</code> untuk Frame ${s.frameNo + 1}.</b></blockquote>`,
          parseMode: "html",
        });
      } catch {}
      return true;
    }
    if (isNext) {
      s.stage = "await_frame";
      setSession(ownerId, s);
      try {
        await msg.reply({
          message: `<blockquote><b>Ok, isi untuk Frame ${s.frameNo + 1}</b></blockquote>`,
          parseMode: "html",
        });
      } catch {}
      return true;
    }
    // isDone → simpan ke DB
    clearSession(ownerId);
    const res = await animasi.addUserAnimation(ownerId, s.name, s.desc, s.delay, s.frames);
    if (!res.ok) {
      try { await msg.reply({ message: `<blockquote><b>❌ Gagal simpan: ${_fmt.esc(res.error)}</b></blockquote>`, parseMode: "html" }); } catch {}
      return true;
    }
    try {
      await msg.reply({
        message:
          `<blockquote><b>✅ Animasi tersimpan!\n\n` +
          `Name: ${_fmt.esc(s.name)}\n` +
          `Deskripsi: ${_fmt.esc(s.desc)}\n` +
          `Delay perframe: ${_fmt.esc(String(s.delay))}\n` +
          `Total frame: ${s.frames.length}\n\n` +
          `Pakai: <code>${prefix}animasi ${_fmt.esc(animasi.label(s.name))}</code> (cuma kamu yang bisa)</b></blockquote>`,
        parseMode: "html",
      });
    } catch {}
    return true;
  }

  return false;
}

// ════════════════════════════════════════════
//  COMMANDS
// ════════════════════════════════════════════
// Handler dipakai .delanimasi & .delanim — hapus animasi user, default ditolak.
async function delAnimasiHandler(event, args, ctx) {
  const prefix = (ctx && ctx.prefix) || ".";
  const ownerId = ctx && ctx.ownerId;
  const name = args.join(" ").trim();
  if (!name) return _fmt.reply(event, `❌ Format: <code>${prefix}delanim &lt;nama&gt;</code>`);
  if (await animasi.isDefault(name)) {
    return _fmt.reply(event, `❌ "<b>${_fmt.esc(name)}</b>" animasi bawaan, ga bisa dihapus.`);
  }
  const res = await animasi.delUserAnimation(ownerId, name);
  if (!res.ok) return _fmt.reply(event, `❌ ${_fmt.esc(res.error)}`);
  return _fmt.reply(event, `✅ Animasi "<b>${_fmt.esc(name)}</b>" dihapus dari database.`);
}

const commands = [
  {
    name: "animasi",
    description: "Animasi ASCII. .animasi (list) atau .animasi <nama>",
    category: "Animasi",
    handler: async (event, args, ctx) => {
      const prefix = (ctx && ctx.prefix) || ".";
      const ownerId = ctx && ctx.ownerId;
      const arg = args.join(" ").trim();

      // Tanpa argumen → LIST (default + punya user)
      if (!arg) {
        const items = await animasi.list(ownerId);
        if (!items.length) {
          return _fmt.reply(event,
            `🎞️ <b>Animasi</b>\n\nBelum ada animasi di database.\n` +
            `<i>Animasi bawaan otomatis dibuat saat bot pertama jalan. Cek koneksi DB.</i>`);
        }
        const defLines = items.filter(a => a.isDefault).map(a =>
          `<code>${prefix}animasi ${_fmt.esc(a.label)}</code> - ${_fmt.esc(a.desc)}`).join("\n");
        const mineLines = items.filter(a => !a.isDefault).map(a =>
          `<code>${prefix}animasi ${_fmt.esc(a.label)}</code> - ${_fmt.esc(a.desc)} <i>(punyamu)</i>`).join("\n");
        let body = `🎞️ <b>Daftar Animasi</b>\n\n${defLines}`;
        if (mineLines) body += `\n\n<b>🔒 Animasi kamu:</b>\n${mineLines}`;
        body += `\n\n<i>Bikin sendiri: </i><code>${prefix}canimasi 0.5,deskripsi,nama</code>`;
        return _fmt.reply(event, body);
      }

      // Dengan argumen → mainkan (cek animasi privat user dulu, lalu default)
      const anim = await animasi.get(arg, ownerId);
      if (!anim) {
        return _fmt.reply(event,
          `❌ Animasi "<b>${_fmt.esc(arg)}</b>" tidak ada.\nKetik <code>${prefix}animasi</code> buat lihat daftar.`);
      }
      let msg;
      try { msg = await event.message.reply({ message: loadingView(5), parseMode: "html" }); }
      catch (e) { return _fmt.reply(event, `❌ Gagal mulai: ${_fmt.esc(e.message)}`); }
      try { await playAnimation(msg, anim); }
      catch (e) { await safeEdit(msg, `<blockquote><i>❌ Gagal: ${_fmt.esc(e.message)}</i></blockquote>`); }
    },
  },

  // ── .canimasi <delay>,<desc>,<name> ──
  {
    name: "canimasi",
    description: "Bikin animasi sendiri (privat). Format: .canimasi <delay>,<deskripsi>,<nama>",
    category: "Animasi",
    handler: async (event, args, ctx) => {
      const prefix = (ctx && ctx.prefix) || ".";
      const ownerId = ctx && ctx.ownerId;
      const raw = args.join(" ").trim();

      // Parse: dipisah koma → delay, desc, name (name = bagian terakhir, desc boleh ada koma? -> ambil 3 bagian, sisanya gabung ke desc)
      const parts = raw.split(",");
      if (parts.length < 3) {
        return _fmt.reply(event,
          `❌ Format: <code>${prefix}canimasi &lt;delay&gt;,&lt;deskripsi&gt;,&lt;nama&gt;</code>\n\n` +
          `Contoh: <code>${prefix}canimasi 0.5,Ketawa ngakak,wkwk</code>\n` +
          `<i>delay = detik per-frame (mis. 0.5)</i>`);
      }
      const delayRaw = parts[0].trim();
      const name = parts[parts.length - 1].trim();
      const desc = parts.slice(1, parts.length - 1).join(",").trim();
      const delay = Number(delayRaw);

      if (!name) return _fmt.reply(event, `❌ Nama animasi kosong.`);
      if (!desc) return _fmt.reply(event, `❌ Deskripsi kosong.`);
      if (!(delay > 0)) return _fmt.reply(event, `❌ Delay harus angka > 0 (detik), mis. <code>0.5</code>.`);

      // Validasi bentrok: default atau sudah punya
      if (await animasi.isDefault(name)) {
        return _fmt.reply(event, `❌ "<b>${_fmt.esc(name)}</b>" itu animasi bawaan. Pilih nama lain.`);
      }
      if (await animasi.userHas(ownerId, name)) {
        return _fmt.reply(event, `❌ Kamu sudah punya animasi "<b>${_fmt.esc(name)}</b>". Hapus dulu dengan <code>${prefix}delanimasi ${_fmt.esc(animasi.label(name))}</code> atau pakai nama lain.`);
      }

      // Mulai sesi → minta Frame 1
      setSession(ownerId, { name, desc, delay, frames: [], stage: "await_frame", frameNo: 0 });
      const s = getSession(ownerId);
      return _fmt.reply(event,
        `${headerCreate(s)}\n\nmasukan text untuk Frame 1\n\n<i>(ketik </i><code>${prefix}batal</code><i> buat membatalkan)</i>`);
    },
  },

  // ── .delanimasi / .delanim <nama> ──
  {
    name: "delanimasi",
    description: "Hapus animasi BUATANMU (animasi bawaan ga bisa). Format: .delanimasi <nama>",
    category: "Animasi",
    handler: delAnimasiHandler,
  },
  {
    name: "delanim",
    description: "Hapus animasi dari database (animasi bawaan spt bom dll ga bisa). Format: .delanim <nama>",
    category: "Animasi",
    handler: delAnimasiHandler,
  },
];

module.exports = { commands, runByName, interceptCanimasiMessage };
