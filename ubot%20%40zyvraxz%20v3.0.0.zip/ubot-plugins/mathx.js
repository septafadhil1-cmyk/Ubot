// ─────────────────────────────────────────
//  Plugin: Math & Converter (semua REAL, offline)
// ─────────────────────────────────────────

const _fmt = require("./_format");

function romanToInt(s){const m={I:1,V:5,X:10,L:50,C:100,D:500,M:1000};let r=0;s=s.toUpperCase();for(let i=0;i<s.length;i++){if(m[s[i]]<m[s[i+1]])r-=m[s[i]];else r+=m[s[i]];}return r;}
function intToRoman(n){const v=[1000,900,500,400,100,90,50,40,10,9,5,4,1];const sy=["M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"];let r="";for(let i=0;i<v.length;i++)while(n>=v[i]){r+=sy[i];n-=v[i];}return r;}

const commands = [
  { name: "calc", description: "Kalkulator (.calc 2+2*3)", category: "Math",
    handler: (e, a) => {
      const expr = a.join("").replace(/[^0-9+\-*/().%]/g, "");
      if (!expr) return _fmt.reply(e, `❌ Format: <code>.calc 2+2*3</code>`);
      try { const r = Function(`"use strict";return(${expr})`)(); return _fmt.reply(e, `🧮 <code>${_fmt.esc(expr)}</code> = <b>${r}</b>`); }
      catch { return _fmt.reply(e, `❌ Ekspresi tidak valid.`); }
    } },
  { name: "percent", description: "Hitung persen (.percent 25 200)", category: "Math",
    handler: (e, a) => { const p=parseFloat(a[0]),t=parseFloat(a[1]); if(isNaN(p)||isNaN(t))return _fmt.reply(e,`❌ Format: <code>.percent 25 200</code> (25% dari 200)`); return _fmt.reply(e, `📊 ${p}% dari ${t} = <b>${(p/100*t)}</b>`); } },
  { name: "factorial", description: "Faktorial (.factorial 5)", category: "Math",
    handler: (e, a) => { let n=parseInt(a[0]); if(isNaN(n)||n<0||n>170)return _fmt.reply(e,`❌ Angka 0-170.`); let r=1; for(let i=2;i<=n;i++)r*=i; return _fmt.reply(e, `🔢 ${n}! = <b>${r}</b>`); } },
  { name: "isprime", description: "Cek bilangan prima (.isprime 17)", category: "Math",
    handler: (e, a) => { const n=parseInt(a[0]); if(isNaN(n))return _fmt.reply(e,`❌ Masukkan angka.`); let p=n>1; for(let i=2;i<=Math.sqrt(n);i++)if(n%i===0){p=false;break;} return _fmt.reply(e, `${p?"✅":"❌"} <b>${n}</b> ${p?"adalah":"bukan"} bilangan prima.`); } },
  { name: "fibonacci", description: "Deret Fibonacci (.fibonacci 10)", category: "Math",
    handler: (e, a) => { let n=Math.min(parseInt(a[0])||10,50); let f=[0,1]; for(let i=2;i<n;i++)f.push(f[i-1]+f[i-2]); return _fmt.reply(e, `🔢 Fibonacci (${n}):\n<code>${f.slice(0,n).join(", ")}</code>`); } },
  { name: "gcd", description: "FPB dua angka (.gcd 12 18)", category: "Math",
    handler: (e, a) => { let x=parseInt(a[0]),y=parseInt(a[1]); if(isNaN(x)||isNaN(y))return _fmt.reply(e,`❌ Format: <code>.gcd 12 18</code>`); const g=(a,b)=>b?g(b,a%b):a; return _fmt.reply(e, `🔢 FPB(${x},${y}) = <b>${g(x,y)}</b>`); } },
  { name: "lcm", description: "KPK dua angka (.lcm 4 6)", category: "Math",
    handler: (e, a) => { let x=parseInt(a[0]),y=parseInt(a[1]); if(isNaN(x)||isNaN(y))return _fmt.reply(e,`❌ Format: <code>.lcm 4 6</code>`); const g=(a,b)=>b?g(b,a%b):a; return _fmt.reply(e, `🔢 KPK(${x},${y}) = <b>${x*y/g(x,y)}</b>`); } },
  { name: "roman", description: "Angka ke Romawi (.roman 2024)", category: "Math",
    handler: (e, a) => { const n=parseInt(a[0]); if(isNaN(n)||n<1||n>3999)return _fmt.reply(e,`❌ Angka 1-3999.`); return _fmt.reply(e, `🏛️ ${n} = <b>${intToRoman(n)}</b>`); } },
  { name: "unroman", description: "Romawi ke angka (.unroman MMXXIV)", category: "Math",
    handler: (e, a) => { if(!a[0])return _fmt.reply(e,`❌ Format: <code>.unroman MMXXIV</code>`); return _fmt.reply(e, `🔢 ${a[0].toUpperCase()} = <b>${romanToInt(a[0])}</b>`); } },
  { name: "celsius", description: "Fahrenheit ke Celsius (.celsius 100)", category: "Math",
    handler: (e, a) => { const f=parseFloat(a[0]); if(isNaN(f))return _fmt.reply(e,`❌ Masukkan angka.`); return _fmt.reply(e, `🌡️ ${f}°F = <b>${((f-32)*5/9).toFixed(2)}°C</b>`); } },
  { name: "fahrenheit", description: "Celsius ke Fahrenheit (.fahrenheit 37)", category: "Math",
    handler: (e, a) => { const c=parseFloat(a[0]); if(isNaN(c))return _fmt.reply(e,`❌ Masukkan angka.`); return _fmt.reply(e, `🌡️ ${c}°C = <b>${(c*9/5+32).toFixed(2)}°F</b>`); } },
  { name: "binary2", description: "Desimal ke biner (.binary2 42)", category: "Math",
    handler: (e, a) => { const n=parseInt(a[0]); if(isNaN(n))return _fmt.reply(e,`❌ Masukkan angka.`); return _fmt.reply(e, `🔢 ${n} = <code>${n.toString(2)}</code>`); } },
  { name: "todecimal", description: "Biner ke desimal (.todecimal 101010)", category: "Math",
    handler: (e, a) => { if(!a[0])return _fmt.reply(e,`❌ Masukkan biner.`); return _fmt.reply(e, `🔢 <code>${a[0]}</code> = <b>${parseInt(a[0],2)}</b>`); } },
  { name: "tohex", description: "Desimal ke hex (.tohex 255)", category: "Math",
    handler: (e, a) => { const n=parseInt(a[0]); if(isNaN(n))return _fmt.reply(e,`❌ Masukkan angka.`); return _fmt.reply(e, `🔢 ${n} = <code>${n.toString(16).toUpperCase()}</code>`); } },
  { name: "average", description: "Rata-rata angka (.average 1 2 3 4)", category: "Math",
    handler: (e, a) => { const n=a.map(Number).filter(x=>!isNaN(x)); if(!n.length)return _fmt.reply(e,`❌ Masukkan angka.`); return _fmt.reply(e, `📊 Rata-rata: <b>${(n.reduce((x,y)=>x+y,0)/n.length).toFixed(2)}</b>`); } },
];

module.exports.commands = commands;
