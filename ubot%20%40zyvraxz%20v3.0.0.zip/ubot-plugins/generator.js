// ─────────────────────────────────────────
//  Plugin: Generators (semua REAL, offline)
// ─────────────────────────────────────────

const _fmt = require("./_format");
function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

const NAMES_DEPAN = ["Budi","Siti","Andi","Dewi","Rina","Agus","Putri","Eko","Maya","Joko","Sari","Dian","Rudi","Lina","Bayu","Nita","Fajar","Indah","Yoga","Wati"];
const NAMES_BLKG = ["Santoso","Wijaya","Pratama","Lestari","Kusuma","Halim","Saputra","Anggraini","Nugroho","Permata","Hidayat","Maulana","Setiawan","Utami","Firmansyah"];
const KOTA = ["Jakarta","Surabaya","Bandung","Medan","Semarang","Makassar","Palembang","Depok","Bogor","Malang","Yogyakarta","Solo","Denpasar","Balikpapan"];

const commands = [
  { name: "lorem", description: "Generate teks Lorem Ipsum", category: "Generator",
    handler: (e, a) => { const n=Math.min(parseInt(a[0])||20,200); const w="lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud".split(" "); let r=[]; for(let i=0;i<n;i++)r.push(pick(w)); let s=r.join(" "); return _fmt.reply(e, `📝 ${s.charAt(0).toUpperCase()+s.slice(1)}.`); } },
  { name: "fakename", description: "Generate nama acak", category: "Generator",
    handler: e => _fmt.reply(e, `👤 <b>${pick(NAMES_DEPAN)} ${pick(NAMES_BLKG)}</b>`) },
  { name: "fakeinfo", description: "Generate data palsu (nama+kota+umur)", category: "Generator",
    handler: e => _fmt.reply(e, `👤 <b>Data Acak:</b>\nNama: ${pick(NAMES_DEPAN)} ${pick(NAMES_BLKG)}\nKota: ${pick(KOTA)}\nUmur: ${rand(17,60)} tahun`) },
  { name: "fakeemail", description: "Generate email acak", category: "Generator",
    handler: e => { const n=pick(NAMES_DEPAN).toLowerCase()+rand(1,999); return _fmt.reply(e, `📧 <code>${n}@${pick(["gmail.com","yahoo.com","outlook.com"])}</code>`); } },
  { name: "fakephone", description: "Generate nomor HP acak", category: "Generator",
    handler: e => { let n="08"+pick(["12","13","21","22","57","58"]); for(let i=0;i<8;i++)n+=rand(0,9); return _fmt.reply(e, `📱 <code>${n}</code>`); } },
  { name: "fakecity", description: "Generate kota acak", category: "Generator",
    handler: e => _fmt.reply(e, `🏙️ <b>${pick(KOTA)}</b>`) },
  { name: "randomemoji", description: "Emoji acak", category: "Generator",
    handler: e => { const em=["😀","😎","🥳","🤩","😍","🔥","💯","✨","🎉","🌟","💖","👑","🚀","🌈","⚡","🍕","🎮","🎯","🦄","🐉"]; let r=""; for(let i=0;i<5;i++)r+=pick(em); return _fmt.reply(e, `${r}`); } },
  { name: "randomword", description: "Kata acak", category: "Generator",
    handler: e => _fmt.reply(e, `🔤 <b>${pick(["kucing","matahari","gunung","laut","bintang","awan","hujan","pelangi","bunga","pohon","sungai","batu","angin","api","cahaya"])}</b>`) },
  { name: "genpin", description: "Generate PIN (.genpin 6)", category: "Generator",
    handler: (e, a) => { const n=Math.min(Math.max(parseInt(a[0])||4,3),12); let p=""; for(let i=0;i<n;i++)p+=rand(0,9); return _fmt.reply(e, `🔢 PIN: <code>${p}</code>`); } },
  { name: "token", description: "Generate token acak (.token 32)", category: "Generator",
    handler: (e, a) => { const n=Math.min(Math.max(parseInt(a[0])||16,8),64); return _fmt.reply(e, `🔑 <code>${require("crypto").randomBytes(n).toString("hex").slice(0,n)}</code>`); } },
  { name: "hexcolor", description: "Generate palet 5 warna", category: "Generator",
    handler: e => { let c=[]; for(let i=0;i<5;i++)c.push("#"+Math.floor(Math.random()*16777215).toString(16).padStart(6,"0")); return _fmt.reply(e, `🎨 Palet:\n<code>${c.join("\n")}</code>`); } },
  { name: "username", description: "Generate username acak", category: "Generator",
    handler: e => { const u=pick(["cool","dark","super","mega","pro","epic","ninja","king","ghost","cyber"])+pick(["wolf","dragon","tiger","phoenix","shadow","storm","blade","knight"])+rand(1,99); return _fmt.reply(e, `🆔 <code>@${u}</code>`); } },
];

module.exports.commands = commands;
