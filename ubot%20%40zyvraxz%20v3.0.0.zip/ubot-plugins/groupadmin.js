// ─────────────────────────────────────────
//  Plugin: Group Admin Tools (REAL — butuh ubot jadi admin)
// ─────────────────────────────────────────

const _fmt = require("./_format");
const { Api } = require("telegram");

async function getTargetId(event) {
  // dari reply atau mention
  if (event.message.replyTo) {
    try { const r = await event.message.getReplyMessage(); return r?.senderId; } catch {}
  }
  return null;
}

const commands = [
  { name: "pin", description: "Pin pesan (reply pesan + .pin)", category: "Grup",
    handler: async (event) => {
      if (!event.message.replyTo) return _fmt.reply(event, `❌ Reply pesan yang mau di-pin.`);
      try {
        await event.client.invoke(new Api.messages.UpdatePinnedMessage({ peer: event.message.peerId, id: event.message.replyTo.replyToMsgId }));
        return _fmt.reply(event, `📌 Pesan berhasil di-pin.`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal pin (perlu admin?): ${_fmt.esc(e.message)}`); }
    } },
  { name: "unpin", description: "Unpin pesan (reply + .unpin)", category: "Grup",
    handler: async (event) => {
      if (!event.message.replyTo) return _fmt.reply(event, `❌ Reply pesan yang mau di-unpin.`);
      try {
        await event.client.invoke(new Api.messages.UpdatePinnedMessage({ peer: event.message.peerId, id: event.message.replyTo.replyToMsgId, unpin: true }));
        return _fmt.reply(event, `📌 Pesan di-unpin.`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    } },
  { name: "tagall", description: "Tag semua member grup", category: "Grup",
    handler: async (event) => {
      try {
        const chat = await event.message.getChat();
        const participants = await event.client.getParticipants(chat, { limit: 100 });
        let mentions = participants.filter(p => !p.bot && !p.deleted).map(p => `<a href="tg://user?id=${p.id}">‌</a>`).join("");
        const text = event.message.text.split(" ").slice(1).join(" ") || "📢 Perhatian semua!";
        await event.client.sendMessage(event.message.peerId, { message: _fmt.wrap(text) + mentions, parseMode: "html" });
      } catch (e) { return _fmt.reply(event, `❌ Gagal tagall: ${_fmt.esc(e.message)}`); }
    } },
  { name: "kick", description: "Kick member (reply + .kick)", category: "Grup",
    handler: async (event) => {
      const target = await getTargetId(event);
      if (!target) return _fmt.reply(event, `❌ Reply pesan member yang mau di-kick.`);
      try {
        await event.client.invoke(new Api.channels.EditBanned({
          channel: event.message.peerId, participant: target,
          bannedRights: new Api.ChatBannedRights({ untilDate: 0, viewMessages: true }),
        }));
        // langsung unban biar bisa join lagi (kick, bukan ban)
        await event.client.invoke(new Api.channels.EditBanned({
          channel: event.message.peerId, participant: target,
          bannedRights: new Api.ChatBannedRights({ untilDate: 0 }),
        }));
        return _fmt.reply(event, `👢 Member di-kick.`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal kick (perlu admin?): ${_fmt.esc(e.message)}`); }
    } },
  { name: "ban", description: "Ban member (reply + .ban)", category: "Grup",
    handler: async (event) => {
      const target = await getTargetId(event);
      if (!target) return _fmt.reply(event, `❌ Reply pesan member yang mau di-ban.`);
      try {
        await event.client.invoke(new Api.channels.EditBanned({
          channel: event.message.peerId, participant: target,
          bannedRights: new Api.ChatBannedRights({ untilDate: 0, viewMessages: true }),
        }));
        return _fmt.reply(event, `🔨 Member di-ban.`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal ban (perlu admin?): ${_fmt.esc(e.message)}`); }
    } },
  { name: "mute", description: "Mute member (reply + .mute)", category: "Grup",
    handler: async (event) => {
      const target = await getTargetId(event);
      if (!target) return _fmt.reply(event, `❌ Reply pesan member yang mau di-mute.`);
      try {
        await event.client.invoke(new Api.channels.EditBanned({
          channel: event.message.peerId, participant: target,
          bannedRights: new Api.ChatBannedRights({ untilDate: 0, sendMessages: true }),
        }));
        return _fmt.reply(event, `🔇 Member di-mute.`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal mute (perlu admin?): ${_fmt.esc(e.message)}`); }
    } },
  { name: "unmute", description: "Unmute member (reply + .unmute)", category: "Grup",
    handler: async (event) => {
      const target = await getTargetId(event);
      if (!target) return _fmt.reply(event, `❌ Reply pesan member yang mau di-unmute.`);
      try {
        await event.client.invoke(new Api.channels.EditBanned({
          channel: event.message.peerId, participant: target,
          bannedRights: new Api.ChatBannedRights({ untilDate: 0 }),
        }));
        return _fmt.reply(event, `🔊 Member di-unmute.`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    } },
  { name: "promote", description: "Jadikan admin (reply + .promote)", category: "Grup",
    handler: async (event) => {
      const target = await getTargetId(event);
      if (!target) return _fmt.reply(event, `❌ Reply pesan member yang mau dipromote.`);
      try {
        await event.client.invoke(new Api.channels.EditAdmin({
          channel: event.message.peerId, userId: target,
          adminRights: new Api.ChatAdminRights({ changeInfo: true, deleteMessages: true, banUsers: true, inviteUsers: true, pinMessages: true }),
          rank: "Admin",
        }));
        return _fmt.reply(event, `⬆️ Member dipromote jadi admin.`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    } },
  { name: "demote", description: "Turunkan admin (reply + .demote)", category: "Grup",
    handler: async (event) => {
      const target = await getTargetId(event);
      if (!target) return _fmt.reply(event, `❌ Reply pesan admin yang mau diturunkan.`);
      try {
        await event.client.invoke(new Api.channels.EditAdmin({
          channel: event.message.peerId, userId: target,
          adminRights: new Api.ChatAdminRights({}), rank: "",
        }));
        return _fmt.reply(event, `⬇️ Admin diturunkan jadi member biasa.`);
      } catch (e) { return _fmt.reply(event, `❌ Gagal: ${_fmt.esc(e.message)}`); }
    } },
];

module.exports.commands = commands;
