// ─────────────────────────────────────────
//  Plugin: Tool Pack — utilitas teks/angka/cipher (no API)
// ─────────────────────────────────────────

const _fmt = require("./_format");
const crypto = require("crypto");

async function getInput(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) { try { const r = await event.message.getReplyMessage(); t = r?.text || r?.message || ""; } catch {} }
  return t;
}

// ── helpers ──
function zalgo(s) {
  const marks = ["\u0300","\u0301","\u0302","\u0303","\u0308","\u0327","\u0334","\u0335","\u0336","\u0489","\u0316","\u0317","\u0323"];
  return s.split("").map(c => c + Array.from({length: 3 + Math.floor(Math.random()*4)}, () => marks[Math.floor(Math.random()*marks.length)]).join("")).join("");
}
function uwu(s) {
  return s.replace(/[rl]/g, "w").replace(/[RL]/g, "W").replace(/n([aeiou])/gi, "ny$1").replace(/\bthe\b/gi, "da") + " uwu~";
}
function cowsay(s) {
  const top = " " + "_".repeat(s.length + 2);
  const bot = " " + "-".repeat(s.length + 2);
  return "```\n" + top + `\n< ${s} >\n` + bot + "\n        \\   ^__^\n         \\  (oo)\\_______\n            (__)\\       )\\/\\\n                ||----w |\n                ||     ||\n```";
}
function emojify(s) {
  const map = { a:"🇦",b:"🇧",c:"🇨",d:"🇩",e:"🇪",f:"🇫",g:"🇬",h:"🇭",i:"🇮",j:"🇯",k:"🇰",l:"🇱",m:"🇲",n:"🇳",o:"🇴",p:"🇵",q:"🇶",r:"🇷",s:"🇸",t:"🇹",u:"🇺",v:"🇻",w:"🇼",x:"🇽",y:"🇾",z:"🇿" };
  return s.toLowerCase().split("").map(c => map[c] ? map[c] + " " : (c === " " ? "   " : c)).join("");
}
function braille(s) {
  const map = { a:"⠁",b:"⠃",c:"⠉",d:"⠙",e:"⠑",f:"⠋",g:"⠛",h:"⠓",i:"⠊",j:"⠚",k:"⠅",l:"⠇",m:"⠍",n:"⠝",o:"⠕",p:"⠏",q:"⠟",r:"⠗",s:"⠎",t:"⠞",u:"⠥",v:"⠧",w:"⠺",x:"⠭",y:"⠽",z:"⠵"," ":" " };
  return s.toLowerCase().split("").map(c => map[c] || c).join("");
}
function rot47(s) {
  return s.replace(/[\x21-\x7E]/g, c => String.fromCharCode(33 + ((c.charCodeAt(0) - 33 + 47) % 94)));
}
function railfence(s, rails = 3) {
  if (rails < 2) return s;
  const rows = Array.from({ length: rails }, () => "");
  let r = 0, dir = 1;
  for (const c of s) { rows[r] += c; if (r === 0) dir = 1; else if (r === rails - 1) dir = -1; r += dir; }
  return rows.join("");
}
function unrailfence(s, rails = 3) {
  if (rails < 2) return s;
  const len = s.length;
  const pattern = [];
  let r = 0, dir = 1;
  for (let i = 0; i < len; i++) { pattern.push(r); if (r === 0) dir = 1; else if (r === rails - 1) dir = -1; r += dir; }
  const idx = [...pattern.keys()].sort((a, b) => pattern[a] - pattern[b] || a - b);
  const res = new Array(len);
  idx.forEach((pos, i) => { res[pos] = s[i]; });
  return res.join("");
}
function luhnValid(num) {
  const digits = num.replace(/\D/g, "");
  if (!digits) return null;
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = parseInt(digits[i]);
    if (alt) { d *= 2; if (d > 9) d -= 9; }
    sum += d; alt = !alt;
  }
  return sum % 10 === 0;
}
// CRC32
const CRC_TABLE = (() => {
  const t = [];
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
  return t;
})();
function crc32(s) {
  let crc = 0xFFFFFFFF;
  const buf = Buffer.from(s, "utf8");
  for (const b of buf) crc = CRC_TABLE[(crc ^ b) & 0xFF] ^ (crc >>> 8);
  return ((crc ^ 0xFFFFFFFF) >>> 0).toString(16).padStart(8, "0");
}
const rnd = (n) => Math.floor(Math.random() * n);

const C = (name, desc, category, fn) => ({
  name, description: desc, category,
  handler: async (event, args, ctx) => {
    const inp = await getInput(event, args);
    if (fn.needInput && !inp) return _fmt.reply(event, `❌ Kasih teks: <code>.${name} teks</code>`);
    try { return _fmt.reply(event, fn(inp, args, ctx)); }
    catch (e) { return _fmt.reply(event, `❌ Error: ${_fmt.esc(e.message)}`); }
  },
});
const needs = (f) => { f.needInput = true; return f; };

module.exports.commands = [
  // Text effects
  C("zalgo", "Teks glitch/cursed", "Text", needs((t) => `${zalgo(t)}`)),
  C("uwu", "Uwu-fy teks", "Text", needs((t) => `${uwu(t)}`)),
  C("cowsay", "Sapi ASCII ngomong", "Text", needs((t) => cowsay(t))),
  C("emojify", "Teks → emoji huruf", "Text", needs((t) => `${emojify(t)}`)),
  C("braille", "Teks → Braille", "Text", needs((t) => `${braille(t)}`)),
  C("stutter", "Teks gagap", "Text", needs((t) => t.split(" ").map(w => w ? `${w[0]}-${w}` : w).join(" "))),
  C("piglatin", "Teks → Pig Latin", "Text", needs((t) => t.split(" ").map(w => w ? w.slice(1) + w[0] + "ay" : w).join(" "))),
  C("shuffle", "Acak huruf teks", "Text", needs((t) => t.split("").sort(() => Math.random() - 0.5).join(""))),
  C("consonant", "Hitung konsonan", "Text", needs((t) => `🔤 Konsonan: <b>${(t.match(/[bcdfghjklmnpqrstvwxyz]/gi) || []).length}</b>`)),
  // Cipher
  C("rot47", "Cipher ROT47", "Encode", needs((t) => `${rot47(t)}`)),
  C("railfence", "Enkripsi Rail Fence (3 rel)", "Encode", needs((t) => `${railfence(t)}`)),
  C("unrailfence", "Dekripsi Rail Fence (3 rel)", "Encode", needs((t) => `${unrailfence(t)}`)),
  // Hash
  C("sha224", "Hash SHA-224", "Encode", needs((t) => `<code>${crypto.createHash("sha224").update(t).digest("hex")}</code>`)),
  C("sha384", "Hash SHA-384", "Encode", needs((t) => `<code>${crypto.createHash("sha384").update(t).digest("hex")}</code>`)),
  C("crc32", "Checksum CRC32", "Encode", needs((t) => `<code>${crc32(t)}</code>`)),
  // Number
  C("oct", "Desimal → Oktal", "Convert", needs((t) => { const n = parseInt(t); if (isNaN(n)) throw new Error("bukan angka"); return `🔢 Oktal: <code>${n.toString(8)}</code>`; })),
  C("unoct", "Oktal → Desimal", "Convert", needs((t) => { const n = parseInt(t, 8); if (isNaN(n)) throw new Error("bukan oktal"); return `🔢 Desimal: <code>${n}</code>`; })),
  C("luhn", "Cek validitas Luhn (kartu/IMEI)", "Tools", needs((t) => { const v = luhnValid(t); return v === null ? "❌ Masukin angka" : (v ? "✅ Valid (lolos Luhn)" : "❌ Tidak valid (gagal Luhn)"); })),
  // Generators
  C("macaddr", "Generate MAC address acak", "Generator", () => `🖧 <code>${Array.from({length:6},()=>rnd(256).toString(16).padStart(2,"0")).join(":").toUpperCase()}</code>`),
  C("randomip", "Generate IPv4 acak", "Generator", () => `🌐 <code>${Array.from({length:4},()=>rnd(256)).join(".")}</code>`),
  C("randomhexcolor", "Generate warna hex acak", "Generator", () => { const h = "#" + rnd(0x1000000).toString(16).padStart(6,"0").toUpperCase(); return `🎨 <code>${h}</code>`; }),
];
