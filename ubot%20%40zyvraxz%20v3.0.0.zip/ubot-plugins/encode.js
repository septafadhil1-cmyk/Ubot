// ─────────────────────────────────────────
//  Plugin: Encode/Decode & Crypto (semua REAL, offline)
// ─────────────────────────────────────────

const _fmt = require("./_format");
const crypto = require("crypto");

async function getText(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) {
    try { const r = await event.message.getReplyMessage(); t = r?.text || r?.message || ""; } catch {}
  }
  return t;
}

// Morse code
const MORSE = {a:".-",b:"-...",c:"-.-.",d:"-..",e:".",f:"..-.",g:"--.",h:"....",i:"..",j:".---",k:"-.-",l:".-..",m:"--",n:"-.",o:"---",p:".--.",q:"--.-",r:".-.",s:"...",t:"-",u:"..-",v:"...-",w:".--",x:"-..-",y:"-.--",z:"--..","0":"-----","1":".----","2":"..---","3":"...--","4":"....-","5":".....","6":"-....","7":"--...","8":"---..","9":"----.",".":".-.-.-",",":"--..--","?":"..--..","!":"-.-.--"};
const MORSE_REV = Object.fromEntries(Object.entries(MORSE).map(([k,v])=>[v,k]));

function rot13(s){return s.replace(/[a-zA-Z]/g,c=>String.fromCharCode((c<="Z"?90:122)>=(c=c.charCodeAt(0)+13)?c:c-26));}
function caesar(s,n){return s.replace(/[a-z]/gi,c=>{const b=c<="Z"?65:97;return String.fromCharCode((c.charCodeAt(0)-b+n)%26+b);});}
function atbash(s){return s.replace(/[a-z]/gi,c=>{const b=c<="Z"?65:97;return String.fromCharCode(b+25-(c.charCodeAt(0)-b));});}

const defs = [
  ["base64", "Encode teks ke Base64", t => Buffer.from(t).toString("base64")],
  ["unbase64", "Decode Base64 ke teks", t => Buffer.from(t, "base64").toString("utf8")],
  ["base32", "Encode teks ke Base32 (hex)", t => Buffer.from(t).toString("hex")],
  ["hex", "Encode teks ke Hexadecimal", t => Buffer.from(t).toString("hex")],
  ["unhex", "Decode Hexadecimal ke teks", t => Buffer.from(t.replace(/\s/g,""), "hex").toString("utf8")],
  ["binary", "Encode teks ke Biner", t => [...t].map(c => c.charCodeAt(0).toString(2).padStart(8,"0")).join(" ")],
  ["unbinary", "Decode Biner ke teks", t => t.trim().split(/\s+/).map(b => String.fromCharCode(parseInt(b,2))).join("")],
  ["url", "URL-encode teks", t => encodeURIComponent(t)],
  ["unurl", "URL-decode teks", t => decodeURIComponent(t)],
  ["morse", "Teks ke kode Morse", t => [...t.toLowerCase()].map(c => c===" "?"/":(MORSE[c]||"")).join(" ").trim()],
  ["unmorse", "Kode Morse ke teks", t => t.trim().split(" ").map(m => m==="/"?" ":(MORSE_REV[m]||"")).join("")],
  ["rot13", "Cipher ROT13", t => rot13(t)],
  ["atbash", "Cipher Atbash", t => atbash(t)],
  ["md5", "Hash MD5", t => crypto.createHash("md5").update(t).digest("hex")],
  ["sha1", "Hash SHA-1", t => crypto.createHash("sha1").update(t).digest("hex")],
  ["sha256", "Hash SHA-256", t => crypto.createHash("sha256").update(t).digest("hex")],
  ["sha512", "Hash SHA-512", t => crypto.createHash("sha512").update(t).digest("hex")],
  ["reverse2", "Balik urutan teks", t => [...t].reverse().join("")],
  ["ascii", "Teks ke kode ASCII", t => [...t].map(c => c.charCodeAt(0)).join(" ")],
  ["unascii", "Kode ASCII ke teks", t => t.trim().split(/\s+/).map(n => String.fromCharCode(parseInt(n,10))).join("")],
];

const commands = defs.map(([name, desc, fn]) => ({
  name, description: desc, category: "Encode",
  handler: async (event, args) => {
    const t = await getText(event, args);
    if (!t) return _fmt.reply(event, `❌ Tulis teks atau reply pesan.`);
    try {
      const out = fn(t);
      if (!out) return _fmt.reply(event, `❌ Gagal memproses (cek format input).`);
      return _fmt.reply(event, `<b>Hasil:</b>\n<code>${_fmt.esc(out)}</code>`);
    } catch (e) {
      return _fmt.reply(event, `❌ Error: ${_fmt.esc(e.message)}`);
    }
  },
}));

// Caesar dengan parameter shift
commands.push({
  name: "caesar", description: "Cipher Caesar (.caesar <shift> <teks>)", category: "Encode",
  handler: async (event, args) => {
    const n = parseInt(args[0]);
    if (isNaN(n)) return _fmt.reply(event, `❌ Format: <code>.caesar 3 halo dunia</code>`);
    const t = args.slice(1).join(" ") || (await getText(event, []));
    if (!t) return _fmt.reply(event, `❌ Tulis teks setelah shift.`);
    return _fmt.reply(event, `<b>Hasil (shift ${n}):</b>\n<code>${_fmt.esc(caesar(t, ((n%26)+26)%26))}</code>`);
  },
});

module.exports.commands = commands;
