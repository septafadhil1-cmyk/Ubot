// ─────────────────────────────────────────
//  Plugin: ID Card
//  .id            → ID card diri sendiri (gambar + teks)
//  .id (reply)    → ID card pengirim pesan yang di-reply
// ─────────────────────────────────────────

const { createCanvas, loadImage } = require("@napi-rs/canvas");
const fs = require("fs");
const path = require("path");
const os = require("os");

function esc(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function nameToColor(name) {
  const colors = ["#E17076","#7BC862","#65AADD","#A695E7","#EE7AAE","#6EC9CB","#FAA774","#F0941E"];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}
function getInitials(name) {
  return name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
}

// Render ID card mirip "TELEGRAM ID CARD"
async function renderIdCard({ name, userId, username, dcId, premium, avatarBuffer }) {
  const W = 760, H = 420;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  // Background gelap dengan rounded corner
  ctx.fillStyle = "#1a2332";
  ctx.beginPath();
  const R = 28;
  ctx.moveTo(R, 0); ctx.lineTo(W - R, 0); ctx.quadraticCurveTo(W, 0, W, R);
  ctx.lineTo(W, H - R); ctx.quadraticCurveTo(W, H, W - R, H);
  ctx.lineTo(R, H); ctx.quadraticCurveTo(0, H, 0, H - R);
  ctx.lineTo(0, R); ctx.quadraticCurveTo(0, 0, R, 0);
  ctx.closePath();
  ctx.fill();

  // Judul
  ctx.fillStyle = "#f5b942";
  ctx.font = "bold 38px sans-serif";
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.fillText("TELEGRAM ID CARD", 220, 45);

  // Avatar lingkaran
  const AV = 130, avX = 50, avY = 95;
  ctx.save();
  ctx.beginPath();
  ctx.arc(avX + AV / 2, avY + AV / 2, AV / 2, 0, Math.PI * 2);
  ctx.clip();
  if (avatarBuffer) {
    try {
      const img = await loadImage(avatarBuffer);
      ctx.drawImage(img, avX, avY, AV, AV);
    } catch {
      ctx.fillStyle = nameToColor(name);
      ctx.fillRect(avX, avY, AV, AV);
    }
  } else {
    ctx.fillStyle = nameToColor(name);
    ctx.fillRect(avX, avY, AV, AV);
  }
  ctx.restore();
  if (!avatarBuffer) {
    ctx.fillStyle = "#fff";
    ctx.font = "bold 48px sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(getInitials(name), avX + AV / 2, avY + AV / 2);
  }

  // Fields
  const fields = [
    ["Nama:", name],
    ["User ID:", String(userId)],
    ["Username:", username ? "@" + username : "-"],
    ["DC ID:", dcId != null ? String(dcId) : "-"],
    ["Premium?:", premium ? "Ya" : "Tidak"],
  ];
  let fy = 110;
  const labelX = 220, valueX = 400;
  ctx.textAlign = "left"; ctx.textBaseline = "middle";
  for (const [label, value] of fields) {
    ctx.fillStyle = "#8fa3bf";
    ctx.font = "bold 24px sans-serif";
    ctx.fillText(label, labelX, fy);
    ctx.fillStyle = "#5fb3f0";
    ctx.font = "bold 24px sans-serif";
    ctx.fillText(value, valueX, fy);
    fy += 48;
  }

  return canvas.toBuffer("image/png");
}

module.exports.commands = [
  {
    name: "id",
    description: "Lihat ID card (gambar + detail) diri/orang lain",
    category: "Utilitas",
    handler: async (event, args, ctx) => {
      const msg = event.message;
      const client = ctx.client;

      try {
        // Tentukan target: reply atau diri sendiri
        let target, chatInfo;
        if (msg.replyTo) {
          const replied = await msg.getReplyMessage();
          target = await replied.getSender();
        } else {
          target = await client.getMe();
        }
        if (!target) throw new Error("Target tidak ditemukan");

        const name = `${target.firstName || ""}${target.lastName ? " " + target.lastName : ""}`.trim() || target.username || "Unknown";
        const userId = target.id;
        const username = target.username || null;
        const premium = !!target.premium;

        // Ambil avatar
        let avatarBuffer = null;
        try {
          avatarBuffer = await client.downloadProfilePhoto(target, { isBig: false });
          if (avatarBuffer && avatarBuffer.length === 0) avatarBuffer = null;
        } catch {}

        // DC ID dari foto profil (kalau ada) — fallback null
        let dcId = target.photo?.dcId ?? null;

        // Render card
        const imgBuffer = await renderIdCard({ name, userId, username, dcId, premium, avatarBuffer });
        const tmpPath = path.join(os.tmpdir(), `idcard_${Date.now()}.png`);
        fs.writeFileSync(tmpPath, imgBuffer);

        // Caption teks detail (tebal + kutip + mono)
        const caption =
          `<blockquote><b>🔍 <b>DATA PENGGUNA</b>\n\n` +
          `👤 <b>Nama:</b> ${esc(name)}\n` +
          `🆔 <b>User ID:</b> <code>${userId}</code>\n` +
          `🌟 <b>Username:</b> ${username ? "@" + esc(username) : "-"}\n` +
          `📡 <b>DC ID:</b> ${dcId != null ? dcId : "-"}\n` +
          `💎 <b>Premium:</b> ${premium ? "Ya ✅" : "Tidak ❌"}</b></blockquote>`;

        await client.sendFile(msg.peerId, {
          file: tmpPath,
          caption,
          parseMode: "html",
          replyTo: msg.id,
          forceDocument: false,
        });

        fs.unlinkSync(tmpPath);
      } catch (e) {
        console.error("id error:", e.message);
        return msg.reply({ message: `<blockquote><b>❌ Gagal: ${esc(e.message)}</b></blockquote>`, parseMode: "html" });
      }
    },
  },
];
