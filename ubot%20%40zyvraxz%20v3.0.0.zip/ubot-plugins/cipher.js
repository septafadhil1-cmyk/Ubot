// ─────────────────────────────────────────
//  Plugin: Cipher & Encoding lanjutan (offline, REAL)
// ─────────────────────────────────────────

const _fmt = require("./_format");
async function getText(event, args) {
  let t = args.join(" ");
  if (!t && event.message.replyTo) { try { const r = await event.message.getReplyMessage(); t = r?.text || ""; } catch {} }
  return t;
}

// Base58
const B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function base58enc(buf) { let n = BigInt("0x" + (buf.toString("hex")||"0")); let s = ""; while (n > 0n) { s = B58[Number(n % 58n)] + s; n /= 58n; } for (const b of buf) { if (b === 0) s = "1" + s; else break; } return s || "1"; }

// Vigenere
function vigenere(text, key, dec) {
  let res = "", ki = 0;
  for (const c of text) {
    if (/[a-z]/i.test(c)) {
      const base = c <= "Z" ? 65 : 97;
      const k = key[ki % key.length].toLowerCase().charCodeAt(0) - 97;
      const shift = dec ? (26 - k) : k;
      res += String.fromCharCode((c.charCodeAt(0) - base + shift) % 26 + base);
      ki++;
    } else res += c;
  }
  return res;
}

// A1Z26
function a1z26enc(t) { return [...t.toLowerCase()].map(c => /[a-z]/.test(c) ? (c.charCodeAt(0)-96) : (c===" "?"/":"")).filter(Boolean).join("-"); }
function a1z26dec(t) { return t.split(/[-\s]/).map(n => n==="/"?" ":(parseInt(n)?String.fromCharCode(parseInt(n)+96):"")).join(""); }

// Leetspeak
const LEET = { a:"4", e:"3", i:"1", o:"0", s:"5", t:"7", b:"8", g:"9", l:"1" };
function leet(t) { return [...t.toLowerCase()].map(c => LEET[c] || c).join(""); }

// NATO phonetic
const NATO = { a:"Alpha",b:"Bravo",c:"Charlie",d:"Delta",e:"Echo",f:"Foxtrot",g:"Golf",h:"Hotel",i:"India",j:"Juliett",k:"Kilo",l:"Lima",m:"Mike",n:"November",o:"Oscar",p:"Papa",q:"Quebec",r:"Romeo",s:"Sierra",t:"Tango",u:"Uniform",v:"Victor",w:"Whiskey",x:"Xray",y:"Yankee",z:"Zulu" };

const commands = [
  { name: "base58", description: "Encode teks ke Base58", category: "Encode",
    handler: async (e, a) => { const t = await getText(e, a); if (!t) return _fmt.reply(e, `❌ Tulis teks.`); return _fmt.reply(e, `<b>Hasil:</b>\n<code>${base58enc(Buffer.from(t))}</code>`); } },
  { name: "vigenere", description: "Vigenere cipher (.vigenere <key> <teks>)", category: "Encode",
    handler: async (e, a) => { const key = a[0]; const t = a.slice(1).join(" "); if (!key || !t) return _fmt.reply(e, `❌ Format: <code>.vigenere kunci pesan rahasia</code>`); return _fmt.reply(e, `🔐 Encrypted:\n<code>${_fmt.esc(vigenere(t, key, false))}</code>`); } },
  { name: "unvigenere", description: "Decrypt Vigenere (.unvigenere <key> <teks>)", category: "Encode",
    handler: async (e, a) => { const key = a[0]; const t = a.slice(1).join(" "); if (!key || !t) return _fmt.reply(e, `❌ Format: <code>.unvigenere kunci teks</code>`); return _fmt.reply(e, `🔓 Decrypted:\n<code>${_fmt.esc(vigenere(t, key, true))}</code>`); } },
  { name: "a1z26", description: "Encode A1Z26 (a=1, b=2...)", category: "Encode",
    handler: async (e, a) => { const t = await getText(e, a); if (!t) return _fmt.reply(e, `❌ Tulis teks.`); return _fmt.reply(e, `<b>Hasil:</b>\n<code>${a1z26enc(t)}</code>`); } },
  { name: "una1z26", description: "Decode A1Z26", category: "Encode",
    handler: async (e, a) => { const t = await getText(e, a); if (!t) return _fmt.reply(e, `❌ Tulis kode.`); return _fmt.reply(e, `<b>Hasil:</b>\n${_fmt.esc(a1z26dec(t))}`); } },
  { name: "leet", description: "Ubah ke leetspeak (h4ck3r)", category: "Encode",
    handler: async (e, a) => { const t = await getText(e, a); if (!t) return _fmt.reply(e, `❌ Tulis teks.`); return _fmt.reply(e, `${_fmt.esc(leet(t))}`); } },
  { name: "nato", description: "Eja pakai NATO phonetic", category: "Encode",
    handler: async (e, a) => { const t = await getText(e, a); if (!t) return _fmt.reply(e, `❌ Tulis teks.`); return _fmt.reply(e, `<b>NATO:</b>\n${[...t.toLowerCase()].map(c => NATO[c] || (c===" "?"|":c)).join(" ")}`); } },
  { name: "base16", description: "Encode ke Base16 (hex uppercase)", category: "Encode",
    handler: async (e, a) => { const t = await getText(e, a); if (!t) return _fmt.reply(e, `❌ Tulis teks.`); return _fmt.reply(e, `<b>Hasil:</b>\n<code>${Buffer.from(t).toString("hex").toUpperCase()}</code>`); } },
  { name: "unbase16", description: "Decode Base16", category: "Encode",
    handler: async (e, a) => { const t = await getText(e, a); if (!t) return _fmt.reply(e, `❌ Tulis kode.`); try { return _fmt.reply(e, `<b>Hasil:</b>\n${_fmt.esc(Buffer.from(t.replace(/\s/g,""), "hex").toString("utf8"))}`); } catch { return _fmt.reply(e, `❌ Format hex salah.`); } } },
];

module.exports.commands = commands;
