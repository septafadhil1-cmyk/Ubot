// ─────────────────────────────────────────
//  Plugin: ASCII Art dari foto
//  .asci  (reply foto / kirim foto + caption .asci) → ubah foto jadi ASCII art
//  Output dijaga MAKS 1000 karakter (aman di bawah 1000/1200), dibungkus <pre> biar rapi.
// ─────────────────────────────────────────
const _fmt = require("./_format");
const { createCanvas, loadImage } = require("@napi-rs/canvas");

const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const MAX_CHARS = 1000;                 // batas total karakter ASCII (termasuk newline)
const RAMP = "@%#*+=-:. ";              // gelap → terang (padat = piksel gelap)
const CHAR_ASPECT = 0.5;                // karakter ~2x lebih tinggi dari lebar → tinggi dikali 0.5
const MAX_W = 64;                       // lebar maks biar ga kelewat lebar di HP

// Cari pesan yang ada fotonya: di pesan ini (foto + caption) atau di pesan yang di-reply
async function findImageMsg(event) {
  const msg = event.message;
  const isImg = (m) => m && (m.photo || (m.document && /image/i.test(m.document?.mimeType || "")));
  if (isImg(msg)) return msg;
  if (msg.replyTo) {
    try {
      const r = await msg.getReplyMessage();
      if (isImg(r) || (r && r.media)) return r;
    } catch {}
  }
  return null;
}

// Tentukan lebar/tinggi grid ASCII biar total karakter <= MAX_CHARS
function computeDims(imgW, imgH) {
  const ratio = (imgH || 1) / (imgW || 1);
  for (let W = MAX_W; W >= 10; W--) {
    const H = Math.max(1, Math.round(W * ratio * CHAR_ASPECT));
    if ((W + 1) * H <= MAX_CHARS) return { W, H }; // +1 = newline tiap baris
  }
  return { W: 10, H: Math.max(1, Math.round(10 * ratio * CHAR_ASPECT)) };
}

async function imageToAscii(buf) {
  const img = await loadImage(buf);
  const { W, H } = computeDims(img.width, img.height);
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0, W, H);
  const data = ctx.getImageData(0, 0, W, H).data;
  let out = "";
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      const a = data[i + 3];
      // luminance (Rec. 601); piksel transparan dianggap terang (spasi)
      let lum = a < 128 ? 255 : (0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
      let idx = Math.floor((lum / 255) * RAMP.length);
      if (idx >= RAMP.length) idx = RAMP.length - 1;
      out += RAMP[idx];
    }
    out += "\n";
  }
  return { text: out, W, H };
}

module.exports.commands = [
  {
    name: "asci",
    description: "Ubah foto jadi ASCII art (reply/kirim foto) — maks 1000 karakter",
    category: "Fun",
    handler: async (event, args, ctx) => {
      const msg = event.message;
      const client = ctx.client;
      const target = await findImageMsg(event);
      if (!target) {
        return _fmt.reply(event, `❌ Reply sebuah <b>foto</b> lalu ketik <code>.asci</code>, atau kirim foto dengan caption <code>.asci</code>.`);
      }

      let status;
      try { status = await msg.reply({ message: `<blockquote><b>🖼️ ᴍᴇɴɢᴜʙᴀʜ ꜰᴏᴛᴏ ᴋᴇ ᴀsᴄɪɪ...</b></blockquote>`, parseMode: "html" }); } catch {}

      try {
        const buf = await client.downloadMedia(target, {});
        if (!buf || !buf.length) throw new Error("Foto gagal diunduh");

        const { text, W, H } = await imageToAscii(buf);
        const safe = esc(text);
        const body = `<pre>${safe}</pre>`;

        // Edit pesan status jadi hasil ASCII (kalau ada), else kirim baru
        if (status) {
          await client.editMessage(msg.peerId, { message: status.id, text: body, parseMode: "html" });
        } else {
          await client.sendMessage(msg.peerId, { message: body, parseMode: "html", replyTo: msg.id });
        }
      } catch (e) {
        console.error("asci error:", e.message);
        const errText = `<blockquote><b>❌ ɢᴀɢᴀʟ ʙɪᴋɪɴ ᴀsᴄɪɪ: ${esc(e.message)}</b></blockquote>`;
        try {
          if (status) await client.editMessage(msg.peerId, { message: status.id, text: errText, parseMode: "html" });
          else await msg.reply({ message: errText, parseMode: "html" });
        } catch {}
      }
    },
  },
];
