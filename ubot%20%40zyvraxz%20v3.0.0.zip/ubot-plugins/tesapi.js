// ─────────────────────────────────────────
// Plugin: APITest — tester API sederhana
// GET / POST JSON
// ─────────────────────────────────────────

const _fmt = require("./_format");

const MAX_OUTPUT = 3500;
const TIMEOUT = 15000;

function cutText(text, max = MAX_OUTPUT) {
  text = String(text ?? "");

  if (text.length <= max) return text;

  return (
    text.slice(0, max) +
    `\n\n... [response dipotong, ${text.length} karakter]`
  );
}

function pretty(data) {
  if (typeof data === "string") {
    try {
      return JSON.stringify(JSON.parse(data), null, 2);
    } catch {
      return data;
    }
  }

  try {
    return JSON.stringify(data, null, 2);
  } catch {
    return String(data);
  }
}

function validUrl(url) {
  try {
    const u = new URL(url);

    return (
      u.protocol === "http:" ||
      u.protocol === "https:"
    );
  } catch {
    return false;
  }
}

async function fetchWithTimeout(url, options = {}) {
  const controller = new AbortController();

  const timer = setTimeout(() => {
    controller.abort();
  }, TIMEOUT);

  try {
    return await fetch(url, {
      ...options,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }
}

async function getText(event, args) {
  let t = args.join(" ");

  if (!t && event.message.replyTo) {
    try {
      const r = await event.message.getReplyMessage();
      t = r?.text || r?.message || "";
    } catch {}
  }

  return t.trim();
}

function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

const commands = [

  // ─────────────────────────────────────────
  // .apitest
  // ─────────────────────────────────────────
  {
    name: "apitest",
    description: "Tes API menggunakan GET (.apitest https://example.com/api)",
    category: "APITest",

    handler: async (event, args) => {
      const input = await getText(event, args);

      if (!input) {
        return _fmt.reply(
          event,
          `❌ <b>Format:</b>\n` +
          `<code>.apitest https://example.com/api</code>`
        );
      }

      const parts = input.split(/\s+/);
      const url = parts.shift();

      if (!validUrl(url)) {
        return _fmt.reply(
          event,
          `❌ URL tidak valid.\n\n` +
          `Contoh:\n` +
          `<code>.apitest https://example.com/api</code>`
        );
      }

      try {
        const start = Date.now();

        const response = await fetchWithTimeout(url, {
          method: "GET",
          headers: {
            "User-Agent": "Telegram-APITest/1.0",
            "Accept": "application/json,text/plain,*/*",
          },
        });

        const time = Date.now() - start;
        const raw = await response.text();

        const result = pretty(raw);

        return _fmt.reply(
          event,
          `🧪 <b>API TEST</b>\n\n` +
          `🌐 URL:\n<code>${_fmt.esc(url)}</code>\n\n` +
          `📡 Method: <b>GET</b>\n` +
          `📊 Status: <b>${response.status} ${_fmt.esc(response.statusText)}</b>\n` +
          `⚡ Response Time: <b>${time}ms</b>\n\n` +
          `📦 <b>Response:</b>\n` +
          `<pre>${_fmt.esc(cutText(result))}</pre>`
        );
      } catch (err) {
        let error = err?.message || String(err);

        if (err?.name === "AbortError") {
          error = `Request timeout (${TIMEOUT / 1000}s)`;
        }

        return _fmt.reply(
          event,
          `❌ <b>API ERROR</b>\n\n` +
          `🌐 <code>${_fmt.esc(url)}</code>\n\n` +
          `⚠️ ${_fmt.esc(error)}`
        );
      }
    },
  },

  // ─────────────────────────────────────────
  // .apipost
  // ─────────────────────────────────────────
  {
    name: "apipost",
    description: "Tes API POST JSON (.apipost URL {\"key\":\"value\"})",
    category: "APITest",

    handler: async (event, args) => {
      const input = await getText(event, args);

      if (!input) {
        return _fmt.reply(
          event,
          `❌ <b>Format:</b>\n` +
          `<code>.apipost https://example.com/api {"key":"value"}</code>`
        );
      }

      const match = input.match(
        /^(https?:\/\/\S+)\s+([\s\S]+)$/
      );

      if (!match) {
        return _fmt.reply(
          event,
          `❌ Format salah.\n\n` +
          `<code>.apipost URL {"key":"value"}</code>`
        );
      }

      const url = match[1];
      const jsonText = match[2].trim();

      if (!validUrl(url)) {
        return _fmt.reply(event, "❌ URL tidak valid.");
      }

      const body = parseJson(jsonText);

      if (body === null) {
        return _fmt.reply(
          event,
          `❌ JSON tidak valid.\n\n` +
          `Contoh:\n` +
          `<code>.apipost https://example.com/api {"name":"Ditzyv"}</code>`
        );
      }

      try {
        const start = Date.now();

        const response = await fetchWithTimeout(url, {
          method: "POST",

          headers: {
            "User-Agent": "Telegram-APITest/1.0",
            "Accept": "application/json,text/plain,*/*",
            "Content-Type": "application/json",
          },

          body: JSON.stringify(body),
        });

        const time = Date.now() - start;
        const raw = await response.text();

        const result = pretty(raw);

        return _fmt.reply(
          event,
          `🧪 <b>API TEST</b>\n\n` +
          `🌐 URL:\n<code>${_fmt.esc(url)}</code>\n\n` +
          `📡 Method: <b>POST</b>\n` +
          `📊 Status: <b>${response.status} ${_fmt.esc(response.statusText)}</b>\n` +
          `⚡ Response Time: <b>${time}ms</b>\n\n` +
          `📦 <b>Response:</b>\n` +
          `<pre>${_fmt.esc(cutText(result))}</pre>`
        );
      } catch (err) {
        let error = err?.message || String(err);

        if (err?.name === "AbortError") {
          error = `Request timeout (${TIMEOUT / 1000}s)`;
        }

        return _fmt.reply(
          event,
          `❌ <b>API ERROR</b>\n\n` +
          `🌐 <code>${_fmt.esc(url)}</code>\n\n` +
          `⚠️ ${_fmt.esc(error)}`
        );
      }
    },
  },

  // ─────────────────────────────────────────
  // .apihelp
  // ─────────────────────────────────────────
  {
    name: "apihelp",
    description: "Menampilkan bantuan API Tester",
    category: "APITest",

    handler: async (event) => {
      return _fmt.reply(
        event,
        `🧪 <b>API TESTER</b>\n\n` +

        `📡 <b>GET</b>\n` +
        `<code>.apitest https://example.com/api</code>\n\n` +

        `📤 <b>POST JSON</b>\n` +
        `<code>.apipost https://example.com/api {"key":"value"}</code>\n\n` +

        `⏱️ Timeout: <b>${TIMEOUT / 1000}s</b>\n` +
        `📦 Response otomatis dirapikan.\n` +
        `✂️ Response panjang akan dipotong.`
      );
    },
  },
];

module.exports = { commands };