// ─────────────────────────────────────────
//  Plugin: QRIS — simpan & tampilkan QRIS pribadi
//  .cqris (reply foto QRIS)  → pasang/ganti QRIS
//  .qris                      → tampilkan QRIS sendiri
//  Foto disimpan LOKAL di Pterodactyl (media/qris/<ownerId>.jpg), bukan Firebase
// ─────────────────────────────────────────

const _fmt = require("./_format");
const fs = require("fs");
const path = require("path");

const QRIS_DIR = path.join(__dirname, "..", "media", "qris");
function ensureDir() { try { fs.mkdirSync(QRIS_DIR, { recursive: true }); } catch {} }
function qrisPath(ownerId) { return path.join(QRIS_DIR, `${ownerId}.jpg`); }

module.exports.commands = [
  {
    name: "cqris",
    description: "Pasang QRIS (reply foto QRIS lalu .cqris)",
    category: "Utilitas",
    handler: async (event, args, ctx) => {
      const msg = event.message;
      const client = ctx.client;

      if (!msg.replyTo) {
        return _fmt.reply(event, `❌ Reply <b>foto QRIS</b> kamu lalu ketik <code>.cqris</code>.`);
      }
      try {
        const replied = await msg.getReplyMessage();
        if (!replied.media || !(replied.photo || (replied.document && /image/.test(replied.document.mimeType || "")))) {
          return _fmt.reply(event, `❌ Yang di-reply harus <b>foto/gambar QRIS</b>.`);
        }
        ensureDir();
        const out = qrisPath(ctx.ownerId);
        await client.downloadMedia(replied, { outputFile: out });

        return _fmt.reply(event,
          `✅ <b>QRIS berhasil dipasang!</b>\n\n` +
          `Sekarang kamu (atau orang lain) bisa ketik <code>.qris</code> untuk menampilkannya.\n\n` +
          `<i>Ganti QRIS: reply foto baru lalu <code>.cqris</code> lagi.</i>`
        );
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal simpan QRIS: ${_fmt.esc(e.message)}`);
      }
    },
  },
  {
    name: "qris",
    description: "Tampilkan QRIS kamu (pasang dulu pakai .cqris)",
    category: "Utilitas",
    handler: async (event, args, ctx) => {
      const msg = event.message;
      const client = ctx.client;
      const out = qrisPath(ctx.ownerId);

      // Belum pasang QRIS
      if (!fs.existsSync(out)) {
        return _fmt.reply(event,
          `⚠️ <b>Kamu belum pasang QRIS!</b>\n\n` +
          `Cara pasang: kirim/forward <b>foto QRIS</b> kamu, lalu <b>reply</b> foto itu dengan <code>.cqris</code>.`
        );
      }

      try {
        const caption = _fmt.wrap(`💳 <b>QRIS Pembayaran</b>\n\nScan QRIS di atas untuk bayar. Terima kasih! 🙏`);
        await client.sendFile(msg.peerId, {
          file: out,
          caption,
          parseMode: "html",
          replyTo: msg.id,
        });
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal kirim QRIS: ${_fmt.esc(e.message)}`);
      }
    },
  },
];
