// ─────────────────────────────────────────
//  Plugin: PM Guard — whitelist & blokir manual buat fitur privacy Anti-PM
//  (bekerja bareng Settings → Privacy: antiPM / blokirAsing)
//  .izinkanpm <id>/reply    → whitelist orang (kebal antiPM/blokir)
//  .hapusizinpm <id>/reply  → cabut dari whitelist
//  .daftarizinpm            → lihat daftar whitelist
//  .blokirpm <id>/reply     → blokir orang secara manual (langsung)
// ─────────────────────────────────────────
const { Api } = require("telegram");
const _fmt = require("./_format");
const privacy = require("../lib/privacyStore");
const esc = _fmt.esc;

module.exports.commands = [
  {
    name: "izinkanpm", description: "Whitelist orang dari Anti-PM: .izinkanpm <id> / reply", category: "Privasi",
    targetUser: true,
    handler: async (event, args, ctx) => {
      const id = args[0];
      if (!id || isNaN(parseInt(id))) return _fmt.reply(event, `❌ Format: <code>.izinkanpm &lt;id&gt;</code> atau reply pesan orangnya.`);
      privacy.addAllow(ctx.ownerId, id);
      return _fmt.reply(event, `✅ <code>${esc(id)}</code> di-whitelist. Dia kebal dari Anti-PM/Blokir asing.`);
    },
  },
  {
    name: "hapusizinpm", description: "Cabut whitelist: .hapusizinpm <id> / reply", category: "Privasi",
    targetUser: true,
    handler: async (event, args, ctx) => {
      const id = args[0];
      if (!id) return _fmt.reply(event, `❌ Format: <code>.hapusizinpm &lt;id&gt;</code> atau reply.`);
      privacy.removeAllow(ctx.ownerId, id);
      return _fmt.reply(event, `🗑 <code>${esc(id)}</code> dicabut dari whitelist.`);
    },
  },
  {
    name: "daftarizinpm", description: "Daftar whitelist Anti-PM", category: "Privasi",
    handler: async (event, args, ctx) => {
      const allow = privacy.get(ctx.ownerId).allow || [];
      if (!allow.length) return _fmt.reply(event, `📃 Whitelist kosong. Tambah pakai <code>.izinkanpm</code>.`);
      return _fmt.reply(event, `📃 <b>Whitelist Anti-PM</b> (${allow.length})\n\n` + allow.map((x) => `• <code>${esc(x)}</code>`).join("\n"));
    },
  },
  {
    name: "blokirpm", description: "Blokir orang manual: .blokirpm <id> / reply", category: "Privasi",
    targetUser: true,
    handler: async (event, args, ctx) => {
      const id = args[0];
      if (!id || isNaN(parseInt(id))) return _fmt.reply(event, `❌ Format: <code>.blokirpm &lt;id&gt;</code> atau reply pesan orangnya.`);
      try {
        const inp = await ctx.client.getInputEntity(parseInt(id));
        await ctx.client.invoke(new Api.contacts.Block({ id: inp }));
        return _fmt.reply(event, `⛔ <code>${esc(id)}</code> diblokir.`);
      } catch (e) {
        return _fmt.reply(event, `❌ Gagal blokir: ${esc(e.message)}`);
      }
    },
  },
];
