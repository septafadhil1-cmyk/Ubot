const { Button } = require("telegram/tl/custom/button");

async function showOwnerPanel(bot, db, event, userId) {
  try {
    const owners = Array.isArray(db.OWNER_IDS)
      ? db.OWNER_IDS.map(String)
      : [];

    if (!owners.includes(String(userId))) {
      return;
    }

    const text =
      `<blockquote>` +
      `<b>👑 OWNER PANEL</b>\n` +
      `━━━━━━━━━━━━━━━━━━\n\n` +
      `Selamat datang di panel Owner.\n\n` +
      `Pilih menu yang ingin kamu gunakan di bawah.` +
      `</blockquote>`;

    const buttons = [
      [
        Button.inline(
          "👥 Kelola User",
          Buffer.from("owner_manage")
        )
      ],
      [
        Button.inline(
          "📊 Statistik",
          Buffer.from("owner_stats")
        ),
        Button.inline(
          "📢 Broadcast",
          Buffer.from("owner_broadcast")
        )
      ],
      [
        Button.inline(
          "⚙️ Owner Settings",
          Buffer.from("owner_settings")
        )
      ],
      [
        Button.inline(
          "« Menu Utama",
          Buffer.from("tab_main")
        )
      ]
    ];

    const target = await bot.getInputEntity(parseInt(userId));

    await bot.sendMessage(target, {
      message: text,
      parseMode: "html",
      buttons: buttons
    });

  } catch (e) {
    console.error("Owner Panel error:", e.message);
  }
}

module.exports = {
  showOwnerPanel
};