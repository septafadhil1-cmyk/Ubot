const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "addgroups.json");

function ensureDB() {
    if (!fs.existsSync(DB_PATH)) {
        fs.writeFileSync(
            DB_PATH,
            JSON.stringify({ groups: [] }, null, 2)
        );
    }
}

function loadDB() {
    ensureDB();

    try {
        return JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
    } catch {
        return { groups: [] };
    }
}

function saveDB(db) {
    fs.writeFileSync(
        DB_PATH,
        JSON.stringify(db, null, 2)
    );
}

module.exports.commands = [
    {
        name: "addgroup",
        description: "Menyimpan grup sebagai target",
        category: "Tools",

        handler: async (event) => {
            if (!event.isGroup) {
                return event.reply("❌ Gunakan command ini di grup.");
            }

            const id = event.chatId.toString();
            const db = loadDB();

            if (db.groups.some(g => g.id === id)) {
                return event.reply("⚠️ Grup ini sudah tersimpan.");
            }

            let title = "Unknown";

            try {
                const chat = await event.getChat();
                title = chat.title || "Unknown";
            } catch {}

            db.groups.push({
                id,
                title,
                createdAt: Date.now()
            });

            saveDB(db);

            return event.reply(
                `✅ <b>GRUP DISIMPAN</b>\n\n` +
                `📌 ${title}\n` +
                `🆔 <code>${id}</code>`
            );
        }
    },

    {
        name: "delgroup",
        description: "Menghapus grup target",
        category: "Tools",

        handler: async (event) => {
            if (!event.isGroup) {
                return event.reply("❌ Gunakan command ini di grup.");
            }

            const id = event.chatId.toString();
            const db = loadDB();

            const before = db.groups.length;

            db.groups = db.groups.filter(
                g => g.id !== id
            );

            if (before === db.groups.length) {
                return event.reply(
                    "⚠️ Grup ini belum tersimpan."
                );
            }

            saveDB(db);

            return event.reply(
                "✅ Grup berhasil dihapus dari database."
            );
        }
    }
];

module.exports.loadDB = loadDB;
module.exports.saveDB = saveDB;
module.exports.DB_PATH = DB_PATH;