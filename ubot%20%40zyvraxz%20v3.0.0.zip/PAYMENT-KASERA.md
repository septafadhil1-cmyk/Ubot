# Kasera Pay — Wallet Top-Up Otomatis

Integrasi ini menggunakan API resmi Kasera Pay, QRIS, Virtual Account, webhook bertanda tangan, verifikasi status dari API Kasera, dan pencegahan kredit saldo ganda pada proses bot tunggal.

## Perintah

- `.pay 50000` — membuat invoice QRIS.
- `.pay 50000 va` — membuat invoice Virtual Account (metode default `va_bca`; ubah melalui `KASERA_VA_METHOD`).
- `.wallet` — melihat saldo wallet.
- `.paystatus` — melihat lima transaksi terakhir.
- `.paystatus KSR...` — memeriksa status invoice milik akun itu.

Nominal QRIS: Rp1.000–Rp10.000.000. Nominal VA: Rp10.000–Rp10.000.000. Saldo hanya ditambah setelah webhook `payment.paid` lolos verifikasi signature dan status pembayaran dikonfirmasi lewat API Kasera.

## Setup di hosting panel Node.js

1. Buat akun merchant Kasera Pay dan buka Developer untuk membuat API key. Jangan bagikan API key atau webhook secret.
2. Tambahkan environment variables berikut di panel hosting:
   - `KASERA_API_KEY`: gunakan `kp_test_...` untuk pengujian atau `kp_live_...` untuk produksi.
   - `KASERA_WEBHOOK_SECRET`: signing secret dari endpoint webhook di mode yang sama dengan API key.
   - `KASERA_WEBHOOK_PATH=/payment/kasera`
   - `KASERA_VA_METHOD=va_bca` (atau kode VA lain yang aktif pada akun Kasera).
   - `PAYMENT_WEBHOOK_PORT`: isi port yang disediakan hosting jika panel mewajibkannya; jika tidak, aplikasi memakai `PORT` atau 3000.
3. Di dashboard Kasera Pay, tambahkan webhook HTTPS publik yang mengarah ke `https://DOMAIN-ANDA/payment/kasera` dan aktifkan event `payment.paid`. Gunakan secret webhook dari mode yang sama (test/live).
4. Pastikan database bot persisten dan tersambung. Wallet dan invoice disimpan ke koleksi `wallets` dan `wallet_payments`; ID event disimpan di `kasera_events`.
5. Mulai dengan API key test (`kp_test_...`), buat `.pay 1000`, lalu selesaikan simulasi pembayaran melalui Kasera Pay Checkout. Pastikan `.wallet` bertambah dan `.paystatus` menunjukkan `PAID`.
6. Setelah tes berhasil, ganti ke API key live dan webhook secret live. Jangan pernah menaruh key di file publik atau membagikannya lewat screenshot.

## Catatan penting

- Kasera Pay memakai `POST /v1/transactions`; request menyertakan `Idempotency-Key` agar retry tidak membuat invoice baru.
- Webhook diverifikasi menggunakan `Kasera-Signature-V1` atas timestamp dan raw body, dengan toleransi 5 menit.
- Aplikasi mengecek status transaksi ke API Kasera sebelum saldo ditambah.
- Jangan anggap pembayaran live sudah teruji sebelum domain HTTPS publik, secret webhook, dan kredensial merchant milik Anda dikonfigurasi dan dites.
- Kredit ganda dicegah dengan status order, ledger wallet, dan lock per order di satu proses Node.js. Jalankan hanya satu instance bot untuk fitur wallet ini; untuk deployment multi-instance, pindahkan proses kredit ke transaksi/unique constraint atomik di database.
